IREE compile dumps for the post "Inside a linalg.matmul: A Deep Dive into IREE's Compilation Pipeline".

Contents:
  matmul_500.mlir                  the input MLIR (500x500 f32 matmul)
  matmul_500/                      the --mlir-print-ir-tree-dir dump, pass by pass
  config/                          one standalone .mlir per dispatch (--iree-hal-dump-executable-configurations-to)

Compiler used:
  IREE compiler version dev @ 442c605b3f85b0728389abb83ad842db38d5108e
  LLVM version 24.0.0git

Command:
  iree-compile /tmp/matmul_500.mlir \
    --iree-hal-target-backends=llvm-cpu \
    --iree-llvmcpu-target-cpu=apple-m4 \
    --iree-opt-level=O3 \
    --iree-llvmcpu-disable-distribution=true \
    --iree-opt-data-tiling=true \
    --iree-llvmcpu-enable-ukernels=none \
    --mlir-disable-threading \
    --mlir-print-ir-after-all \
    --mlir-print-ir-after-change \
    --mlir-print-ir-tree-dir=/tmp/matmul_500 \
    --iree-hal-dump-executable-configurations-to=/tmp/matmul_500/configs \
    -o /tmp/matmul_500/matmul_500.vmfb