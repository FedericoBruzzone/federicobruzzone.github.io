// FILE: /tmp/matmul_500.mlir
func.func @matmul(%A: tensor<500x500xf32>, 
                  %B: tensor<500x500xf32>, 
                  %C: tensor<500x500xf32>) -> tensor<500x500xf32> {
    %0 = linalg.matmul 
            ins(%A, %B : tensor<500x500xf32>, tensor<500x500xf32>) 
            outs(%C : tensor<500x500xf32>) -> tensor<500x500xf32>
    func.return %0 : tensor<500x500xf32>
}