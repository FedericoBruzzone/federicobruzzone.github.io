// -----// IR Dump After IREEImportPublicPass: iree-import-public //----- //
module {
  util.func public @matmul(%arg0: tensor<500x500xf32>, %arg1: tensor<500x500xf32>, %arg2: tensor<500x500xf32>) -> tensor<500x500xf32> {
    %0 = linalg.matmul ins(%arg0, %arg1 : tensor<500x500xf32>, tensor<500x500xf32>) outs(%arg2 : tensor<500x500xf32>) -> tensor<500x500xf32>
    util.return %0 : tensor<500x500xf32>
  }
}


