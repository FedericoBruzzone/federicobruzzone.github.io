// -----// IR Dump After WrapEntryPointsPass: iree-abi-wrap-entry-points{invocation-model=sync} //----- //
module {
  util.func public @matmul(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "sync func @matmul(%input0: tensor<500x500xf32>, %input1: tensor<500x500xf32>, %input2: tensor<500x500xf32>) -> (%output0: tensor<500x500xf32>)"}} {
    %0 = hal.tensor.import %arg0 "input0" : !hal.buffer_view -> tensor<500x500xf32>
    %1 = hal.tensor.import %arg1 "input1" : !hal.buffer_view -> tensor<500x500xf32>
    %2 = hal.tensor.import %arg2 "input2" : !hal.buffer_view -> tensor<500x500xf32>
    %3 = util.call @_matmul(%0, %1, %2) : (tensor<500x500xf32>, tensor<500x500xf32>, tensor<500x500xf32>) -> tensor<500x500xf32>
    %4 = hal.tensor.export %3 "output0" : tensor<500x500xf32> -> !hal.buffer_view
    util.return %4 : !hal.buffer_view
  }
  util.func private @_matmul(%arg0: tensor<500x500xf32>, %arg1: tensor<500x500xf32>, %arg2: tensor<500x500xf32>) -> tensor<500x500xf32> attributes {hal.abi.convention = #hal.abi.convention<synchronous>} {
    %0 = linalg.matmul ins(%arg0, %arg1 : tensor<500x500xf32>, tensor<500x500xf32>) outs(%arg2 : tensor<500x500xf32>) -> tensor<500x500xf32>
    util.return %0 : tensor<500x500xf32>
  }
}


