// -----// IR Dump After PackDispatchOperandsPass: iree-stream-pack-dispatch-operands //----- //
#encoding = #iree_encoding.layout<[#iree_cpu.cpu_encoding_resolver<configuration = {encoding_info = {innerDimsPos = [0, 1], innerTileSizes = [8, 1], outerDimsPerm = [0, 1]}}>]>
#encoding1 = #iree_encoding.layout<[#iree_cpu.cpu_encoding_resolver<configuration = {encoding_info = {innerDimsPos = [1, 0], innerTileSizes = [8, 1], outerDimsPerm = [1, 0]}}>]>
#encoding2 = #iree_encoding.layout<[#iree_cpu.cpu_encoding_resolver<configuration = {encoding_info = {innerDimsPos = [0, 1], innerTileSizes = [8, 8], outerDimsPerm = [0, 1]}}>]>
#executable_target_embedded_elf_arm_64 = #hal.executable.target<"llvm-cpu", "embedded-elf-arm_64", {cpu = "apple-m4", cpu_features = "+v8.7a,+aes,+bf16,+complxnum,+crc,+dotprod,+fp-armv8,+fp16fml,+fpac,+fullfp16,+i8mm,+jsconv,+lse,+neon,+pauth,+perfmon,+ras,+rcpc,+rdm,+sha2,+sha3,+sme,+sme-f64f64,+sme-i16i64,+sme2,+reserve-x18", data_layout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128-Fn32", iree.encoding.resolver = #iree_cpu.cpu_encoding_resolver<>, max_stack_allocation_size = 32768 : i64, native_vector_size = 16 : i64, target_triple = "arm64-unknown-unknown-eabi-elf", ukernels = "none"}>
#map = affine_map<(d0, d1, d2) -> (d0, d2)>
#map1 = affine_map<(d0, d1, d2) -> (d2, d1)>
#map2 = affine_map<(d0, d1, d2) -> (d0, d1)>
#device_target_local = #hal.device.target<"local", [#executable_target_embedded_elf_arm_64]> : !hal.device
#encoding3 = #iree_encoding.encoding<operand_index = 0 : index, op_type = matmul, element_types = [f32, f32, f32], user_indexing_maps = [#map, #map1, #map2], iteration_sizes = [500, 500, 500]>
#encoding4 = #iree_encoding.encoding<operand_index = 1 : index, op_type = matmul, element_types = [f32, f32, f32], user_indexing_maps = [#map, #map1, #map2], iteration_sizes = [500, 500, 500]>
#encoding5 = #iree_encoding.encoding<operand_index = 2 : index, op_type = matmul, element_types = [f32, f32, f32], user_indexing_maps = [#map, #map1, #map2], iteration_sizes = [500, 500, 500]>
module attributes {stream.affinity.default = #hal.device.affinity<@__device_0>} {
  util.global private @__device_0 = #device_target_local
  stream.executable private @matmul_dispatch_0 {
    stream.executable.export public @matmul_dispatch_0_matmul_like_500x500x500_f32 workgroups() -> (index, index, index) {
      %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice()
      stream.return %x, %y, %z : index, index, index
    }
    builtin.module {
      func.func @matmul_dispatch_0_matmul_like_500x500x500_f32(%arg0: !stream.binding {stream.alignment = 64 : index}, %arg1: !stream.binding {stream.alignment = 64 : index}, %arg2: i32, %arg3: i32, %arg4: i32, %arg5: i32, %arg6: i32, %arg7: i32, %arg8: i32, %arg9: i32) {
        %0 = arith.extui %arg2 : i32 to i64
        %1 = arith.extui %arg3 : i32 to i64
        %c32_i64 = arith.constant 32 : i64
        %2 = arith.shli %1, %c32_i64 : i64
        %3 = arith.ori %0, %2 : i64
        %4 = arith.index_castui %3 {stream.values = [0 : index]} : i64 to index
        %5 = arith.extui %arg4 : i32 to i64
        %6 = arith.extui %arg5 : i32 to i64
        %c32_i64_0 = arith.constant 32 : i64
        %7 = arith.shli %6, %c32_i64_0 : i64
        %8 = arith.ori %5, %7 : i64
        %9 = arith.index_castui %8 {stream.alignment = 128 : index, stream.values = [1008000 : index]} : i64 to index
        %10 = arith.extui %arg6 : i32 to i64
        %11 = arith.extui %arg7 : i32 to i64
        %c32_i64_1 = arith.constant 32 : i64
        %12 = arith.shli %11, %c32_i64_1 : i64
        %13 = arith.ori %10, %12 : i64
        %14 = arith.index_castui %13 {stream.alignment = 256 : index, stream.values = [2016000 : index]} : i64 to index
        %15 = arith.extui %arg8 : i32 to i64
        %16 = arith.extui %arg9 : i32 to i64
        %c32_i64_2 = arith.constant 32 : i64
        %17 = arith.shli %16, %c32_i64_2 : i64
        %18 = arith.ori %15, %17 : i64
        %19 = arith.index_castui %18 {stream.values = [0 : index]} : i64 to index
        %20:4 = util.assume.int 
            %4<umin = 0, umax = 0>, 
            %9<umin = 1008000, umax = 1008000, udiv = 1008000>, 
            %14<umin = 2016000, umax = 2016000, udiv = 2016000>, 
            %19<umin = 0, umax = 0>
          : index, index, index, index
        %c0 = arith.constant 0 : index
        %21 = stream.binding.subspan %arg0[%20#0] : !stream.binding -> !iree_tensor_ext.dispatch.tensor<readonly:tensor<500x500xf32, #encoding>>
        %22 = stream.binding.subspan %arg0[%20#1] : !stream.binding -> !iree_tensor_ext.dispatch.tensor<readonly:tensor<500x500xf32, #encoding1>>
        %23 = stream.binding.subspan %arg0[%20#2] : !stream.binding -> !iree_tensor_ext.dispatch.tensor<readonly:tensor<500x500xf32, #encoding2>>
        %24 = stream.binding.subspan %arg1[%20#3] : !stream.binding -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<500x500xf32>>
        %25 = iree_tensor_ext.dispatch.tensor.load %21, offsets = [0, 0], sizes = [500, 500], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<500x500xf32, #encoding>> -> tensor<500x500xf32, #encoding3>
        %26 = iree_tensor_ext.dispatch.tensor.load %22, offsets = [0, 0], sizes = [500, 500], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<500x500xf32, #encoding1>> -> tensor<500x500xf32, #encoding4>
        %27 = iree_tensor_ext.dispatch.tensor.load %23, offsets = [0, 0], sizes = [500, 500], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<500x500xf32, #encoding2>> -> tensor<500x500xf32, #encoding5>
        %28 = linalg.generic {indexing_maps = [#map, #map1, #map2], iterator_types = ["parallel", "parallel", "reduction"]} ins(%25, %26 : tensor<500x500xf32, #encoding3>, tensor<500x500xf32, #encoding4>) outs(%27 : tensor<500x500xf32, #encoding5>) {
        ^bb0(%in: f32, %in_3: f32, %out: f32):
          %30 = arith.mulf %in, %in_3 : f32
          %31 = arith.addf %out, %30 : f32
          linalg.yield %31 : f32
        } -> tensor<500x500xf32, #encoding5>
        %29 = iree_encoding.unset_encoding %28 : tensor<500x500xf32, #encoding5> -> tensor<500x500xf32>
        iree_tensor_ext.dispatch.tensor.store %29, %24, offsets = [0, 0], sizes = [500, 500], strides = [1, 1] : tensor<500x500xf32> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<500x500xf32>>
        return
      }
    }
  }
  stream.executable private @_encoding_0 {
    stream.executable.export public @_encoding_0_encode_500x500xf32_to_500x500xf32 workgroups() -> (index, index, index) {
      %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice()
      stream.return %x, %y, %z : index, index, index
    }
    builtin.module {
      func.func @_encoding_0_encode_500x500xf32_to_500x500xf32(%arg0: !stream.binding {stream.alignment = 64 : index}, %arg1: !stream.binding {stream.alignment = 64 : index}, %arg2: i32, %arg3: i32, %arg4: i32, %arg5: i32) {
        %0 = arith.extui %arg2 : i32 to i64
        %1 = arith.extui %arg3 : i32 to i64
        %c32_i64 = arith.constant 32 : i64
        %2 = arith.shli %1, %c32_i64 : i64
        %3 = arith.ori %0, %2 : i64
        %4 = arith.index_castui %3 {stream.values = [0 : index]} : i64 to index
        %5 = arith.extui %arg4 : i32 to i64
        %6 = arith.extui %arg5 : i32 to i64
        %c32_i64_0 = arith.constant 32 : i64
        %7 = arith.shli %6, %c32_i64_0 : i64
        %8 = arith.ori %5, %7 : i64
        %9 = arith.index_castui %8 {stream.values = [0 : index]} : i64 to index
        %10:2 = util.assume.int 
            %4<umin = 0, umax = 0>, 
            %9<umin = 0, umax = 0>
          : index, index
        %c0 = arith.constant 0 : index
        %11 = stream.binding.subspan %arg0[%10#0] : !stream.binding -> !iree_tensor_ext.dispatch.tensor<readonly:tensor<500x500xf32>>
        %12 = stream.binding.subspan %arg1[%10#1] : !stream.binding -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<500x500xf32, #encoding>>
        %13 = iree_tensor_ext.dispatch.tensor.load %11, offsets = [0, 0], sizes = [500, 500], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<500x500xf32>> -> tensor<500x500xf32>
        %14 = iree_encoding.set_encoding %13 : tensor<500x500xf32> -> tensor<500x500xf32, #encoding>
        iree_tensor_ext.dispatch.tensor.store %14, %12, offsets = [0, 0], sizes = [500, 500], strides = [1, 1] : tensor<500x500xf32, #encoding> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<500x500xf32, #encoding>>
        return
      }
    }
  }
  stream.executable private @_encoding_1 {
    stream.executable.export public @_encoding_1_encode_500x500xf32_to_500x500xf32 workgroups() -> (index, index, index) {
      %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice()
      stream.return %x, %y, %z : index, index, index
    }
    builtin.module {
      func.func @_encoding_1_encode_500x500xf32_to_500x500xf32(%arg0: !stream.binding {stream.alignment = 64 : index}, %arg1: !stream.binding {stream.alignment = 64 : index}, %arg2: i32, %arg3: i32, %arg4: i32, %arg5: i32) {
        %0 = arith.extui %arg2 : i32 to i64
        %1 = arith.extui %arg3 : i32 to i64
        %c32_i64 = arith.constant 32 : i64
        %2 = arith.shli %1, %c32_i64 : i64
        %3 = arith.ori %0, %2 : i64
        %4 = arith.index_castui %3 {stream.values = [0 : index]} : i64 to index
        %5 = arith.extui %arg4 : i32 to i64
        %6 = arith.extui %arg5 : i32 to i64
        %c32_i64_0 = arith.constant 32 : i64
        %7 = arith.shli %6, %c32_i64_0 : i64
        %8 = arith.ori %5, %7 : i64
        %9 = arith.index_castui %8 {stream.alignment = 128 : index, stream.values = [1008000 : index]} : i64 to index
        %10:2 = util.assume.int 
            %4<umin = 0, umax = 0>, 
            %9<umin = 1008000, umax = 1008000, udiv = 1008000>
          : index, index
        %c0 = arith.constant 0 : index
        %11 = stream.binding.subspan %arg0[%10#0] : !stream.binding -> !iree_tensor_ext.dispatch.tensor<readonly:tensor<500x500xf32>>
        %12 = stream.binding.subspan %arg1[%10#1] : !stream.binding -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<500x500xf32, #encoding1>>
        %13 = iree_tensor_ext.dispatch.tensor.load %11, offsets = [0, 0], sizes = [500, 500], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<500x500xf32>> -> tensor<500x500xf32>
        %14 = iree_encoding.set_encoding %13 : tensor<500x500xf32> -> tensor<500x500xf32, #encoding1>
        iree_tensor_ext.dispatch.tensor.store %14, %12, offsets = [0, 0], sizes = [500, 500], strides = [1, 1] : tensor<500x500xf32, #encoding1> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<500x500xf32, #encoding1>>
        return
      }
    }
  }
  stream.executable private @_encoding_2 {
    stream.executable.export public @_encoding_2_encode_500x500xf32_to_500x500xf32 workgroups() -> (index, index, index) {
      %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice()
      stream.return %x, %y, %z : index, index, index
    }
    builtin.module {
      func.func @_encoding_2_encode_500x500xf32_to_500x500xf32(%arg0: !stream.binding {stream.alignment = 64 : index}, %arg1: !stream.binding {stream.alignment = 64 : index}, %arg2: i32, %arg3: i32, %arg4: i32, %arg5: i32) {
        %0 = arith.extui %arg2 : i32 to i64
        %1 = arith.extui %arg3 : i32 to i64
        %c32_i64 = arith.constant 32 : i64
        %2 = arith.shli %1, %c32_i64 : i64
        %3 = arith.ori %0, %2 : i64
        %4 = arith.index_castui %3 {stream.values = [0 : index]} : i64 to index
        %5 = arith.extui %arg4 : i32 to i64
        %6 = arith.extui %arg5 : i32 to i64
        %c32_i64_0 = arith.constant 32 : i64
        %7 = arith.shli %6, %c32_i64_0 : i64
        %8 = arith.ori %5, %7 : i64
        %9 = arith.index_castui %8 {stream.alignment = 256 : index, stream.values = [2016000 : index]} : i64 to index
        %10:2 = util.assume.int 
            %4<umin = 0, umax = 0>, 
            %9<umin = 2016000, umax = 2016000, udiv = 2016000>
          : index, index
        %c0 = arith.constant 0 : index
        %11 = stream.binding.subspan %arg0[%10#0] : !stream.binding -> !iree_tensor_ext.dispatch.tensor<readonly:tensor<500x500xf32>>
        %12 = stream.binding.subspan %arg1[%10#1] : !stream.binding -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<500x500xf32, #encoding2>>
        %13 = iree_tensor_ext.dispatch.tensor.load %11, offsets = [0, 0], sizes = [500, 500], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<500x500xf32>> -> tensor<500x500xf32>
        %14 = iree_encoding.set_encoding %13 : tensor<500x500xf32> -> tensor<500x500xf32, #encoding2>
        iree_tensor_ext.dispatch.tensor.store %14, %12, offsets = [0, 0], sizes = [500, 500], strides = [1, 1] : tensor<500x500xf32, #encoding2> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<500x500xf32, #encoding2>>
        return
      }
    }
  }
  util.func public @matmul(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "sync func @matmul(%input0: tensor<500x500xf32>, %input1: tensor<500x500xf32>, %input2: tensor<500x500xf32>) -> (%output0: tensor<500x500xf32>)"}} {
    %c3032064 = arith.constant 3032064 : index
    %c2016000 = arith.constant 2016000 : index
    %c0 = arith.constant 0 : index
    %c1016064 = arith.constant 1016064 : index
    %c1008000 = arith.constant 1008000 : index
    %c1000000 = arith.constant 1000000 : index
    %c500 = arith.constant 500 : index
    %element_type_f32 = hal.element_type<f32> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%c500, %c500]) type(%element_type_f32) encoding(%dense_row_major)
    %0 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<500x500xf32> in !stream.resource<external>{%c1000000}
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%c500, %c500]) type(%element_type_f32) encoding(%dense_row_major)
    %1 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<500x500xf32> in !stream.resource<external>{%c1000000}
    hal.buffer_view.assert<%arg2 : !hal.buffer_view> message("input2") shape([%c500, %c500]) type(%element_type_f32) encoding(%dense_row_major)
    %2 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg2 : !hal.buffer_view -> tensor<500x500xf32> in !stream.resource<external>{%c1000000}
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) : !stream.resource<external>{%c1000000} => !stream.timepoint
    %result_0, %result_timepoint_1 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) : !stream.resource<transient>{%c3032064} => !stream.timepoint
    %3 = stream.timepoint.join max(%result_timepoint, %result_timepoint_1) => !stream.timepoint
    %c0_2 = arith.constant 0 : index
    %c0_i64 = arith.constant 0 : i64
    %c0_i32 = arith.constant 0 : i32
    %c32_i64 = arith.constant 32 : i64
    %c0_i32_3 = arith.constant 0 : i32
    %c0_i64_4 = arith.constant 0 : i64
    %c0_i32_5 = arith.constant 0 : i32
    %c32_i64_6 = arith.constant 32 : i64
    %c0_i32_7 = arith.constant 0 : i32
    %c0_i64_8 = arith.constant 0 : i64
    %c0_i32_9 = arith.constant 0 : i32
    %c32_i64_10 = arith.constant 32 : i64
    %c0_i32_11 = arith.constant 0 : i32
    %c1008000_i64 = arith.constant 1008000 : i64
    %c1008000_i32 = arith.constant 1008000 : i32
    %c32_i64_12 = arith.constant 32 : i64
    %c0_i64_13 = arith.constant 0 : i64
    %c0_i32_14 = arith.constant 0 : i32
    %c0_i64_15 = arith.constant 0 : i64
    %c0_i32_16 = arith.constant 0 : i32
    %c32_i64_17 = arith.constant 32 : i64
    %c0_i32_18 = arith.constant 0 : i32
    %c2016000_i64 = arith.constant 2016000 : i64
    %c2016000_i32 = arith.constant 2016000 : i32
    %c32_i64_19 = arith.constant 32 : i64
    %c0_i64_20 = arith.constant 0 : i64
    %c0_i32_21 = arith.constant 0 : i32
    %c0_i64_22 = arith.constant 0 : i64
    %c0_i32_23 = arith.constant 0 : i32
    %c32_i64_24 = arith.constant 32 : i64
    %c0_i32_25 = arith.constant 0 : i32
    %c1008000_i64_26 = arith.constant 1008000 : i64
    %c1008000_i32_27 = arith.constant 1008000 : i32
    %c32_i64_28 = arith.constant 32 : i64
    %c0_i64_29 = arith.constant 0 : i64
    %c0_i32_30 = arith.constant 0 : i32
    %c2016000_i64_31 = arith.constant 2016000 : i64
    %c2016000_i32_32 = arith.constant 2016000 : i32
    %c32_i64_33 = arith.constant 32 : i64
    %c0_i64_34 = arith.constant 0 : i64
    %c0_i32_35 = arith.constant 0 : i32
    %c0_i64_36 = arith.constant 0 : i64
    %c0_i32_37 = arith.constant 0 : i32
    %c32_i64_38 = arith.constant 32 : i64
    %c0_i32_39 = arith.constant 0 : i32
    %4 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%3) => with(%0 as %arg3: !stream.resource<external>{%c1000000}, %1 as %arg4: !stream.resource<external>{%c1000000}, %2 as %arg5: !stream.resource<external>{%c1000000}, %result as %arg6: !stream.resource<external>{%c1000000}, %result_0 as %arg7: !stream.resource<transient>{%c3032064}) {
      stream.cmd.concurrent {
        stream.cmd.dispatch @_encoding_0::@_encoding_0_encode_500x500xf32_to_500x500xf32(%c0_i32, %c0_i32_3, %c0_i32_5, %c0_i32_7 : i32, i32, i32, i32) {
          ro %arg3[%c0_2 for %c1000000] : !stream.resource<external>{%c1000000},
          wo %arg7[%c0_2 for %c3032064] : !stream.resource<transient>{%c3032064}
        }
        stream.cmd.dispatch @_encoding_1::@_encoding_1_encode_500x500xf32_to_500x500xf32(%c0_i32_9, %c0_i32_11, %c1008000_i32, %c0_i32_14 : i32, i32, i32, i32) {
          ro %arg4[%c0_2 for %c1000000] : !stream.resource<external>{%c1000000},
          wo %arg7[%c0_2 for %c3032064] : !stream.resource<transient>{%c3032064}
        }
        stream.cmd.dispatch @_encoding_2::@_encoding_2_encode_500x500xf32_to_500x500xf32(%c0_i32_16, %c0_i32_18, %c2016000_i32, %c0_i32_21 : i32, i32, i32, i32) {
          ro %arg5[%c0_2 for %c1000000] : !stream.resource<external>{%c1000000},
          wo %arg7[%c0_2 for %c3032064] : !stream.resource<transient>{%c3032064}
        }
      }
      stream.cmd.dispatch @matmul_dispatch_0::@matmul_dispatch_0_matmul_like_500x500x500_f32(%c0_i32_23, %c0_i32_25, %c1008000_i32_27, %c0_i32_30, %c2016000_i32_32, %c0_i32_35, %c0_i32_37, %c0_i32_39 : i32, i32, i32, i32, i32, i32, i32, i32) {
        ro %arg7[%c0_2 for %c3032064] : !stream.resource<transient>{%c3032064},
        wo %arg6[%c0_2 for %c1000000] : !stream.resource<external>{%c1000000}
      }
    } => !stream.timepoint
    %5 = stream.resource.dealloca on(#hal.device.affinity<@__device_0>) await(%4) => %result_0 : !stream.resource<transient>{%c3032064} => !stream.timepoint
    %6 = stream.timepoint.await %5 => %result : !stream.resource<external>{%c1000000}
    %7 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %6 : tensor<500x500xf32> in !stream.resource<external>{%c1000000} -> !hal.buffer_view
    util.return %7 : !hal.buffer_view
  }
}


