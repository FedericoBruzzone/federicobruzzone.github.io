// -----// IR Dump After FoldGlobalsPass: iree-util-fold-globals //----- //
#encoding = #iree_encoding.layout<[#iree_cpu.cpu_encoding_resolver<configuration = {encoding_info = {innerDimsPos = [0, 1], innerTileSizes = [8, 1], outerDimsPerm = [0, 1]}}>]>
#encoding1 = #iree_encoding.layout<[#iree_cpu.cpu_encoding_resolver<configuration = {encoding_info = {innerDimsPos = [1, 0], innerTileSizes = [8, 1], outerDimsPerm = [1, 0]}}>]>
#encoding2 = #iree_encoding.layout<[#iree_cpu.cpu_encoding_resolver<configuration = {encoding_info = {innerDimsPos = [0, 1], innerTileSizes = [8, 8], outerDimsPerm = [0, 1]}}>]>
#executable_target_embedded_elf_arm_64 = #hal.executable.target<"llvm-cpu", "embedded-elf-arm_64", {cpu = "apple-m4", cpu_features = "+v8.7a,+aes,+bf16,+complxnum,+crc,+dotprod,+fp-armv8,+fp16fml,+fpac,+fullfp16,+i8mm,+jsconv,+lse,+neon,+pauth,+perfmon,+ras,+rcpc,+rdm,+sha2,+sha3,+sme,+sme-f64f64,+sme-i16i64,+sme2,+reserve-x18", data_layout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128-Fn32", iree.encoding.resolver = #iree_cpu.cpu_encoding_resolver<>, max_stack_allocation_size = 32768 : i64, native_vector_size = 16 : i64, target_triple = "arm64-unknown-unknown-eabi-elf", ukernels = "none"}>
#map = affine_map<(d0, d1, d2) -> (d0, d2)>
#map1 = affine_map<(d0, d1, d2) -> (d2, d1)>
#map2 = affine_map<(d0, d1, d2) -> (d0, d1)>
#device_target_local = #hal.device.target<"local", [#executable_target_embedded_elf_arm_64]> : !hal.device
#encoding3 = #iree_encoding.encoding<operand_index = 0 : index, op_type = matmul, element_types = [f32, f32, f32], user_indexing_maps = [#map, #map1, #map2], iteration_sizes = [500, 500, 500]>
#encoding4 = #iree_encoding.encoding<operand_index = 1 : index, op_type = matmul, element_types = [f32, f32, f32], user_indexing_maps = [#map, #map1, #map2], iteration_sizes = [500, 500, 500]>
#encoding5 = #iree_encoding.encoding<operand_index = 2 : index, op_type = matmul, element_types = [f32, f32, f32], user_indexing_maps = [#map, #map1, #map2], iteration_sizes = [500, 500, 500]>
module attributes {stream.affinity.default = #hal.device.affinity<@__device_0>} {
  util.global private @__device_0 = #device_target_local
  stream.executable private @matmul_dispatch_0 {
    stream.executable.export public @matmul_dispatch_0_matmul_like_500x500x500_f32 workgroups() -> (index, index, index) {
      %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice()
      stream.return %x, %y, %z : index, index, index
    }
    builtin.module {
      func.func @matmul_dispatch_0_matmul_like_500x500x500_f32(%arg0: !stream.binding {stream.alignment = 64 : index}, %arg1: !stream.binding {stream.alignment = 64 : index}) {
        %c0 = arith.constant 0 : index
        %c1008000 = arith.constant 1008000 : index
        %c2016000 = arith.constant 2016000 : index
        %0 = stream.binding.subspan %arg0[%c0] : !stream.binding -> !iree_tensor_ext.dispatch.tensor<readonly:tensor<500x500xf32, #encoding>>
        %1 = stream.binding.subspan %arg0[%c1008000] : !stream.binding -> !iree_tensor_ext.dispatch.tensor<readonly:tensor<500x500xf32, #encoding1>>
        %2 = stream.binding.subspan %arg0[%c2016000] : !stream.binding -> !iree_tensor_ext.dispatch.tensor<readonly:tensor<500x500xf32, #encoding2>>
        %3 = stream.binding.subspan %arg1[%c0] : !stream.binding -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<500x500xf32>>
        %4 = iree_tensor_ext.dispatch.tensor.load %0, offsets = [0, 0], sizes = [500, 500], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<500x500xf32, #encoding>> -> tensor<500x500xf32, #encoding3>
        %5 = iree_tensor_ext.dispatch.tensor.load %1, offsets = [0, 0], sizes = [500, 500], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<500x500xf32, #encoding1>> -> tensor<500x500xf32, #encoding4>
        %6 = iree_tensor_ext.dispatch.tensor.load %2, offsets = [0, 0], sizes = [500, 500], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<500x500xf32, #encoding2>> -> tensor<500x500xf32, #encoding5>
        %7 = linalg.generic {indexing_maps = [#map, #map1, #map2], iterator_types = ["parallel", "parallel", "reduction"]} ins(%4, %5 : tensor<500x500xf32, #encoding3>, tensor<500x500xf32, #encoding4>) outs(%6 : tensor<500x500xf32, #encoding5>) {
        ^bb0(%in: f32, %in_0: f32, %out: f32):
          %9 = arith.mulf %in, %in_0 : f32
          %10 = arith.addf %out, %9 : f32
          linalg.yield %10 : f32
        } -> tensor<500x500xf32, #encoding5>
        %8 = iree_encoding.unset_encoding %7 : tensor<500x500xf32, #encoding5> -> tensor<500x500xf32>
        iree_tensor_ext.dispatch.tensor.store %8, %3, offsets = [0, 0], sizes = [500, 500], strides = [1, 1] : tensor<500x500xf32> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<500x500xf32>>
        return
      }
    }
  }
  stream.executable private @_encoding_0 {
    stream.executable.export public @_encoding_0_encode_500x500xf32_to_500x500xf32 workgroups() -> (index, index, index) {
      %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice()
      stream.return %x, %y, %z : index, index, index
    }
    builtin.module {
      func.func @_encoding_0_encode_500x500xf32_to_500x500xf32(%arg0: !stream.binding {stream.alignment = 64 : index}, %arg1: !stream.binding {stream.alignment = 64 : index}) {
        %c0 = arith.constant 0 : index
        %0 = stream.binding.subspan %arg0[%c0] : !stream.binding -> !iree_tensor_ext.dispatch.tensor<readonly:tensor<500x500xf32>>
        %1 = stream.binding.subspan %arg1[%c0] : !stream.binding -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<500x500xf32, #encoding>>
        %2 = iree_tensor_ext.dispatch.tensor.load %0, offsets = [0, 0], sizes = [500, 500], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<500x500xf32>> -> tensor<500x500xf32>
        %3 = iree_encoding.set_encoding %2 : tensor<500x500xf32> -> tensor<500x500xf32, #encoding>
        iree_tensor_ext.dispatch.tensor.store %3, %1, offsets = [0, 0], sizes = [500, 500], strides = [1, 1] : tensor<500x500xf32, #encoding> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<500x500xf32, #encoding>>
        return
      }
    }
  }
  stream.executable private @_encoding_1 {
    stream.executable.export public @_encoding_1_encode_500x500xf32_to_500x500xf32 workgroups() -> (index, index, index) {
      %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice()
      stream.return %x, %y, %z : index, index, index
    }
    builtin.module {
      func.func @_encoding_1_encode_500x500xf32_to_500x500xf32(%arg0: !stream.binding {stream.alignment = 64 : index}, %arg1: !stream.binding {stream.alignment = 64 : index}) {
        %c0 = arith.constant 0 : index
        %c1008000 = arith.constant 1008000 : index
        %0 = stream.binding.subspan %arg0[%c0] : !stream.binding -> !iree_tensor_ext.dispatch.tensor<readonly:tensor<500x500xf32>>
        %1 = stream.binding.subspan %arg1[%c1008000] : !stream.binding -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<500x500xf32, #encoding1>>
        %2 = iree_tensor_ext.dispatch.tensor.load %0, offsets = [0, 0], sizes = [500, 500], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<500x500xf32>> -> tensor<500x500xf32>
        %3 = iree_encoding.set_encoding %2 : tensor<500x500xf32> -> tensor<500x500xf32, #encoding1>
        iree_tensor_ext.dispatch.tensor.store %3, %1, offsets = [0, 0], sizes = [500, 500], strides = [1, 1] : tensor<500x500xf32, #encoding1> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<500x500xf32, #encoding1>>
        return
      }
    }
  }
  stream.executable private @_encoding_2 {
    stream.executable.export public @_encoding_2_encode_500x500xf32_to_500x500xf32 workgroups() -> (index, index, index) {
      %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice()
      stream.return %x, %y, %z : index, index, index
    }
    builtin.module {
      func.func @_encoding_2_encode_500x500xf32_to_500x500xf32(%arg0: !stream.binding {stream.alignment = 64 : index}, %arg1: !stream.binding {stream.alignment = 64 : index}) {
        %c0 = arith.constant 0 : index
        %c2016000 = arith.constant 2016000 : index
        %0 = stream.binding.subspan %arg0[%c0] : !stream.binding -> !iree_tensor_ext.dispatch.tensor<readonly:tensor<500x500xf32>>
        %1 = stream.binding.subspan %arg1[%c2016000] : !stream.binding -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<500x500xf32, #encoding2>>
        %2 = iree_tensor_ext.dispatch.tensor.load %0, offsets = [0, 0], sizes = [500, 500], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<500x500xf32>> -> tensor<500x500xf32>
        %3 = iree_encoding.set_encoding %2 : tensor<500x500xf32> -> tensor<500x500xf32, #encoding2>
        iree_tensor_ext.dispatch.tensor.store %3, %1, offsets = [0, 0], sizes = [500, 500], strides = [1, 1] : tensor<500x500xf32, #encoding2> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<500x500xf32, #encoding2>>
        return
      }
    }
  }
  util.func public @matmul(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "sync func @matmul(%input0: tensor<500x500xf32>, %input1: tensor<500x500xf32>, %input2: tensor<500x500xf32>) -> (%output0: tensor<500x500xf32>)"}} {
    %c3032064 = arith.constant 3032064 : index
    %c0 = arith.constant 0 : index
    %c1000000 = arith.constant 1000000 : index
    %c500 = arith.constant 500 : index
    %element_type_f32 = hal.element_type<f32> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%c500, %c500]) type(%element_type_f32) encoding(%dense_row_major)
    %0 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<500x500xf32> in !stream.resource<external>{%c1000000}
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%c500, %c500]) type(%element_type_f32) encoding(%dense_row_major)
    %1 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<500x500xf32> in !stream.resource<external>{%c1000000}
    hal.buffer_view.assert<%arg2 : !hal.buffer_view> message("input2") shape([%c500, %c500]) type(%element_type_f32) encoding(%dense_row_major)
    %2 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg2 : !hal.buffer_view -> tensor<500x500xf32> in !stream.resource<external>{%c1000000}
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) : !stream.resource<external>{%c1000000} => !stream.timepoint
    %result_0, %result_timepoint_1 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) : !stream.resource<transient>{%c3032064} => !stream.timepoint
    %3 = stream.timepoint.join max(%result_timepoint, %result_timepoint_1) => !stream.timepoint
    %4 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%3) => with(%0 as %arg3: !stream.resource<external>{%c1000000}, %1 as %arg4: !stream.resource<external>{%c1000000}, %2 as %arg5: !stream.resource<external>{%c1000000}, %result as %arg6: !stream.resource<external>{%c1000000}, %result_0 as %arg7: !stream.resource<transient>{%c3032064}) {
      stream.cmd.concurrent {
        stream.cmd.dispatch @_encoding_0::@_encoding_0_encode_500x500xf32_to_500x500xf32 {
          ro %arg3[%c0 for %c1000000] : !stream.resource<external>{%c1000000},
          wo %arg7[%c0 for %c3032064] : !stream.resource<transient>{%c3032064}
        }
        stream.cmd.dispatch @_encoding_1::@_encoding_1_encode_500x500xf32_to_500x500xf32 {
          ro %arg4[%c0 for %c1000000] : !stream.resource<external>{%c1000000},
          wo %arg7[%c0 for %c3032064] : !stream.resource<transient>{%c3032064}
        }
        stream.cmd.dispatch @_encoding_2::@_encoding_2_encode_500x500xf32_to_500x500xf32 {
          ro %arg5[%c0 for %c1000000] : !stream.resource<external>{%c1000000},
          wo %arg7[%c0 for %c3032064] : !stream.resource<transient>{%c3032064}
        }
      }
      stream.cmd.dispatch @matmul_dispatch_0::@matmul_dispatch_0_matmul_like_500x500x500_f32 {
        ro %arg7[%c0 for %c3032064] : !stream.resource<transient>{%c3032064},
        wo %arg6[%c0 for %c1000000] : !stream.resource<external>{%c1000000}
      }
    } => !stream.timepoint
    %5 = stream.resource.dealloca on(#hal.device.affinity<@__device_0>) await(%4) => %result_0 : !stream.resource<transient>{%c3032064} => !stream.timepoint
    %6 = stream.timepoint.await %5 => %result : !stream.resource<external>{%c1000000}
    %7 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %6 : tensor<500x500xf32> in !stream.resource<external>{%c1000000} -> !hal.buffer_view
    util.return %7 : !hal.buffer_view
  }
}


