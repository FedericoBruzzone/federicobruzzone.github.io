// -----// IR Dump After DumpExecutableSourcesPass: iree-hal-dump-executable-sources{path=/tmp/iree/config prefix=configured} //----- //
#config = #iree_cpu.lowering_config<vector_common_parallel = [1, 1, 8, 8]>
#config1 = #iree_cpu.lowering_config<distribution = [7, 7, 0, 0, 0, 0], vector_common_parallel = [1, 1, 0, 8, 8, 0], vector_reduction = [0, 0, 1, 0, 0, 1]>
#config2 = #iree_cpu.lowering_config<vector_common_parallel = [8, 8]>
#config3 = #iree_cpu.lowering_config<distribution = [63, 20], vector_common_parallel = [1, 1]>
#config4 = #iree_cpu.lowering_config<distribution = [3, 63], vector_common_parallel = [1, 1]>
#executable_target_embedded_elf_arm_64 = #hal.executable.target<"llvm-cpu", "embedded-elf-arm_64", {cpu = "apple-m4", cpu_features = "+v8.7a,+aes,+bf16,+complxnum,+crc,+dotprod,+fp-armv8,+fp16fml,+fpac,+fullfp16,+i8mm,+jsconv,+lse,+neon,+pauth,+perfmon,+ras,+rcpc,+rdm,+sha2,+sha3,+sme,+sme-f64f64,+sme-i16i64,+sme2,+reserve-x18", data_layout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128-Fn32", iree.encoding.resolver = #iree_cpu.cpu_encoding_resolver<>, max_stack_allocation_size = 32768 : i64, native_vector_size = 16 : i64, target_triple = "arm64-unknown-unknown-eabi-elf", ukernels = "none"}>
#map = affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>
#pipeline_layout = #hal.pipeline.layout<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>
#translation = #iree_codegen.translation_info<pipeline = #iree_cpu.pipeline<Mmt4dTilingExpert>>
#translation1 = #iree_codegen.translation_info<pipeline = #iree_cpu.pipeline<DataTiling>, {enable_decomposition}>
#device_target_local = #hal.device.target<"local", [#executable_target_embedded_elf_arm_64]> : !hal.device
module attributes {stream.affinity.default = #hal.device.affinity<@__device_0>} {
  util.global private @__device_0 = #device_target_local
  hal.executable private @matmul_dispatch_0 {
    hal.executable.variant public @embedded_elf_arm_64 target(#executable_target_embedded_elf_arm_64) {
      hal.executable.export public @matmul_dispatch_0_matmul_like_500x500x500_f32 ordinal(0) layout(#pipeline_layout) count(%arg0: !hal.device) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice()
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @matmul_dispatch_0_matmul_like_500x500x500_f32() attributes {translation_info = #translation} {
          %cst = arith.constant 0.000000e+00 : f32
          %c0 = arith.constant 0 : index
          %c1008000 = arith.constant 1008000 : index
          %c2016000 = arith.constant 2016000 : index
          %0 = hal.interface.binding.subspan layout(#pipeline_layout) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : memref<63x500x8x1xf32, #hal.descriptor_type<storage_buffer>>
          %1 = hal.interface.binding.subspan layout(#pipeline_layout) binding(0) alignment(64) offset(%c1008000) flags("ReadOnly|Indirect") : memref<63x500x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
          %2 = hal.interface.binding.subspan layout(#pipeline_layout) binding(0) alignment(64) offset(%c2016000) flags("ReadOnly|Indirect") : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
          %3 = hal.interface.binding.subspan layout(#pipeline_layout) binding(1) alignment(64) offset(%c0) flags(Indirect) : memref<500x500xf32, #hal.descriptor_type<storage_buffer>>
          %4 = iree_codegen.load_from_buffer %0 : memref<63x500x8x1xf32, #hal.descriptor_type<storage_buffer>> -> tensor<63x500x8x1xf32>
          %5 = iree_codegen.load_from_buffer %1 : memref<63x500x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>, #hal.descriptor_type<storage_buffer>> -> tensor<63x500x8x1xf32>
          %6 = iree_codegen.load_from_buffer %2 : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>, #hal.descriptor_type<storage_buffer>> -> tensor<63x63x8x8xf32>
          %7 = tensor.empty() : tensor<63x63x8x8xf32>
          %8 = linalg.fill {lowering_config = #config} ins(%cst : f32) outs(%7 : tensor<63x63x8x8xf32>) -> tensor<63x63x8x8xf32>
          %9 = linalg.mmt4d {lowering_config = #config1} ins(%4, %5 : tensor<63x500x8x1xf32>, tensor<63x500x8x1xf32>) outs(%8 : tensor<63x63x8x8xf32>) -> tensor<63x63x8x8xf32>
          %10 = linalg.generic {indexing_maps = [#map, #map, #map], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%9, %6 : tensor<63x63x8x8xf32>, tensor<63x63x8x8xf32>) outs(%7 : tensor<63x63x8x8xf32>) attrs =  {lowering_config = #config} {
          ^bb0(%in: f32, %in_0: f32, %out: f32):
            %12 = arith.addf %in, %in_0 : f32
            linalg.yield %12 : f32
          } -> tensor<63x63x8x8xf32>
          %11 = tensor.empty() : tensor<500x500xf32>
          %unpack = linalg.unpack %10 outer_dims_perm = [0, 1] inner_dims_pos = [0, 1] inner_tiles = [8, 8] into %11 {lowering_config = #config2} : tensor<63x63x8x8xf32> -> tensor<500x500xf32>
          iree_codegen.store_to_buffer %unpack, %3 : tensor<500x500xf32> into memref<500x500xf32, #hal.descriptor_type<storage_buffer>>
          return
        }
        iree_codegen.dispatch_config @matmul_dispatch_0_matmul_like_500x500x500_f32 {
        ^bb0(%arg0: !hal.device):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice()
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  hal.executable private @_encoding_0 {
    hal.executable.variant public @embedded_elf_arm_64 target(#executable_target_embedded_elf_arm_64) {
      hal.executable.export public @_encoding_0_encode_500x500xf32_to_500x500xf32 ordinal(0) layout(#pipeline_layout) count(%arg0: !hal.device) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice()
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @_encoding_0_encode_500x500xf32_to_500x500xf32() attributes {translation_info = #translation1} {
          %cst = arith.constant 0.000000e+00 : f32
          %c0 = arith.constant 0 : index
          %0 = hal.interface.binding.subspan layout(#pipeline_layout) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : memref<500x500xf32, #hal.descriptor_type<storage_buffer>>
          %1 = hal.interface.binding.subspan layout(#pipeline_layout) binding(1) alignment(64) offset(%c0) flags(Indirect) : memref<63x500x8x1xf32, #hal.descriptor_type<storage_buffer>>
          %2 = iree_codegen.load_from_buffer %0 : memref<500x500xf32, #hal.descriptor_type<storage_buffer>> -> tensor<500x500xf32>
          %3 = tensor.empty() : tensor<63x500x8x1xf32>
          %pack = linalg.pack %2 padding_value(%cst : f32) outer_dims_perm = [0, 1] inner_dims_pos = [0, 1] inner_tiles = [8, 1] into %3 {lowering_config = #config3} : tensor<500x500xf32> -> tensor<63x500x8x1xf32>
          iree_codegen.store_to_buffer %pack, %1 : tensor<63x500x8x1xf32> into memref<63x500x8x1xf32, #hal.descriptor_type<storage_buffer>>
          return
        }
        iree_codegen.dispatch_config @_encoding_0_encode_500x500xf32_to_500x500xf32 {
        ^bb0(%arg0: !hal.device):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice()
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  hal.executable private @_encoding_1 {
    hal.executable.variant public @embedded_elf_arm_64 target(#executable_target_embedded_elf_arm_64) {
      hal.executable.export public @_encoding_1_encode_500x500xf32_to_500x500xf32 ordinal(0) layout(#pipeline_layout) count(%arg0: !hal.device) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice()
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @_encoding_1_encode_500x500xf32_to_500x500xf32() attributes {translation_info = #translation1} {
          %cst = arith.constant 0.000000e+00 : f32
          %c0 = arith.constant 0 : index
          %c1008000 = arith.constant 1008000 : index
          %0 = hal.interface.binding.subspan layout(#pipeline_layout) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : memref<500x500xf32, #hal.descriptor_type<storage_buffer>>
          %1 = hal.interface.binding.subspan layout(#pipeline_layout) binding(1) alignment(64) offset(%c1008000) flags(Indirect) : memref<63x500x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
          %2 = iree_codegen.load_from_buffer %0 : memref<500x500xf32, #hal.descriptor_type<storage_buffer>> -> tensor<500x500xf32>
          %3 = tensor.empty() : tensor<63x500x8x1xf32>
          %pack = linalg.pack %2 padding_value(%cst : f32) outer_dims_perm = [1, 0] inner_dims_pos = [1, 0] inner_tiles = [8, 1] into %3 {lowering_config = #config3} : tensor<500x500xf32> -> tensor<63x500x8x1xf32>
          iree_codegen.store_to_buffer %pack, %1 : tensor<63x500x8x1xf32> into memref<63x500x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
          return
        }
        iree_codegen.dispatch_config @_encoding_1_encode_500x500xf32_to_500x500xf32 {
        ^bb0(%arg0: !hal.device):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice()
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  hal.executable private @_encoding_2 {
    hal.executable.variant public @embedded_elf_arm_64 target(#executable_target_embedded_elf_arm_64) {
      hal.executable.export public @_encoding_2_encode_500x500xf32_to_500x500xf32 ordinal(0) layout(#pipeline_layout) count(%arg0: !hal.device) -> (index, index, index) {
        %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice()
        hal.return %x, %y, %z : index, index, index
      }
      builtin.module {
        func.func @_encoding_2_encode_500x500xf32_to_500x500xf32() attributes {translation_info = #translation1} {
          %cst = arith.constant 0.000000e+00 : f32
          %c0 = arith.constant 0 : index
          %c2016000 = arith.constant 2016000 : index
          %0 = hal.interface.binding.subspan layout(#pipeline_layout) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : memref<500x500xf32, #hal.descriptor_type<storage_buffer>>
          %1 = hal.interface.binding.subspan layout(#pipeline_layout) binding(1) alignment(64) offset(%c2016000) flags(Indirect) : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
          %2 = iree_codegen.load_from_buffer %0 : memref<500x500xf32, #hal.descriptor_type<storage_buffer>> -> tensor<500x500xf32>
          %3 = tensor.empty() : tensor<63x63x8x8xf32>
          %pack = linalg.pack %2 padding_value(%cst : f32) outer_dims_perm = [0, 1] inner_dims_pos = [0, 1] inner_tiles = [8, 8] into %3 {lowering_config = #config4} : tensor<500x500xf32> -> tensor<63x63x8x8xf32>
          iree_codegen.store_to_buffer %pack, %1 : tensor<63x63x8x8xf32> into memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
          return
        }
        iree_codegen.dispatch_config @_encoding_2_encode_500x500xf32_to_500x500xf32 {
        ^bb0(%arg0: !hal.device):
          %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice()
          iree_codegen.yield %x, %y, %z : index, index, index
        }
      }
    }
  }
  util.func public @matmul(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "sync func @matmul(%input0: tensor<500x500xf32>, %input1: tensor<500x500xf32>, %input2: tensor<500x500xf32>) -> (%output0: tensor<500x500xf32>)"}} {
    %c3032064 = arith.constant 3032064 : index
    %c0 = arith.constant 0 : index
    %c1000000 = arith.constant 1000000 : index
    %c500 = arith.constant 500 : index
    %element_type_f32 = hal.element_type<f32> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%c500, %c500]) type(%element_type_f32) encoding(%dense_row_major)
    %0 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<500x500xf32> in !stream.resource<external>{%c1000000}
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%c500, %c500]) type(%element_type_f32) encoding(%dense_row_major)
    %1 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<500x500xf32> in !stream.resource<external>{%c1000000}
    hal.buffer_view.assert<%arg2 : !hal.buffer_view> message("input2") shape([%c500, %c500]) type(%element_type_f32) encoding(%dense_row_major)
    %2 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg2 : !hal.buffer_view -> tensor<500x500xf32> in !stream.resource<external>{%c1000000}
    %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) : !stream.resource<external>{%c1000000} => !stream.timepoint
    %result_0, %result_timepoint_1 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) : !stream.resource<transient>{%c3032064} => !stream.timepoint
    %3 = stream.timepoint.join max(%result_timepoint, %result_timepoint_1) => !stream.timepoint
    %4 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%3) => with(%0 as %arg3: !stream.resource<external>{%c1000000}, %1 as %arg4: !stream.resource<external>{%c1000000}, %2 as %arg5: !stream.resource<external>{%c1000000}, %result as %arg6: !stream.resource<external>{%c1000000}, %result_0 as %arg7: !stream.resource<transient>{%c3032064}) {
      stream.cmd.concurrent {
        stream.cmd.dispatch @_encoding_0::@embedded_elf_arm_64::@_encoding_0_encode_500x500xf32_to_500x500xf32 {
          ro %arg3[%c0 for %c1000000] : !stream.resource<external>{%c1000000},
          wo %arg7[%c0 for %c3032064] : !stream.resource<transient>{%c3032064}
        }
        stream.cmd.dispatch @_encoding_1::@embedded_elf_arm_64::@_encoding_1_encode_500x500xf32_to_500x500xf32 {
          ro %arg4[%c0 for %c1000000] : !stream.resource<external>{%c1000000},
          wo %arg7[%c0 for %c3032064] : !stream.resource<transient>{%c3032064}
        }
        stream.cmd.dispatch @_encoding_2::@embedded_elf_arm_64::@_encoding_2_encode_500x500xf32_to_500x500xf32 {
          ro %arg5[%c0 for %c1000000] : !stream.resource<external>{%c1000000},
          wo %arg7[%c0 for %c3032064] : !stream.resource<transient>{%c3032064}
        }
      }
      stream.cmd.dispatch @matmul_dispatch_0::@embedded_elf_arm_64::@matmul_dispatch_0_matmul_like_500x500x500_f32 {
        ro %arg7[%c0 for %c3032064] : !stream.resource<transient>{%c3032064},
        wo %arg6[%c0 for %c1000000] : !stream.resource<external>{%c1000000}
      }
    } => !stream.timepoint
    %5 = stream.resource.dealloca on(#hal.device.affinity<@__device_0>) await(%4) => %result_0 : !stream.resource<transient>{%c3032064} => !stream.timepoint
    %6 = stream.timepoint.await %5 => %result : !stream.resource<external>{%c1000000}
    %7 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %6 : tensor<500x500xf32> in !stream.resource<external>{%c1000000} -> !hal.buffer_view
    util.return %7 : !hal.buffer_view
  }
}


