// -----// IR Dump After AssignLegacyTargetDevicesPass: iree-hal-assign-legacy-target-devices{target-registry=1 targetBackends={llvm-cpu}} //----- //
#executable_target_embedded_elf_arm_64 = #hal.executable.target<"llvm-cpu", "embedded-elf-arm_64", {cpu = "apple-m4", cpu_features = "+v8.7a,+aes,+bf16,+complxnum,+crc,+dotprod,+fp-armv8,+fp16fml,+fpac,+fullfp16,+i8mm,+jsconv,+lse,+neon,+pauth,+perfmon,+ras,+rcpc,+rdm,+sha2,+sha3,+sme,+sme-f64f64,+sme-i16i64,+sme2,+reserve-x18", data_layout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128-Fn32", iree.encoding.resolver = #iree_cpu.cpu_encoding_resolver<>, max_stack_allocation_size = 32768 : i64, native_vector_size = 16 : i64, target_triple = "arm64-unknown-unknown-eabi-elf", ukernels = "none"}>
#device_target_local = #hal.device.target<"local", [#executable_target_embedded_elf_arm_64]> : !hal.device
module attributes {hal.device.targets = [#device_target_local]} {
  util.func public @matmul(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "sync func @matmul(%input0: tensor<500x500xf32>, %input1: tensor<500x500xf32>, %input2: tensor<500x500xf32>) -> (%output0: tensor<500x500xf32>)"}} {
    %0 = hal.tensor.import %arg0 "input0" : !hal.buffer_view -> tensor<500x500xf32>
    %1 = hal.tensor.import %arg1 "input1" : !hal.buffer_view -> tensor<500x500xf32>
    %2 = hal.tensor.import %arg2 "input2" : !hal.buffer_view -> tensor<500x500xf32>
    %3 = linalg.matmul ins(%0, %1 : tensor<500x500xf32>, tensor<500x500xf32>) outs(%2 : tensor<500x500xf32>) -> tensor<500x500xf32>
    %4 = hal.tensor.export %3 "output0" : tensor<500x500xf32> -> !hal.buffer_view
    util.return %4 : !hal.buffer_view
  }
}


