// -----// IR Dump After IREEAffineExpandIndexOpsPass: iree-affine-expand-index-ops //----- //
#executable_target_embedded_elf_arm_64 = #hal.executable.target<"llvm-cpu", "embedded-elf-arm_64", {cpu = "apple-m4", cpu_features = "+v8.7a,+aes,+bf16,+complxnum,+crc,+dotprod,+fp-armv8,+fp16fml,+fpac,+fullfp16,+i8mm,+jsconv,+lse,+neon,+pauth,+perfmon,+ras,+rcpc,+rdm,+sha2,+sha3,+sme,+sme-f64f64,+sme-i16i64,+sme2,+reserve-x18", data_layout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128-Fn32", iree.encoding.resolver = #iree_cpu.cpu_encoding_resolver<>, max_stack_allocation_size = 32768 : i64, native_vector_size = 16 : i64, target_triple = "arm64-unknown-unknown-eabi-elf", ukernels = "none"}>
#pipeline_layout = #hal.pipeline.layout<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>
module {
  hal.executable private @matmul_500_linked {
    hal.executable.variant public @embedded_elf_arm_64 target(#executable_target_embedded_elf_arm_64) {
      hal.executable.export public @matmul_dispatch_0_matmul_like_500x500x500_f32 ordinal(0) layout(#pipeline_layout) attributes {workgroup_size = [1 : index, 1 : index, 1 : index]}
      hal.executable.export public @_encoding_0_encode_500x500xf32_to_500x500xf32 ordinal(1) layout(#pipeline_layout) attributes {workgroup_size = [1 : index, 1 : index, 1 : index]}
      hal.executable.export public @_encoding_1_encode_500x500xf32_to_500x500xf32 ordinal(2) layout(#pipeline_layout) attributes {workgroup_size = [1 : index, 1 : index, 1 : index]}
      hal.executable.export public @_encoding_2_encode_500x500xf32_to_500x500xf32 ordinal(3) layout(#pipeline_layout) attributes {workgroup_size = [1 : index, 1 : index, 1 : index]}
      builtin.module {
        llvm.func @matmul_dispatch_0_matmul_like_500x500x500_f32(%arg0: !llvm.ptr {llvm.align = 16 : i64, llvm.noalias, llvm.nonnull, llvm.noundef}, %arg1: !llvm.ptr {llvm.align = 16 : i64, llvm.noalias, llvm.nonnull, llvm.noundef}, %arg2: !llvm.ptr {llvm.align = 16 : i64, llvm.noalias, llvm.nonnull, llvm.noundef}) -> i32 {
          %0 = llvm.mlir.poison : vector<8xi64>
          %1 = llvm.mlir.constant(7 : i64) : i64
          %2 = llvm.mlir.constant(6 : i64) : i64
          %3 = llvm.mlir.constant(5 : i64) : i64
          %4 = llvm.mlir.constant(4 : i64) : i64
          %5 = llvm.mlir.constant(3 : i64) : i64
          %6 = llvm.mlir.constant(2 : i64) : i64
          %7 = llvm.mlir.constant(1 : i64) : i64
          %8 = llvm.mlir.constant(0 : i32) : i32
          %9 = llvm.mlir.poison : vector<8xf32>
          %10 = llvm.mlir.constant(4032 : index) : i64
          %11 = llvm.mlir.constant(0 : i64) : i64
          %12 = llvm.mlir.constant(64 : index) : i64
          %13 = llvm.mlir.constant(true) : i1
          %14 = llvm.mlir.constant(4000 : index) : i64
          %15 = llvm.mlir.constant(dense<false> : vector<8xi1>) : vector<8xi1>
          %16 = llvm.mlir.constant(dense<[0, 1, 2, 3, 4, 5, 6, 7]> : vector<8xi64>) : vector<8xi64>
          %17 = llvm.mlir.poison : !llvm.array<8 x vector<8xf32>>
          %18 = llvm.mlir.constant(-8 : index) : i64
          %19 = llvm.mlir.constant(8 : index) : i64
          %20 = llvm.mlir.constant(7 : index) : i64
          %21 = llvm.mlir.constant(6 : index) : i64
          %22 = llvm.mlir.constant(5 : index) : i64
          %23 = llvm.mlir.constant(4 : index) : i64
          %24 = llvm.mlir.constant(3 : index) : i64
          %25 = llvm.mlir.constant(2 : index) : i64
          %26 = llvm.mlir.constant(dense<0.000000e+00> : vector<8x8xf32>) : !llvm.array<8 x vector<8xf32>>
          %27 = llvm.mlir.constant(63 : index) : i64
          %28 = llvm.mlir.constant(1 : index) : i64
          %29 = llvm.mlir.constant(500 : index) : i64
          %30 = llvm.mlir.constant(0 : index) : i64
          %31 = llvm.load %arg1 : !llvm.ptr -> !llvm.struct<"iree_hal_executable_dispatch_state_v0_t", (i32, i32, i16, i16, i32, i32, i16, i8, i8, ptr, ptr, ptr)>
          %32 = llvm.extractvalue %31[10] : !llvm.struct<"iree_hal_executable_dispatch_state_v0_t", (i32, i32, i16, i16, i32, i32, i16, i8, i8, ptr, ptr, ptr)> 
          %33 = llvm.load %32 : !llvm.ptr -> !llvm.ptr
          llvm.intr.assume %13 ["align"(%33, %12 : !llvm.ptr, i64)] : i1
          %34 = llvm.load %arg1 : !llvm.ptr -> !llvm.struct<"iree_hal_executable_dispatch_state_v0_t", (i32, i32, i16, i16, i32, i32, i16, i8, i8, ptr, ptr, ptr)>
          %35 = llvm.extractvalue %34[10] : !llvm.struct<"iree_hal_executable_dispatch_state_v0_t", (i32, i32, i16, i16, i32, i32, i16, i8, i8, ptr, ptr, ptr)> 
          %36 = llvm.load %35 : !llvm.ptr -> !llvm.ptr
          %37 = llvm.getelementptr %36[1008000] : (!llvm.ptr) -> !llvm.ptr, i8
          llvm.intr.assume %13 ["align"(%37, %12 : !llvm.ptr, i64)] : i1
          %38 = llvm.load %arg1 : !llvm.ptr -> !llvm.struct<"iree_hal_executable_dispatch_state_v0_t", (i32, i32, i16, i16, i32, i32, i16, i8, i8, ptr, ptr, ptr)>
          %39 = llvm.extractvalue %38[10] : !llvm.struct<"iree_hal_executable_dispatch_state_v0_t", (i32, i32, i16, i16, i32, i32, i16, i8, i8, ptr, ptr, ptr)> 
          %40 = llvm.load %39 : !llvm.ptr -> !llvm.ptr
          %41 = llvm.getelementptr %40[2016000] : (!llvm.ptr) -> !llvm.ptr, i8
          llvm.intr.assume %13 ["align"(%41, %12 : !llvm.ptr, i64)] : i1
          %42 = llvm.load %arg1 : !llvm.ptr -> !llvm.struct<"iree_hal_executable_dispatch_state_v0_t", (i32, i32, i16, i16, i32, i32, i16, i8, i8, ptr, ptr, ptr)>
          %43 = llvm.extractvalue %42[10] : !llvm.struct<"iree_hal_executable_dispatch_state_v0_t", (i32, i32, i16, i16, i32, i32, i16, i8, i8, ptr, ptr, ptr)> 
          %44 = llvm.getelementptr %43[1] : (!llvm.ptr) -> !llvm.ptr, !llvm.ptr
          %45 = llvm.load %44 : !llvm.ptr -> !llvm.ptr
          llvm.intr.assume %13 ["align"(%45, %12 : !llvm.ptr, i64)] : i1
          llvm.br ^bb1(%30 : i64)
        ^bb1(%46: i64):  // 2 preds: ^bb0, ^bb7
          %47 = llvm.icmp "slt" %46, %27 : i64
          llvm.cond_br %47, ^bb2, ^bb8
        ^bb2:  // pred: ^bb1
          %48 = llvm.mul %46, %19 overflow<nsw> : i64
          %49 = llvm.mul %46, %18 overflow<nsw> : i64
          %50 = llvm.add %49, %29 : i64
          %51 = llvm.intr.smin(%50, %19) : (i64, i64) -> i64
          llvm.br ^bb3(%30 : i64)
        ^bb3(%52: i64):  // 2 preds: ^bb2, ^bb6
          %53 = llvm.icmp "slt" %52, %27 : i64
          llvm.cond_br %53, ^bb4(%30, %26 : i64, !llvm.array<8 x vector<8xf32>>), ^bb7
        ^bb4(%54: i64, %55: !llvm.array<8 x vector<8xf32>>):  // 2 preds: ^bb3, ^bb5
          %56 = llvm.icmp "slt" %54, %29 : i64
          llvm.cond_br %56, ^bb5, ^bb6
        ^bb5:  // pred: ^bb4
          %57 = llvm.mul %46, %14 : i64
          %58 = llvm.mul %54, %19 : i64
          %59 = llvm.add %57, %58 : i64
          %60 = llvm.add %59, %30 : i64
          %61 = llvm.add %60, %30 : i64
          %62 = llvm.getelementptr %33[%61] : (!llvm.ptr, i64) -> !llvm.ptr, f32
          %63 = llvm.load %62 {alignment = 4 : i64} : !llvm.ptr -> vector<8xf32>
          %64 = llvm.mul %52, %14 : i64
          %65 = llvm.add %64, %58 : i64
          %66 = llvm.add %65, %30 : i64
          %67 = llvm.add %66, %30 : i64
          %68 = llvm.getelementptr %37[%67] : (!llvm.ptr, i64) -> !llvm.ptr, f32
          %69 = llvm.load %68 {alignment = 4 : i64} : !llvm.ptr -> vector<8xf32>
          %70 = llvm.extractelement %63[%11 : i64] : vector<8xf32>
          %71 = llvm.insertelement %70, %9[%8 : i32] : vector<8xf32>
          %72 = llvm.shufflevector %71, %9 [0, 0, 0, 0, 0, 0, 0, 0] : vector<8xf32> 
          %73 = llvm.extractvalue %55[0] : !llvm.array<8 x vector<8xf32>> 
          %74 = llvm.intr.fmuladd(%72, %69, %73) : (vector<8xf32>, vector<8xf32>, vector<8xf32>) -> vector<8xf32>
          %75 = llvm.extractelement %63[%7 : i64] : vector<8xf32>
          %76 = llvm.insertelement %75, %9[%8 : i32] : vector<8xf32>
          %77 = llvm.shufflevector %76, %9 [0, 0, 0, 0, 0, 0, 0, 0] : vector<8xf32> 
          %78 = llvm.extractvalue %55[1] : !llvm.array<8 x vector<8xf32>> 
          %79 = llvm.intr.fmuladd(%77, %69, %78) : (vector<8xf32>, vector<8xf32>, vector<8xf32>) -> vector<8xf32>
          %80 = llvm.extractelement %63[%6 : i64] : vector<8xf32>
          %81 = llvm.insertelement %80, %9[%8 : i32] : vector<8xf32>
          %82 = llvm.shufflevector %81, %9 [0, 0, 0, 0, 0, 0, 0, 0] : vector<8xf32> 
          %83 = llvm.extractvalue %55[2] : !llvm.array<8 x vector<8xf32>> 
          %84 = llvm.intr.fmuladd(%82, %69, %83) : (vector<8xf32>, vector<8xf32>, vector<8xf32>) -> vector<8xf32>
          %85 = llvm.extractelement %63[%5 : i64] : vector<8xf32>
          %86 = llvm.insertelement %85, %9[%8 : i32] : vector<8xf32>
          %87 = llvm.shufflevector %86, %9 [0, 0, 0, 0, 0, 0, 0, 0] : vector<8xf32> 
          %88 = llvm.extractvalue %55[3] : !llvm.array<8 x vector<8xf32>> 
          %89 = llvm.intr.fmuladd(%87, %69, %88) : (vector<8xf32>, vector<8xf32>, vector<8xf32>) -> vector<8xf32>
          %90 = llvm.extractelement %63[%4 : i64] : vector<8xf32>
          %91 = llvm.insertelement %90, %9[%8 : i32] : vector<8xf32>
          %92 = llvm.shufflevector %91, %9 [0, 0, 0, 0, 0, 0, 0, 0] : vector<8xf32> 
          %93 = llvm.extractvalue %55[4] : !llvm.array<8 x vector<8xf32>> 
          %94 = llvm.intr.fmuladd(%92, %69, %93) : (vector<8xf32>, vector<8xf32>, vector<8xf32>) -> vector<8xf32>
          %95 = llvm.extractelement %63[%3 : i64] : vector<8xf32>
          %96 = llvm.insertelement %95, %9[%8 : i32] : vector<8xf32>
          %97 = llvm.shufflevector %96, %9 [0, 0, 0, 0, 0, 0, 0, 0] : vector<8xf32> 
          %98 = llvm.extractvalue %55[5] : !llvm.array<8 x vector<8xf32>> 
          %99 = llvm.intr.fmuladd(%97, %69, %98) : (vector<8xf32>, vector<8xf32>, vector<8xf32>) -> vector<8xf32>
          %100 = llvm.extractelement %63[%2 : i64] : vector<8xf32>
          %101 = llvm.insertelement %100, %9[%8 : i32] : vector<8xf32>
          %102 = llvm.shufflevector %101, %9 [0, 0, 0, 0, 0, 0, 0, 0] : vector<8xf32> 
          %103 = llvm.extractvalue %55[6] : !llvm.array<8 x vector<8xf32>> 
          %104 = llvm.intr.fmuladd(%102, %69, %103) : (vector<8xf32>, vector<8xf32>, vector<8xf32>) -> vector<8xf32>
          %105 = llvm.extractelement %63[%1 : i64] : vector<8xf32>
          %106 = llvm.insertelement %105, %9[%8 : i32] : vector<8xf32>
          %107 = llvm.shufflevector %106, %9 [0, 0, 0, 0, 0, 0, 0, 0] : vector<8xf32> 
          %108 = llvm.extractvalue %55[7] : !llvm.array<8 x vector<8xf32>> 
          %109 = llvm.intr.fmuladd(%107, %69, %108) : (vector<8xf32>, vector<8xf32>, vector<8xf32>) -> vector<8xf32>
          %110 = llvm.insertvalue %74, %17[0] : !llvm.array<8 x vector<8xf32>> 
          %111 = llvm.insertvalue %79, %110[1] : !llvm.array<8 x vector<8xf32>> 
          %112 = llvm.insertvalue %84, %111[2] : !llvm.array<8 x vector<8xf32>> 
          %113 = llvm.insertvalue %89, %112[3] : !llvm.array<8 x vector<8xf32>> 
          %114 = llvm.insertvalue %94, %113[4] : !llvm.array<8 x vector<8xf32>> 
          %115 = llvm.insertvalue %99, %114[5] : !llvm.array<8 x vector<8xf32>> 
          %116 = llvm.insertvalue %104, %115[6] : !llvm.array<8 x vector<8xf32>> 
          %117 = llvm.insertvalue %109, %116[7] : !llvm.array<8 x vector<8xf32>> 
          %118 = llvm.add %54, %28 : i64
          llvm.br ^bb4(%118, %117 : i64, !llvm.array<8 x vector<8xf32>>)
        ^bb6:  // pred: ^bb4
          %119 = llvm.mul %46, %10 : i64
          %120 = llvm.mul %52, %12 : i64
          %121 = llvm.add %119, %120 : i64
          %122 = llvm.mul %30, %19 : i64
          %123 = llvm.add %121, %122 : i64
          %124 = llvm.add %123, %30 : i64
          %125 = llvm.getelementptr %41[%124] : (!llvm.ptr, i64) -> !llvm.ptr, f32
          %126 = llvm.load %125 {alignment = 4 : i64} : !llvm.ptr -> vector<8xf32>
          %127 = llvm.mul %28, %19 : i64
          %128 = llvm.add %121, %127 : i64
          %129 = llvm.add %128, %30 : i64
          %130 = llvm.getelementptr %41[%129] : (!llvm.ptr, i64) -> !llvm.ptr, f32
          %131 = llvm.load %130 {alignment = 4 : i64} : !llvm.ptr -> vector<8xf32>
          %132 = llvm.mul %25, %19 : i64
          %133 = llvm.add %121, %132 : i64
          %134 = llvm.add %133, %30 : i64
          %135 = llvm.getelementptr %41[%134] : (!llvm.ptr, i64) -> !llvm.ptr, f32
          %136 = llvm.load %135 {alignment = 4 : i64} : !llvm.ptr -> vector<8xf32>
          %137 = llvm.mul %24, %19 : i64
          %138 = llvm.add %121, %137 : i64
          %139 = llvm.add %138, %30 : i64
          %140 = llvm.getelementptr %41[%139] : (!llvm.ptr, i64) -> !llvm.ptr, f32
          %141 = llvm.load %140 {alignment = 4 : i64} : !llvm.ptr -> vector<8xf32>
          %142 = llvm.mul %23, %19 : i64
          %143 = llvm.add %121, %142 : i64
          %144 = llvm.add %143, %30 : i64
          %145 = llvm.getelementptr %41[%144] : (!llvm.ptr, i64) -> !llvm.ptr, f32
          %146 = llvm.load %145 {alignment = 4 : i64} : !llvm.ptr -> vector<8xf32>
          %147 = llvm.mul %22, %19 : i64
          %148 = llvm.add %121, %147 : i64
          %149 = llvm.add %148, %30 : i64
          %150 = llvm.getelementptr %41[%149] : (!llvm.ptr, i64) -> !llvm.ptr, f32
          %151 = llvm.load %150 {alignment = 4 : i64} : !llvm.ptr -> vector<8xf32>
          %152 = llvm.mul %21, %19 : i64
          %153 = llvm.add %121, %152 : i64
          %154 = llvm.add %153, %30 : i64
          %155 = llvm.getelementptr %41[%154] : (!llvm.ptr, i64) -> !llvm.ptr, f32
          %156 = llvm.load %155 {alignment = 4 : i64} : !llvm.ptr -> vector<8xf32>
          %157 = llvm.mul %20, %19 : i64
          %158 = llvm.add %121, %157 : i64
          %159 = llvm.add %158, %30 : i64
          %160 = llvm.getelementptr %41[%159] : (!llvm.ptr, i64) -> !llvm.ptr, f32
          %161 = llvm.load %160 {alignment = 4 : i64} : !llvm.ptr -> vector<8xf32>
          %162 = llvm.extractvalue %55[0] : !llvm.array<8 x vector<8xf32>> 
          %163 = llvm.fadd %162, %126 {fastmathFlags = #llvm.fastmath<contract>} : vector<8xf32>
          %164 = llvm.extractvalue %55[1] : !llvm.array<8 x vector<8xf32>> 
          %165 = llvm.fadd %164, %131 {fastmathFlags = #llvm.fastmath<contract>} : vector<8xf32>
          %166 = llvm.extractvalue %55[2] : !llvm.array<8 x vector<8xf32>> 
          %167 = llvm.fadd %166, %136 {fastmathFlags = #llvm.fastmath<contract>} : vector<8xf32>
          %168 = llvm.extractvalue %55[3] : !llvm.array<8 x vector<8xf32>> 
          %169 = llvm.fadd %168, %141 {fastmathFlags = #llvm.fastmath<contract>} : vector<8xf32>
          %170 = llvm.extractvalue %55[4] : !llvm.array<8 x vector<8xf32>> 
          %171 = llvm.fadd %170, %146 {fastmathFlags = #llvm.fastmath<contract>} : vector<8xf32>
          %172 = llvm.extractvalue %55[5] : !llvm.array<8 x vector<8xf32>> 
          %173 = llvm.fadd %172, %151 {fastmathFlags = #llvm.fastmath<contract>} : vector<8xf32>
          %174 = llvm.extractvalue %55[6] : !llvm.array<8 x vector<8xf32>> 
          %175 = llvm.fadd %174, %156 {fastmathFlags = #llvm.fastmath<contract>} : vector<8xf32>
          %176 = llvm.extractvalue %55[7] : !llvm.array<8 x vector<8xf32>> 
          %177 = llvm.fadd %176, %161 {fastmathFlags = #llvm.fastmath<contract>} : vector<8xf32>
          %178 = llvm.mul %52, %19 overflow<nsw> : i64
          %179 = llvm.mul %52, %18 overflow<nsw> : i64
          %180 = llvm.add %179, %29 : i64
          %181 = llvm.intr.smin(%180, %19) : (i64, i64) -> i64
          %182 = llvm.insertelement %181, %0[%8 : i32] : vector<8xi64>
          %183 = llvm.shufflevector %182, %0 [0, 0, 0, 0, 0, 0, 0, 0] : vector<8xi64> 
          %184 = llvm.icmp "sgt" %183, %16 : vector<8xi64>
          %185 = llvm.icmp "sgt" %51, %30 : i64
          %186 = llvm.select %185, %184, %15 : i1, vector<8xi1>
          %187 = llvm.icmp "sgt" %51, %28 : i64
          %188 = llvm.select %187, %184, %15 : i1, vector<8xi1>
          %189 = llvm.icmp "sgt" %51, %25 : i64
          %190 = llvm.select %189, %184, %15 : i1, vector<8xi1>
          %191 = llvm.icmp "sgt" %51, %24 : i64
          %192 = llvm.select %191, %184, %15 : i1, vector<8xi1>
          %193 = llvm.icmp "sgt" %51, %23 : i64
          %194 = llvm.select %193, %184, %15 : i1, vector<8xi1>
          %195 = llvm.icmp "sgt" %51, %22 : i64
          %196 = llvm.select %195, %184, %15 : i1, vector<8xi1>
          %197 = llvm.icmp "sgt" %51, %21 : i64
          %198 = llvm.select %197, %184, %15 : i1, vector<8xi1>
          %199 = llvm.icmp "sgt" %51, %20 : i64
          %200 = llvm.select %199, %184, %15 : i1, vector<8xi1>
          %201 = llvm.mul %48, %29 : i64
          %202 = llvm.add %201, %178 : i64
          %203 = llvm.getelementptr %45[%202] : (!llvm.ptr, i64) -> !llvm.ptr, f32
          llvm.intr.masked.store %163, %203, %186 {alignment = 4 : i32} : vector<8xf32>, vector<8xi1> into !llvm.ptr
          %204 = llvm.add %48, %28 : i64
          %205 = llvm.mul %204, %29 : i64
          %206 = llvm.add %205, %178 : i64
          %207 = llvm.getelementptr %45[%206] : (!llvm.ptr, i64) -> !llvm.ptr, f32
          llvm.intr.masked.store %165, %207, %188 {alignment = 4 : i32} : vector<8xf32>, vector<8xi1> into !llvm.ptr
          %208 = llvm.add %48, %25 : i64
          %209 = llvm.mul %208, %29 : i64
          %210 = llvm.add %209, %178 : i64
          %211 = llvm.getelementptr %45[%210] : (!llvm.ptr, i64) -> !llvm.ptr, f32
          llvm.intr.masked.store %167, %211, %190 {alignment = 4 : i32} : vector<8xf32>, vector<8xi1> into !llvm.ptr
          %212 = llvm.add %48, %24 : i64
          %213 = llvm.mul %212, %29 : i64
          %214 = llvm.add %213, %178 : i64
          %215 = llvm.getelementptr %45[%214] : (!llvm.ptr, i64) -> !llvm.ptr, f32
          llvm.intr.masked.store %169, %215, %192 {alignment = 4 : i32} : vector<8xf32>, vector<8xi1> into !llvm.ptr
          %216 = llvm.add %48, %23 : i64
          %217 = llvm.mul %216, %29 : i64
          %218 = llvm.add %217, %178 : i64
          %219 = llvm.getelementptr %45[%218] : (!llvm.ptr, i64) -> !llvm.ptr, f32
          llvm.intr.masked.store %171, %219, %194 {alignment = 4 : i32} : vector<8xf32>, vector<8xi1> into !llvm.ptr
          %220 = llvm.add %48, %22 : i64
          %221 = llvm.mul %220, %29 : i64
          %222 = llvm.add %221, %178 : i64
          %223 = llvm.getelementptr %45[%222] : (!llvm.ptr, i64) -> !llvm.ptr, f32
          llvm.intr.masked.store %173, %223, %196 {alignment = 4 : i32} : vector<8xf32>, vector<8xi1> into !llvm.ptr
          %224 = llvm.add %48, %21 : i64
          %225 = llvm.mul %224, %29 : i64
          %226 = llvm.add %225, %178 : i64
          %227 = llvm.getelementptr %45[%226] : (!llvm.ptr, i64) -> !llvm.ptr, f32
          llvm.intr.masked.store %175, %227, %198 {alignment = 4 : i32} : vector<8xf32>, vector<8xi1> into !llvm.ptr
          %228 = llvm.add %48, %20 : i64
          %229 = llvm.mul %228, %29 : i64
          %230 = llvm.add %229, %178 : i64
          %231 = llvm.getelementptr %45[%230] : (!llvm.ptr, i64) -> !llvm.ptr, f32
          llvm.intr.masked.store %177, %231, %200 {alignment = 4 : i32} : vector<8xf32>, vector<8xi1> into !llvm.ptr
          %232 = llvm.add %52, %28 : i64
          llvm.br ^bb3(%232 : i64)
        ^bb7:  // pred: ^bb3
          %233 = llvm.add %46, %28 : i64
          llvm.br ^bb1(%233 : i64)
        ^bb8:  // pred: ^bb1
          llvm.return %8 : i32
        }
        llvm.func @_encoding_0_encode_500x500xf32_to_500x500xf32(%arg0: !llvm.ptr {llvm.align = 16 : i64, llvm.noalias, llvm.nonnull, llvm.noundef}, %arg1: !llvm.ptr {llvm.align = 16 : i64, llvm.noalias, llvm.nonnull, llvm.noundef}, %arg2: !llvm.ptr {llvm.align = 16 : i64, llvm.noalias, llvm.nonnull, llvm.noundef}) -> i32 {
          %0 = llvm.mlir.constant(0 : i32) : i32
          %1 = llvm.mlir.poison : vector<8xi32>
          %2 = llvm.mlir.constant(4000 : index) : i64
          %3 = llvm.mlir.constant(64 : index) : i64
          %4 = llvm.mlir.constant(true) : i1
          %5 = llvm.mlir.constant(-8 : index) : i64
          %6 = llvm.mlir.constant(dense<0.000000e+00> : vector<8xf32>) : vector<8xf32>
          %7 = llvm.mlir.constant(8 : index) : i64
          %8 = llvm.mlir.constant(2147483647 : index) : i64
          %9 = llvm.mlir.constant(dense<[0, 1, 2, 3, 4, 5, 6, 7]> : vector<8xi32>) : vector<8xi32>
          %10 = llvm.mlir.constant(1 : index) : i64
          %11 = llvm.mlir.constant(500 : index) : i64
          %12 = llvm.mlir.constant(63 : index) : i64
          %13 = llvm.mlir.constant(0 : index) : i64
          %14 = llvm.load %arg1 : !llvm.ptr -> !llvm.struct<"iree_hal_executable_dispatch_state_v0_t", (i32, i32, i16, i16, i32, i32, i16, i8, i8, ptr, ptr, ptr)>
          %15 = llvm.extractvalue %14[10] : !llvm.struct<"iree_hal_executable_dispatch_state_v0_t", (i32, i32, i16, i16, i32, i32, i16, i8, i8, ptr, ptr, ptr)> 
          %16 = llvm.load %15 : !llvm.ptr -> !llvm.ptr
          llvm.intr.assume %4 ["align"(%16, %3 : !llvm.ptr, i64)] : i1
          %17 = llvm.load %arg1 : !llvm.ptr -> !llvm.struct<"iree_hal_executable_dispatch_state_v0_t", (i32, i32, i16, i16, i32, i32, i16, i8, i8, ptr, ptr, ptr)>
          %18 = llvm.extractvalue %17[10] : !llvm.struct<"iree_hal_executable_dispatch_state_v0_t", (i32, i32, i16, i16, i32, i32, i16, i8, i8, ptr, ptr, ptr)> 
          %19 = llvm.getelementptr %18[1] : (!llvm.ptr) -> !llvm.ptr, !llvm.ptr
          %20 = llvm.load %19 : !llvm.ptr -> !llvm.ptr
          llvm.intr.assume %4 ["align"(%20, %3 : !llvm.ptr, i64)] : i1
          llvm.br ^bb1(%13 : i64)
        ^bb1(%21: i64):  // 2 preds: ^bb0, ^bb10
          %22 = llvm.icmp "slt" %21, %12 : i64
          llvm.cond_br %22, ^bb2, ^bb11
        ^bb2:  // pred: ^bb1
          %23 = llvm.mul %21, %7 overflow<nsw> : i64
          %24 = llvm.mul %21, %5 overflow<nsw> : i64
          %25 = llvm.add %24, %11 : i64
          %26 = llvm.intr.smin(%25, %7) : (i64, i64) -> i64
          llvm.br ^bb3(%13 : i64)
        ^bb3(%27: i64):  // 2 preds: ^bb2, ^bb9
          %28 = llvm.icmp "slt" %27, %11 : i64
          llvm.cond_br %28, ^bb4, ^bb10
        ^bb4:  // pred: ^bb3
          %29 = llvm.intr.smin(%26, %8) : (i64, i64) -> i64
          %30 = llvm.trunc %29 : i64 to i32
          %31 = llvm.insertelement %30, %1[%0 : i32] : vector<8xi32>
          %32 = llvm.shufflevector %31, %1 [0, 0, 0, 0, 0, 0, 0, 0] : vector<8xi32> 
          %33 = llvm.icmp "sgt" %32, %9 : vector<8xi32>
          llvm.br ^bb5(%13, %6 : i64, vector<8xf32>)
        ^bb5(%34: i64, %35: vector<8xf32>):  // 2 preds: ^bb4, ^bb8
          %36 = llvm.icmp "slt" %34, %7 : i64
          llvm.cond_br %36, ^bb6, ^bb9
        ^bb6:  // pred: ^bb5
          %37 = llvm.extractelement %33[%34 : i64] : vector<8xi1>
          llvm.cond_br %37, ^bb7, ^bb8(%35 : vector<8xf32>)
        ^bb7:  // pred: ^bb6
          %38 = llvm.add %23, %34 : i64
          %39 = llvm.mul %38, %11 overflow<nsw, nuw> : i64
          %40 = llvm.add %39, %27 overflow<nsw, nuw> : i64
          %41 = llvm.getelementptr inbounds|nuw %16[%40] : (!llvm.ptr, i64) -> !llvm.ptr, f32
          %42 = llvm.load %41 : !llvm.ptr -> f32
          %43 = llvm.insertelement %42, %35[%34 : i64] : vector<8xf32>
          llvm.br ^bb8(%43 : vector<8xf32>)
        ^bb8(%44: vector<8xf32>):  // 2 preds: ^bb6, ^bb7
          %45 = llvm.add %34, %10 : i64
          llvm.br ^bb5(%45, %44 : i64, vector<8xf32>)
        ^bb9:  // pred: ^bb5
          %46 = llvm.mul %21, %2 : i64
          %47 = llvm.mul %27, %7 : i64
          %48 = llvm.add %46, %47 : i64
          %49 = llvm.add %48, %13 : i64
          %50 = llvm.add %49, %13 : i64
          %51 = llvm.getelementptr %20[%50] : (!llvm.ptr, i64) -> !llvm.ptr, f32
          llvm.store %35, %51 {alignment = 4 : i64} : vector<8xf32>, !llvm.ptr
          %52 = llvm.add %27, %10 : i64
          llvm.br ^bb3(%52 : i64)
        ^bb10:  // pred: ^bb3
          %53 = llvm.add %21, %10 : i64
          llvm.br ^bb1(%53 : i64)
        ^bb11:  // pred: ^bb1
          llvm.return %0 : i32
        }
        llvm.func @_encoding_1_encode_500x500xf32_to_500x500xf32(%arg0: !llvm.ptr {llvm.align = 16 : i64, llvm.noalias, llvm.nonnull, llvm.noundef}, %arg1: !llvm.ptr {llvm.align = 16 : i64, llvm.noalias, llvm.nonnull, llvm.noundef}, %arg2: !llvm.ptr {llvm.align = 16 : i64, llvm.noalias, llvm.nonnull, llvm.noundef}) -> i32 {
          %0 = llvm.mlir.constant(0 : i32) : i32
          %1 = llvm.mlir.poison : vector<8xi32>
          %2 = llvm.mlir.constant(4000 : index) : i64
          %3 = llvm.mlir.constant(64 : index) : i64
          %4 = llvm.mlir.constant(true) : i1
          %5 = llvm.mlir.constant(-8 : index) : i64
          %6 = llvm.mlir.constant(8 : index) : i64
          %7 = llvm.mlir.constant(dense<0.000000e+00> : vector<8xf32>) : vector<8xf32>
          %8 = llvm.mlir.constant(2147483647 : index) : i64
          %9 = llvm.mlir.constant(dense<[0, 1, 2, 3, 4, 5, 6, 7]> : vector<8xi32>) : vector<8xi32>
          %10 = llvm.mlir.constant(1 : index) : i64
          %11 = llvm.mlir.constant(500 : index) : i64
          %12 = llvm.mlir.constant(63 : index) : i64
          %13 = llvm.mlir.constant(0 : index) : i64
          %14 = llvm.load %arg1 : !llvm.ptr -> !llvm.struct<"iree_hal_executable_dispatch_state_v0_t", (i32, i32, i16, i16, i32, i32, i16, i8, i8, ptr, ptr, ptr)>
          %15 = llvm.extractvalue %14[10] : !llvm.struct<"iree_hal_executable_dispatch_state_v0_t", (i32, i32, i16, i16, i32, i32, i16, i8, i8, ptr, ptr, ptr)> 
          %16 = llvm.load %15 : !llvm.ptr -> !llvm.ptr
          llvm.intr.assume %4 ["align"(%16, %3 : !llvm.ptr, i64)] : i1
          %17 = llvm.load %arg1 : !llvm.ptr -> !llvm.struct<"iree_hal_executable_dispatch_state_v0_t", (i32, i32, i16, i16, i32, i32, i16, i8, i8, ptr, ptr, ptr)>
          %18 = llvm.extractvalue %17[10] : !llvm.struct<"iree_hal_executable_dispatch_state_v0_t", (i32, i32, i16, i16, i32, i32, i16, i8, i8, ptr, ptr, ptr)> 
          %19 = llvm.getelementptr %18[1] : (!llvm.ptr) -> !llvm.ptr, !llvm.ptr
          %20 = llvm.load %19 : !llvm.ptr -> !llvm.ptr
          %21 = llvm.getelementptr %20[1008000] : (!llvm.ptr) -> !llvm.ptr, i8
          llvm.intr.assume %4 ["align"(%21, %3 : !llvm.ptr, i64)] : i1
          llvm.br ^bb1(%13 : i64)
        ^bb1(%22: i64):  // 2 preds: ^bb0, ^bb5
          %23 = llvm.icmp "slt" %22, %12 : i64
          llvm.cond_br %23, ^bb2, ^bb6
        ^bb2:  // pred: ^bb1
          %24 = llvm.mul %22, %6 overflow<nsw> : i64
          %25 = llvm.mul %22, %5 overflow<nsw> : i64
          %26 = llvm.add %25, %11 : i64
          %27 = llvm.intr.smin(%26, %6) : (i64, i64) -> i64
          llvm.br ^bb3(%13 : i64)
        ^bb3(%28: i64):  // 2 preds: ^bb2, ^bb4
          %29 = llvm.icmp "slt" %28, %11 : i64
          llvm.cond_br %29, ^bb4, ^bb5
        ^bb4:  // pred: ^bb3
          %30 = llvm.intr.smin(%27, %8) : (i64, i64) -> i64
          %31 = llvm.trunc %30 : i64 to i32
          %32 = llvm.insertelement %31, %1[%0 : i32] : vector<8xi32>
          %33 = llvm.shufflevector %32, %1 [0, 0, 0, 0, 0, 0, 0, 0] : vector<8xi32> 
          %34 = llvm.icmp "sgt" %33, %9 : vector<8xi32>
          %35 = llvm.mul %28, %11 : i64
          %36 = llvm.add %35, %24 : i64
          %37 = llvm.getelementptr %16[%36] : (!llvm.ptr, i64) -> !llvm.ptr, f32
          %38 = llvm.intr.masked.load %37, %34, %7 {alignment = 4 : i32} : (!llvm.ptr, vector<8xi1>, vector<8xf32>) -> vector<8xf32>
          %39 = llvm.mul %22, %2 : i64
          %40 = llvm.mul %28, %6 : i64
          %41 = llvm.add %39, %40 : i64
          %42 = llvm.add %41, %13 : i64
          %43 = llvm.add %42, %13 : i64
          %44 = llvm.getelementptr %21[%43] : (!llvm.ptr, i64) -> !llvm.ptr, f32
          llvm.store %38, %44 {alignment = 4 : i64} : vector<8xf32>, !llvm.ptr
          %45 = llvm.add %28, %10 : i64
          llvm.br ^bb3(%45 : i64)
        ^bb5:  // pred: ^bb3
          %46 = llvm.add %22, %10 : i64
          llvm.br ^bb1(%46 : i64)
        ^bb6:  // pred: ^bb1
          llvm.return %0 : i32
        }
        llvm.func @_encoding_2_encode_500x500xf32_to_500x500xf32(%arg0: !llvm.ptr {llvm.align = 16 : i64, llvm.noalias, llvm.nonnull, llvm.noundef}, %arg1: !llvm.ptr {llvm.align = 16 : i64, llvm.noalias, llvm.nonnull, llvm.noundef}, %arg2: !llvm.ptr {llvm.align = 16 : i64, llvm.noalias, llvm.nonnull, llvm.noundef}) -> i32 {
          %0 = llvm.mlir.constant(0 : i32) : i32
          %1 = llvm.mlir.poison : vector<8xi64>
          %2 = llvm.mlir.constant(4032 : index) : i64
          %3 = llvm.mlir.constant(64 : index) : i64
          %4 = llvm.mlir.constant(true) : i1
          %5 = llvm.mlir.constant(dense<false> : vector<8xi1>) : vector<8xi1>
          %6 = llvm.mlir.constant(dense<[0, 1, 2, 3, 4, 5, 6, 7]> : vector<8xi64>) : vector<8xi64>
          %7 = llvm.mlir.constant(7 : index) : i64
          %8 = llvm.mlir.constant(6 : index) : i64
          %9 = llvm.mlir.constant(5 : index) : i64
          %10 = llvm.mlir.constant(4 : index) : i64
          %11 = llvm.mlir.constant(3 : index) : i64
          %12 = llvm.mlir.constant(2 : index) : i64
          %13 = llvm.mlir.constant(500 : index) : i64
          %14 = llvm.mlir.constant(-8 : index) : i64
          %15 = llvm.mlir.constant(8 : index) : i64
          %16 = llvm.mlir.constant(dense<0.000000e+00> : vector<8xf32>) : vector<8xf32>
          %17 = llvm.mlir.constant(1 : index) : i64
          %18 = llvm.mlir.constant(63 : index) : i64
          %19 = llvm.mlir.constant(0 : index) : i64
          %20 = llvm.load %arg1 : !llvm.ptr -> !llvm.struct<"iree_hal_executable_dispatch_state_v0_t", (i32, i32, i16, i16, i32, i32, i16, i8, i8, ptr, ptr, ptr)>
          %21 = llvm.extractvalue %20[10] : !llvm.struct<"iree_hal_executable_dispatch_state_v0_t", (i32, i32, i16, i16, i32, i32, i16, i8, i8, ptr, ptr, ptr)> 
          %22 = llvm.load %21 : !llvm.ptr -> !llvm.ptr
          llvm.intr.assume %4 ["align"(%22, %3 : !llvm.ptr, i64)] : i1
          %23 = llvm.load %arg1 : !llvm.ptr -> !llvm.struct<"iree_hal_executable_dispatch_state_v0_t", (i32, i32, i16, i16, i32, i32, i16, i8, i8, ptr, ptr, ptr)>
          %24 = llvm.extractvalue %23[10] : !llvm.struct<"iree_hal_executable_dispatch_state_v0_t", (i32, i32, i16, i16, i32, i32, i16, i8, i8, ptr, ptr, ptr)> 
          %25 = llvm.getelementptr %24[1] : (!llvm.ptr) -> !llvm.ptr, !llvm.ptr
          %26 = llvm.load %25 : !llvm.ptr -> !llvm.ptr
          %27 = llvm.getelementptr %26[2016000] : (!llvm.ptr) -> !llvm.ptr, i8
          llvm.intr.assume %4 ["align"(%27, %3 : !llvm.ptr, i64)] : i1
          llvm.br ^bb1(%19 : i64)
        ^bb1(%28: i64):  // 2 preds: ^bb0, ^bb5
          %29 = llvm.icmp "slt" %28, %18 : i64
          llvm.cond_br %29, ^bb2, ^bb6
        ^bb2:  // pred: ^bb1
          %30 = llvm.mul %28, %15 overflow<nsw> : i64
          %31 = llvm.mul %28, %14 overflow<nsw> : i64
          %32 = llvm.add %31, %13 : i64
          %33 = llvm.intr.smin(%32, %15) : (i64, i64) -> i64
          llvm.br ^bb3(%19 : i64)
        ^bb3(%34: i64):  // 2 preds: ^bb2, ^bb4
          %35 = llvm.icmp "slt" %34, %18 : i64
          llvm.cond_br %35, ^bb4, ^bb5
        ^bb4:  // pred: ^bb3
          %36 = llvm.mul %34, %15 overflow<nsw> : i64
          %37 = llvm.mul %34, %14 overflow<nsw> : i64
          %38 = llvm.add %37, %13 : i64
          %39 = llvm.intr.smin(%38, %15) : (i64, i64) -> i64
          %40 = llvm.insertelement %39, %1[%0 : i32] : vector<8xi64>
          %41 = llvm.shufflevector %40, %1 [0, 0, 0, 0, 0, 0, 0, 0] : vector<8xi64> 
          %42 = llvm.icmp "sgt" %41, %6 : vector<8xi64>
          %43 = llvm.icmp "sgt" %33, %19 : i64
          %44 = llvm.select %43, %42, %5 : i1, vector<8xi1>
          %45 = llvm.icmp "sgt" %33, %17 : i64
          %46 = llvm.select %45, %42, %5 : i1, vector<8xi1>
          %47 = llvm.icmp "sgt" %33, %12 : i64
          %48 = llvm.select %47, %42, %5 : i1, vector<8xi1>
          %49 = llvm.icmp "sgt" %33, %11 : i64
          %50 = llvm.select %49, %42, %5 : i1, vector<8xi1>
          %51 = llvm.icmp "sgt" %33, %10 : i64
          %52 = llvm.select %51, %42, %5 : i1, vector<8xi1>
          %53 = llvm.icmp "sgt" %33, %9 : i64
          %54 = llvm.select %53, %42, %5 : i1, vector<8xi1>
          %55 = llvm.icmp "sgt" %33, %8 : i64
          %56 = llvm.select %55, %42, %5 : i1, vector<8xi1>
          %57 = llvm.icmp "sgt" %33, %7 : i64
          %58 = llvm.select %57, %42, %5 : i1, vector<8xi1>
          %59 = llvm.mul %30, %13 : i64
          %60 = llvm.add %59, %36 : i64
          %61 = llvm.getelementptr %22[%60] : (!llvm.ptr, i64) -> !llvm.ptr, f32
          %62 = llvm.intr.masked.load %61, %44, %16 {alignment = 4 : i32} : (!llvm.ptr, vector<8xi1>, vector<8xf32>) -> vector<8xf32>
          %63 = llvm.add %30, %17 : i64
          %64 = llvm.mul %63, %13 : i64
          %65 = llvm.add %64, %36 : i64
          %66 = llvm.getelementptr %22[%65] : (!llvm.ptr, i64) -> !llvm.ptr, f32
          %67 = llvm.intr.masked.load %66, %46, %16 {alignment = 4 : i32} : (!llvm.ptr, vector<8xi1>, vector<8xf32>) -> vector<8xf32>
          %68 = llvm.add %30, %12 : i64
          %69 = llvm.mul %68, %13 : i64
          %70 = llvm.add %69, %36 : i64
          %71 = llvm.getelementptr %22[%70] : (!llvm.ptr, i64) -> !llvm.ptr, f32
          %72 = llvm.intr.masked.load %71, %48, %16 {alignment = 4 : i32} : (!llvm.ptr, vector<8xi1>, vector<8xf32>) -> vector<8xf32>
          %73 = llvm.add %30, %11 : i64
          %74 = llvm.mul %73, %13 : i64
          %75 = llvm.add %74, %36 : i64
          %76 = llvm.getelementptr %22[%75] : (!llvm.ptr, i64) -> !llvm.ptr, f32
          %77 = llvm.intr.masked.load %76, %50, %16 {alignment = 4 : i32} : (!llvm.ptr, vector<8xi1>, vector<8xf32>) -> vector<8xf32>
          %78 = llvm.add %30, %10 : i64
          %79 = llvm.mul %78, %13 : i64
          %80 = llvm.add %79, %36 : i64
          %81 = llvm.getelementptr %22[%80] : (!llvm.ptr, i64) -> !llvm.ptr, f32
          %82 = llvm.intr.masked.load %81, %52, %16 {alignment = 4 : i32} : (!llvm.ptr, vector<8xi1>, vector<8xf32>) -> vector<8xf32>
          %83 = llvm.add %30, %9 : i64
          %84 = llvm.mul %83, %13 : i64
          %85 = llvm.add %84, %36 : i64
          %86 = llvm.getelementptr %22[%85] : (!llvm.ptr, i64) -> !llvm.ptr, f32
          %87 = llvm.intr.masked.load %86, %54, %16 {alignment = 4 : i32} : (!llvm.ptr, vector<8xi1>, vector<8xf32>) -> vector<8xf32>
          %88 = llvm.add %30, %8 : i64
          %89 = llvm.mul %88, %13 : i64
          %90 = llvm.add %89, %36 : i64
          %91 = llvm.getelementptr %22[%90] : (!llvm.ptr, i64) -> !llvm.ptr, f32
          %92 = llvm.intr.masked.load %91, %56, %16 {alignment = 4 : i32} : (!llvm.ptr, vector<8xi1>, vector<8xf32>) -> vector<8xf32>
          %93 = llvm.add %30, %7 : i64
          %94 = llvm.mul %93, %13 : i64
          %95 = llvm.add %94, %36 : i64
          %96 = llvm.getelementptr %22[%95] : (!llvm.ptr, i64) -> !llvm.ptr, f32
          %97 = llvm.intr.masked.load %96, %58, %16 {alignment = 4 : i32} : (!llvm.ptr, vector<8xi1>, vector<8xf32>) -> vector<8xf32>
          %98 = llvm.mul %28, %2 : i64
          %99 = llvm.mul %34, %3 : i64
          %100 = llvm.add %98, %99 : i64
          %101 = llvm.mul %19, %15 : i64
          %102 = llvm.add %100, %101 : i64
          %103 = llvm.add %102, %19 : i64
          %104 = llvm.getelementptr %27[%103] : (!llvm.ptr, i64) -> !llvm.ptr, f32
          llvm.store %62, %104 {alignment = 4 : i64} : vector<8xf32>, !llvm.ptr
          %105 = llvm.mul %17, %15 : i64
          %106 = llvm.add %100, %105 : i64
          %107 = llvm.add %106, %19 : i64
          %108 = llvm.getelementptr %27[%107] : (!llvm.ptr, i64) -> !llvm.ptr, f32
          llvm.store %67, %108 {alignment = 4 : i64} : vector<8xf32>, !llvm.ptr
          %109 = llvm.mul %12, %15 : i64
          %110 = llvm.add %100, %109 : i64
          %111 = llvm.add %110, %19 : i64
          %112 = llvm.getelementptr %27[%111] : (!llvm.ptr, i64) -> !llvm.ptr, f32
          llvm.store %72, %112 {alignment = 4 : i64} : vector<8xf32>, !llvm.ptr
          %113 = llvm.mul %11, %15 : i64
          %114 = llvm.add %100, %113 : i64
          %115 = llvm.add %114, %19 : i64
          %116 = llvm.getelementptr %27[%115] : (!llvm.ptr, i64) -> !llvm.ptr, f32
          llvm.store %77, %116 {alignment = 4 : i64} : vector<8xf32>, !llvm.ptr
          %117 = llvm.mul %10, %15 : i64
          %118 = llvm.add %100, %117 : i64
          %119 = llvm.add %118, %19 : i64
          %120 = llvm.getelementptr %27[%119] : (!llvm.ptr, i64) -> !llvm.ptr, f32
          llvm.store %82, %120 {alignment = 4 : i64} : vector<8xf32>, !llvm.ptr
          %121 = llvm.mul %9, %15 : i64
          %122 = llvm.add %100, %121 : i64
          %123 = llvm.add %122, %19 : i64
          %124 = llvm.getelementptr %27[%123] : (!llvm.ptr, i64) -> !llvm.ptr, f32
          llvm.store %87, %124 {alignment = 4 : i64} : vector<8xf32>, !llvm.ptr
          %125 = llvm.mul %8, %15 : i64
          %126 = llvm.add %100, %125 : i64
          %127 = llvm.add %126, %19 : i64
          %128 = llvm.getelementptr %27[%127] : (!llvm.ptr, i64) -> !llvm.ptr, f32
          llvm.store %92, %128 {alignment = 4 : i64} : vector<8xf32>, !llvm.ptr
          %129 = llvm.mul %7, %15 : i64
          %130 = llvm.add %100, %129 : i64
          %131 = llvm.add %130, %19 : i64
          %132 = llvm.getelementptr %27[%131] : (!llvm.ptr, i64) -> !llvm.ptr, f32
          llvm.store %97, %132 {alignment = 4 : i64} : vector<8xf32>, !llvm.ptr
          %133 = llvm.add %34, %17 : i64
          llvm.br ^bb3(%133 : i64)
        ^bb5:  // pred: ^bb3
          %134 = llvm.add %28, %17 : i64
          llvm.br ^bb1(%134 : i64)
        ^bb6:  // pred: ^bb1
          llvm.return %0 : i32
        }
      }
    }
  }
  util.global private @__device_0 : !hal.device
  util.initializer {
    %c18_i32 = arith.constant 18 : i32
    %false = arith.constant false
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %0 = util.null : !hal.device
    %device_count = hal.devices.count : index
    %1:3 = scf.while (%arg0 = %c0, %arg1 = %c0, %arg2 = %0) : (index, index, !hal.device) -> (index, index, !hal.device) {
      %3 = util.cmp.eq %arg2, %0 : !hal.device
      %4 = arith.cmpi slt, %arg0, %device_count : index
      %5 = arith.andi %3, %4 : i1
      scf.condition(%5) %arg0, %arg1, %arg2 : index, index, !hal.device
    } do {
    ^bb0(%arg0: index, %arg1: index, %arg2: !hal.device):
      %device_n = hal.devices.get %arg0 : !hal.device
      %ok, %value = hal.device.query<%device_n : !hal.device> key("hal.device.id" :: "local*") : i1, i1 = false
      %3 = scf.if %value -> (i1) {
        %ok_0, %value_1 = hal.device.query<%device_n : !hal.device> key("hal.executable.format" :: "embedded-elf-arm_64") : i1, i1 = false
        scf.yield %value_1 : i1
      } else {
        scf.yield %false : i1
      }
      %4 = arith.cmpi eq, %arg1, %c0 : index
      %5 = arith.select %3, %c1, %c0 : index
      %6 = arith.addi %arg1, %5 : index
      %7 = arith.andi %3, %4 : i1
      %8 = arith.select %7, %device_n, %0 : !hal.device
      %9 = arith.addi %arg0, %c1 : index
      scf.yield %9, %6, %8 : index, index, !hal.device
    }
    %2 = util.cmp.eq %1#2, %0 : !hal.device
    scf.if %2 {
      util.status.check_ok %c18_i32, "HAL device `__device_0` not found or unavailable: #hal.device.target<\22local\22, [#hal.executable.target<\22llvm-cpu\22, \22embedded-elf-arm_64\22, {cpu = \22apple-m4\22, cpu_features = \22+v8.7a,+aes,+bf16,+complxnum,+crc,+dotprod,+fp-armv8,+fp16fml,+fpac,+fullfp16,+i8mm,+jsconv,+lse,+neon,+pauth,+perfmon,+ras,+rcpc,+rdm,+sha2,+sha3,+sme,+sme-f64f64,+sme-i16i64,+sme2,+reserve-x18\22, data_layout = \22e-m:e-p270:32:32-p271:32:32-p272:64:64-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128-Fn32\22, iree.encoding.resolver = #iree_cpu.cpu_encoding_resolver<>, max_stack_allocation_size = 32768 : i64, native_vector_size = 16 : i64, target_triple = \22arm64-unknown-unknown-eabi-elf\22, ukernels = \22none\22}>]>"
    }
    util.global.store %1#2, @__device_0 : !hal.device
    util.return
  }
  util.global private @__device_0_query_0_hal_executable_format_embedded_elf_arm_64 : i1
  util.initializer {
    %__device_0 = util.global.load @__device_0 : !hal.device
    %ok, %value = hal.device.query<%__device_0 : !hal.device> key("hal.executable.format" :: "embedded-elf-arm_64") : i1, i1 = false
    util.global.store %value, @__device_0_query_0_hal_executable_format_embedded_elf_arm_64 : i1
    util.return
  }
  util.global private @__device_0_executable_0_matmul_500_linked : !hal.executable
  util.initializer {
    %c-1_i64 = arith.constant -1 : i64
    %c-1 = arith.constant -1 : index
    %c0 = arith.constant 0 : index
    %c14_i32 = arith.constant 14 : i32
    %0 = util.null : !hal.executable
    %__device_0_query_0_hal_executable_format_embedded_elf_arm_64 = util.global.load @__device_0_query_0_hal_executable_format_embedded_elf_arm_64 : i1
    %__device_0 = util.global.load @__device_0 : !hal.device
    %1 = arith.select %__device_0_query_0_hal_executable_format_embedded_elf_arm_64, %c0, %c-1 : index
    %2 = arith.cmpi eq, %1, %c0 : index
    %3 = scf.if %2 -> (!hal.executable) {
      %executable = hal.executable.create device(%__device_0 : !hal.device) affinity(%c-1_i64) target(@matmul_500_linked::@embedded_elf_arm_64) : !hal.executable
      scf.yield %executable : !hal.executable
    } else {
      util.status.check_ok %c14_i32, "HAL device `__device_0` does not support any variant of executable `matmul_500_linked`; available formats: [embedded-elf-arm_64]"
      scf.yield %0 : !hal.executable
    }
    util.global.store %3, @__device_0_executable_0_matmul_500_linked : !hal.executable
    util.return
  }
  util.func private @__matmul_memoize_apply(%arg0: !hal.device, %arg1: i64) -> !hal.command_buffer attributes {inlining_policy = #util.inline.never} {
    %c3 = arith.constant 3 : index
    %c2 = arith.constant 2 : index
    %c1 = arith.constant 1 : index
    %c3032064 = arith.constant 3032064 : index
    %c1000000 = arith.constant 1000000 : index
    %c4 = arith.constant 4 : index
    %c0 = arith.constant 0 : index
    %c5 = arith.constant 5 : index
    %__device_0_executable_0_matmul_500_linked = util.global.load immutable @__device_0_executable_0_matmul_500_linked : !hal.executable
    %cmd = hal.command_buffer.create device(%arg0 : !hal.device) mode("None") categories("Transfer|Dispatch") affinity(%arg1) bindings(%c5) : !hal.command_buffer
    %function_id = hal.executable.lookup.function target(%__device_0_executable_0_matmul_500_linked : !hal.executable) function(@matmul_500_linked::@embedded_elf_arm_64::@_encoding_0_encode_500x500xf32_to_500x500xf32) : i64
    hal.command_buffer.dispatch<%cmd : !hal.command_buffer> target(%__device_0_executable_0_matmul_500_linked : !hal.executable)[%function_id] workgroups([%c1, %c1, %c1]) bindings([
      (%c0 : index)[%c0, %c1000000], 
      (%c4 : index)[%c0, %c3032064]
    ]) flags("None")
    %function_id_0 = hal.executable.lookup.function target(%__device_0_executable_0_matmul_500_linked : !hal.executable) function(@matmul_500_linked::@embedded_elf_arm_64::@_encoding_1_encode_500x500xf32_to_500x500xf32) : i64
    hal.command_buffer.dispatch<%cmd : !hal.command_buffer> target(%__device_0_executable_0_matmul_500_linked : !hal.executable)[%function_id_0] workgroups([%c1, %c1, %c1]) bindings([
      (%c1 : index)[%c0, %c1000000], 
      (%c4 : index)[%c0, %c3032064]
    ]) flags("None")
    %function_id_1 = hal.executable.lookup.function target(%__device_0_executable_0_matmul_500_linked : !hal.executable) function(@matmul_500_linked::@embedded_elf_arm_64::@_encoding_2_encode_500x500xf32_to_500x500xf32) : i64
    hal.command_buffer.dispatch<%cmd : !hal.command_buffer> target(%__device_0_executable_0_matmul_500_linked : !hal.executable)[%function_id_1] workgroups([%c1, %c1, %c1]) bindings([
      (%c2 : index)[%c0, %c1000000], 
      (%c4 : index)[%c0, %c3032064]
    ]) flags("None")
    hal.command_buffer.execution_barrier<%cmd : !hal.command_buffer> source("Dispatch|Transfer|CommandRetire") target("CommandIssue|Dispatch|Transfer") flags("None")
    %function_id_2 = hal.executable.lookup.function target(%__device_0_executable_0_matmul_500_linked : !hal.executable) function(@matmul_500_linked::@embedded_elf_arm_64::@matmul_dispatch_0_matmul_like_500x500x500_f32) : i64
    hal.command_buffer.dispatch<%cmd : !hal.command_buffer> target(%__device_0_executable_0_matmul_500_linked : !hal.executable)[%function_id_2] workgroups([%c1, %c1, %c1]) bindings([
      (%c4 : index)[%c0, %c3032064], 
      (%c3 : index)[%c0, %c1000000]
    ]) flags("None")
    hal.command_buffer.execution_barrier<%cmd : !hal.command_buffer> source("Dispatch|Transfer|CommandRetire") target("CommandIssue|Dispatch|Transfer") flags("None")
    hal.command_buffer.finalize<%cmd : !hal.command_buffer>
    util.return %cmd : !hal.command_buffer
  }
  util.global private @__matmul_memoize_result_0_device_0 : !hal.command_buffer
  util.initializer {
    %c-1_i64 = arith.constant -1 : i64
    %__device_0 = util.global.load immutable @__device_0 : !hal.device
    %0 = util.call @__matmul_memoize_apply(%__device_0, %c-1_i64) : (!hal.device, i64) -> !hal.command_buffer
    util.global.store %0, @__matmul_memoize_result_0_device_0 : !hal.command_buffer
    util.return
  }
  util.func private @__matmul_memoize_lookup(%arg0: !hal.device, %arg1: i64) -> !hal.command_buffer {
    %0 = util.null : !hal.command_buffer
    %__device_0 = util.global.load immutable @__device_0 : !hal.device
    %1 = util.cmp.eq %arg0, %__device_0 : !hal.device
    %2 = scf.if %1 -> (!hal.command_buffer) {
      %__matmul_memoize_result_0_device_0 = util.global.load immutable @__matmul_memoize_result_0_device_0 : !hal.command_buffer
      scf.yield %__matmul_memoize_result_0_device_0 : !hal.command_buffer
    } else {
      scf.yield %0 : !hal.command_buffer
    }
    util.return %2 : !hal.command_buffer
  }
  util.func public @matmul(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "sync func @matmul(%input0: tensor<500x500xf32>, %input1: tensor<500x500xf32>, %input2: tensor<500x500xf32>) -> (%output0: tensor<500x500xf32>)"}} {
    %c-1_i32 = arith.constant -1 : i32
    %c0_i64 = arith.constant 0 : i64
    %0 = util.null : !hal.fence
    %c-1_i64 = arith.constant -1 : i64
    %c3032064 = arith.constant 3032064 : index
    %c0 = arith.constant 0 : index
    %c1000000 = arith.constant 1000000 : index
    %c500 = arith.constant 500 : index
    %memory_type = hal.memory_type<"DeviceVisible|DeviceLocal"> : i32
    %buffer_usage = hal.buffer_usage<"TransferSource|TransferTarget|Transfer|DispatchStorageRead|DispatchStorageWrite|DispatchStorage"> : i32
    %__device_0 = util.global.load immutable @__device_0 : !hal.device
    %element_type_f32 = hal.element_type<f32> : i32
    %dense_row_major = hal.encoding_type<dense_row_major> : i32
    hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%c500, %c500]) type(%element_type_f32) encoding(%dense_row_major)
    %buffer = hal.buffer_view.buffer<%arg0 : !hal.buffer_view> : !hal.buffer
    %allocator = hal.device.allocator<%__device_0 : !hal.device> : !hal.allocator
    hal.buffer.assert<%buffer : !hal.buffer> message("tensor") allocator(%allocator : !hal.allocator) minimum_length(%c1000000) type(DeviceVisible) usage("TransferSource|TransferTarget|Transfer|DispatchStorageRead|DispatchStorageWrite|DispatchStorage")
    hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%c500, %c500]) type(%element_type_f32) encoding(%dense_row_major)
    %buffer_0 = hal.buffer_view.buffer<%arg1 : !hal.buffer_view> : !hal.buffer
    hal.buffer.assert<%buffer_0 : !hal.buffer> message("tensor") allocator(%allocator : !hal.allocator) minimum_length(%c1000000) type(DeviceVisible) usage("TransferSource|TransferTarget|Transfer|DispatchStorageRead|DispatchStorageWrite|DispatchStorage")
    hal.buffer_view.assert<%arg2 : !hal.buffer_view> message("input2") shape([%c500, %c500]) type(%element_type_f32) encoding(%dense_row_major)
    %buffer_1 = hal.buffer_view.buffer<%arg2 : !hal.buffer_view> : !hal.buffer
    hal.buffer.assert<%buffer_1 : !hal.buffer> message("tensor") allocator(%allocator : !hal.allocator) minimum_length(%c1000000) type(DeviceVisible) usage("TransferSource|TransferTarget|Transfer|DispatchStorageRead|DispatchStorageWrite|DispatchStorage")
    %fence = hal.fence.create device(%__device_0 : !hal.device) flags("None") : !hal.fence
    %transient_buffer = hal.device.queue.alloca<%__device_0 : !hal.device> affinity(%c-1_i64) wait(%0) signal(%fence) pool(%c0_i64) type(%memory_type) usage(%buffer_usage) flags("None") : !hal.buffer{%c1000000}
    %fence_2 = hal.fence.create device(%__device_0 : !hal.device) flags("None") : !hal.fence
    %transient_buffer_3 = hal.device.queue.alloca<%__device_0 : !hal.device> affinity(%c-1_i64) wait(%0) signal(%fence_2) pool(%c0_i64) type(%memory_type) usage(%buffer_usage) flags("None") : !hal.buffer{%c3032064}
    %fence_4 = hal.fence.join at([%fence, %fence_2]) flags("None") -> !hal.fence
    %1 = util.call @__matmul_memoize_lookup(%__device_0, %c-1_i64) : (!hal.device, i64) -> !hal.command_buffer
    %fence_5 = hal.fence.create device(%__device_0 : !hal.device) flags("None") : !hal.fence
    hal.device.queue.execute.indirect<%__device_0 : !hal.device> affinity(%c-1_i64) wait(%fence_4) signal(%fence_5) commands(%1) bindings([
      (%buffer : !hal.buffer)[%c0, %c1000000], 
      (%buffer_0 : !hal.buffer)[%c0, %c1000000], 
      (%buffer_1 : !hal.buffer)[%c0, %c1000000], 
      (%transient_buffer : !hal.buffer)[%c0, %c1000000], 
      (%transient_buffer_3 : !hal.buffer)[%c0, %c3032064]
    ]) flags("None")
    %fence_6 = hal.fence.create device(%__device_0 : !hal.device) flags("None") : !hal.fence
    hal.device.queue.dealloca<%__device_0 : !hal.device> affinity(%c-1_i64) wait(%fence_5) signal(%fence_6) buffer(%transient_buffer_3 : !hal.buffer) flags("None")
    %status = hal.fence.await until([%fence_6]) timeout_millis(%c-1_i32) flags("None") : i32
    util.status.check_ok %status, "failed to wait on timepoint"
    %view = hal.buffer_view.create buffer(%transient_buffer : !hal.buffer)[%c0, %c1000000] shape([%c500, %c500]) type(%element_type_f32) encoding(%dense_row_major) : !hal.buffer_view
    util.return %view : !hal.buffer_view
  }
}


