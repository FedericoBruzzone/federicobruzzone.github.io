// -----// IR Dump After mlir::iree_compiler::detail::OpPipelineAdaptorPass: iree-op-pipeline-adaptor //----- //
#executable_target_embedded_elf_arm_64 = #hal.executable.target<"llvm-cpu", "embedded-elf-arm_64", {cpu = "apple-m4", cpu_features = "+v8.7a,+aes,+bf16,+complxnum,+crc,+dotprod,+fp-armv8,+fp16fml,+fpac,+fullfp16,+i8mm,+jsconv,+lse,+neon,+pauth,+perfmon,+ras,+rcpc,+rdm,+sha2,+sha3,+sme,+sme-f64f64,+sme-i16i64,+sme2,+reserve-x18", data_layout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128-Fn32", iree.encoding.resolver = #iree_cpu.cpu_encoding_resolver<>, max_stack_allocation_size = 32768 : i64, native_vector_size = 16 : i64, target_triple = "arm64-unknown-unknown-eabi-elf", ukernels = "none"}>
#map = affine_map<(d0, d1, d2) -> (d0, d2)>
#map1 = affine_map<(d0, d1, d2) -> (d2, d1)>
#map2 = affine_map<(d0, d1, d2) -> (d0, d1)>
#device_target_local = #hal.device.target<"local", [#executable_target_embedded_elf_arm_64]> : !hal.device
#encoding = #iree_encoding.encoding<operand_index = 0 : index, op_type = matmul, element_types = [f32, f32, f32], user_indexing_maps = [#map, #map1, #map2], iteration_sizes = [500, 500, 500]>
#encoding1 = #iree_encoding.encoding<operand_index = 1 : index, op_type = matmul, element_types = [f32, f32, f32], user_indexing_maps = [#map, #map1, #map2], iteration_sizes = [500, 500, 500]>
#encoding2 = #iree_encoding.encoding<operand_index = 2 : index, op_type = matmul, element_types = [f32, f32, f32], user_indexing_maps = [#map, #map1, #map2], iteration_sizes = [500, 500, 500]>
module attributes {stream.affinity.default = #hal.device.affinity<@__device_0>} {
  util.global private @__device_0 = #device_target_local
  util.func public @matmul(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "sync func @matmul(%input0: tensor<500x500xf32>, %input1: tensor<500x500xf32>, %input2: tensor<500x500xf32>) -> (%output0: tensor<500x500xf32>)"}} {
    %0 = hal.tensor.import %arg0 "input0" : !hal.buffer_view -> tensor<500x500xf32>
    %1 = iree_tensor_ext.compute_barrier.start %0 : tensor<500x500xf32> -> tensor<500x500xf32>
    %2 = hal.tensor.import %arg1 "input1" : !hal.buffer_view -> tensor<500x500xf32>
    %3 = iree_tensor_ext.compute_barrier.start %2 : tensor<500x500xf32> -> tensor<500x500xf32>
    %4 = hal.tensor.import %arg2 "input2" : !hal.buffer_view -> tensor<500x500xf32>
    %5 = iree_tensor_ext.compute_barrier.start %4 : tensor<500x500xf32> -> tensor<500x500xf32>
    %6 = flow.dispatch.region -> (tensor<500x500xf32>) {
      %9 = iree_encoding.set_encoding %1 : tensor<500x500xf32> -> tensor<500x500xf32, #encoding>
      %10 = iree_encoding.set_encoding %3 : tensor<500x500xf32> -> tensor<500x500xf32, #encoding1>
      %11 = iree_encoding.set_encoding %5 : tensor<500x500xf32> -> tensor<500x500xf32, #encoding2>
      %12 = linalg.generic {indexing_maps = [#map, #map1, #map2], iterator_types = ["parallel", "parallel", "reduction"]} ins(%9, %10 : tensor<500x500xf32, #encoding>, tensor<500x500xf32, #encoding1>) outs(%11 : tensor<500x500xf32, #encoding2>) {
      ^bb0(%in: f32, %in_0: f32, %out: f32):
        %14 = arith.mulf %in, %in_0 : f32
        %15 = arith.addf %out, %14 : f32
        linalg.yield %15 : f32
      } -> tensor<500x500xf32, #encoding2>
      %13 = iree_encoding.unset_encoding %12 : tensor<500x500xf32, #encoding2> -> tensor<500x500xf32>
      flow.return %13 : tensor<500x500xf32>
    }
    %7 = iree_tensor_ext.compute_barrier.end %6 : tensor<500x500xf32> -> tensor<500x500xf32>
    %8 = hal.tensor.export %7 "output0" : tensor<500x500xf32> -> !hal.buffer_view
    util.return %8 : !hal.buffer_view
  }
}


