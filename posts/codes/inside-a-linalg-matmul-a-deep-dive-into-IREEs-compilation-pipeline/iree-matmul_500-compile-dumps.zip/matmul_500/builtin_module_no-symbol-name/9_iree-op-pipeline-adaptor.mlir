// -----// IR Dump After mlir::iree_compiler::detail::OpPipelineAdaptorPass: iree-op-pipeline-adaptor //----- //
#executable_target_embedded_elf_arm_64 = #hal.executable.target<"llvm-cpu", "embedded-elf-arm_64", {cpu = "apple-m4", cpu_features = "+v8.7a,+aes,+bf16,+complxnum,+crc,+dotprod,+fp-armv8,+fp16fml,+fpac,+fullfp16,+i8mm,+jsconv,+lse,+neon,+pauth,+perfmon,+ras,+rcpc,+rdm,+sha2,+sha3,+sme,+sme-f64f64,+sme-i16i64,+sme2,+reserve-x18", data_layout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128-Fn32", iree.encoding.resolver = #iree_cpu.cpu_encoding_resolver<>, max_stack_allocation_size = 32768 : i64, native_vector_size = 16 : i64, target_triple = "arm64-unknown-unknown-eabi-elf", ukernels = "none"}>
#map = affine_map<(d0, d1, d2) -> (d0, d2)>
#map1 = affine_map<(d0, d1, d2) -> (d2, d1)>
#map2 = affine_map<(d0, d1, d2) -> (d0, d1)>
#device_target_local = #hal.device.target<"local", [#executable_target_embedded_elf_arm_64]> : !hal.device
#encoding = #iree_encoding.encoding<operand_index = 0 : index, op_type = matmul, element_types = [f32, f32, f32], user_indexing_maps = [#map, #map1, #map2], iteration_sizes = [500, 500, 500]>
#encoding1 = #iree_encoding.encoding<operand_index = 1 : index, op_type = matmul, element_types = [f32, f32, f32], user_indexing_maps = [#map, #map1, #map2], iteration_sizes = [500, 500, 500]>
#encoding2 = #iree_encoding.encoding<operand_index = 2 : index, op_type = matmul, element_types = [f32, f32, f32], user_indexing_maps = [#map, #map1, #map2], iteration_sizes = [500, 500, 500]>
module attributes {stream.affinity.default = #hal.device.affinity<@__device_0>} {
  util.global private @__device_0 = #device_target_local
  util.func public @matmul(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "sync func @matmul(%input0: tensor<500x500xf32>, %input1: tensor<500x500xf32>, %input2: tensor<500x500xf32>) -> (%output0: tensor<500x500xf32>)"}} {
    %0 = hal.tensor.import %arg0 "input0" : !hal.buffer_view -> tensor<500x500xf32>
    %1 = hal.tensor.import %arg1 "input1" : !hal.buffer_view -> tensor<500x500xf32>
    %2 = hal.tensor.import %arg2 "input2" : !hal.buffer_view -> tensor<500x500xf32>
    %3 = flow.tensor.encode %0 : tensor<500x500xf32> -> tensor<500x500xf32, #encoding>
    %4 = flow.tensor.encode %1 : tensor<500x500xf32> -> tensor<500x500xf32, #encoding1>
    %5 = flow.tensor.encode %2 : tensor<500x500xf32> -> tensor<500x500xf32, #encoding2>
    %6 = flow.dispatch.workgroups(%3, %4, %5) : (tensor<500x500xf32, #encoding>, tensor<500x500xf32, #encoding1>, tensor<500x500xf32, #encoding2>) -> tensor<500x500xf32> =
        (%arg3: !iree_tensor_ext.dispatch.tensor<readonly:tensor<500x500xf32, #encoding>>, %arg4: !iree_tensor_ext.dispatch.tensor<readonly:tensor<500x500xf32, #encoding1>>, %arg5: !iree_tensor_ext.dispatch.tensor<readonly:tensor<500x500xf32, #encoding2>>, %arg6: !iree_tensor_ext.dispatch.tensor<writeonly:tensor<500x500xf32>>) {
      %8 = iree_tensor_ext.dispatch.tensor.load %arg3, offsets = [0, 0], sizes = [500, 500], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<500x500xf32, #encoding>> -> tensor<500x500xf32, #encoding>
      %9 = iree_tensor_ext.dispatch.tensor.load %arg4, offsets = [0, 0], sizes = [500, 500], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<500x500xf32, #encoding1>> -> tensor<500x500xf32, #encoding1>
      %10 = iree_tensor_ext.dispatch.tensor.load %arg5, offsets = [0, 0], sizes = [500, 500], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<500x500xf32, #encoding2>> -> tensor<500x500xf32, #encoding2>
      %11 = linalg.generic {indexing_maps = [#map, #map1, #map2], iterator_types = ["parallel", "parallel", "reduction"]} ins(%8, %9 : tensor<500x500xf32, #encoding>, tensor<500x500xf32, #encoding1>) outs(%10 : tensor<500x500xf32, #encoding2>) {
      ^bb0(%in: f32, %in_0: f32, %out: f32):
        %13 = arith.mulf %in, %in_0 : f32
        %14 = arith.addf %out, %13 : f32
        linalg.yield %14 : f32
      } -> tensor<500x500xf32, #encoding2>
      %12 = iree_encoding.unset_encoding %11 : tensor<500x500xf32, #encoding2> -> tensor<500x500xf32>
      iree_tensor_ext.dispatch.tensor.store %12, %arg6, offsets = [0, 0], sizes = [500, 500], strides = [1, 1] : tensor<500x500xf32> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<500x500xf32>>
      flow.return
    } count() -> (index, index, index) {
      %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice()
      flow.return %x, %y, %z : index, index, index
    }
    %7 = hal.tensor.export %6 "output0" : tensor<500x500xf32> -> !hal.buffer_view
    util.return %7 : !hal.buffer_view
  }
}


