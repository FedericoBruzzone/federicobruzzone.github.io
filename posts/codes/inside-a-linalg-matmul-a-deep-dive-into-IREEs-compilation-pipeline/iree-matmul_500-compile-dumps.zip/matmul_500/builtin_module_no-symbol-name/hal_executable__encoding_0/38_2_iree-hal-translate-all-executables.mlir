// -----// IR Dump After TranslateAllExecutablesPass: iree-hal-translate-all-executables{target-registry=1} //----- //
hal.executable private @_encoding_0 {
  hal.executable.variant public @embedded_elf_arm_64 target(<"llvm-cpu", "embedded-elf-arm_64", {cpu = "apple-m4", cpu_features = "+v8.7a,+aes,+bf16,+complxnum,+crc,+dotprod,+fp-armv8,+fp16fml,+fpac,+fullfp16,+i8mm,+jsconv,+lse,+neon,+pauth,+perfmon,+ras,+rcpc,+rdm,+sha2,+sha3,+sme,+sme-f64f64,+sme-i16i64,+sme2,+reserve-x18", data_layout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128-Fn32", iree.encoding.resolver = #iree_cpu.cpu_encoding_resolver<>, max_stack_allocation_size = 32768 : i64, native_vector_size = 16 : i64, target_triple = "arm64-unknown-unknown-eabi-elf", ukernels = "none"}>) {
    hal.executable.export public @_encoding_0_encode_500x500xf32_to_500x500xf32 ordinal(0) layout(#hal.pipeline.layout<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device) -> (index, index, index) {
      %c1 = arith.constant 1 : index
      hal.return %c1, %c1, %c1 : index, index, index
    } attributes {workgroup_size = [1 : index, 1 : index, 1 : index]}
    builtin.module attributes {llvm.data_layout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128-Fn32", llvm.target_triple = "arm64-unknown-unknown-eabi-elf"} {
      llvm.func @_encoding_0_encode_500x500xf32_to_500x500xf32(%arg0: !llvm.ptr {llvm.align = 16 : i64, llvm.noalias, llvm.nonnull, llvm.noundef}, %arg1: !llvm.ptr {llvm.align = 16 : i64, llvm.noalias, llvm.nonnull, llvm.noundef}, %arg2: !llvm.ptr {llvm.align = 16 : i64, llvm.noalias, llvm.nonnull, llvm.noundef}) -> i32 {
        %0 = llvm.mlir.constant(0 : i32) : i32
        %1 = llvm.mlir.poison : vector<8xi32>
        %2 = llvm.mlir.constant(4000 : index) : i64
        %3 = llvm.mlir.constant(64 : index) : i64
        %4 = llvm.mlir.constant(true) : i1
        %5 = llvm.mlir.constant(-8 : index) : i64
        %6 = llvm.mlir.constant(dense<0.000000e+00> : vector<8xf32>) : vector<8xf32>
        %7 = llvm.mlir.constant(8 : index) : i64
        %8 = llvm.mlir.constant(2147483647 : index) : i64
        %9 = llvm.mlir.constant(dense<[0, 1, 2, 3, 4, 5, 6, 7]> : vector<8xi32>) : vector<8xi32>
        %10 = llvm.mlir.constant(1 : index) : i64
        %11 = llvm.mlir.constant(500 : index) : i64
        %12 = llvm.mlir.constant(63 : index) : i64
        %13 = llvm.mlir.constant(0 : index) : i64
        %14 = llvm.load %arg1 : !llvm.ptr -> !llvm.struct<"iree_hal_executable_dispatch_state_v0_t", (i32, i32, i16, i16, i32, i32, i16, i8, i8, ptr, ptr, ptr)>
        %15 = llvm.extractvalue %14[10] : !llvm.struct<"iree_hal_executable_dispatch_state_v0_t", (i32, i32, i16, i16, i32, i32, i16, i8, i8, ptr, ptr, ptr)> 
        %16 = llvm.load %15 : !llvm.ptr -> !llvm.ptr
        llvm.intr.assume %4 ["align"(%16, %3 : !llvm.ptr, i64)] : i1
        %17 = llvm.load %arg1 : !llvm.ptr -> !llvm.struct<"iree_hal_executable_dispatch_state_v0_t", (i32, i32, i16, i16, i32, i32, i16, i8, i8, ptr, ptr, ptr)>
        %18 = llvm.extractvalue %17[10] : !llvm.struct<"iree_hal_executable_dispatch_state_v0_t", (i32, i32, i16, i16, i32, i32, i16, i8, i8, ptr, ptr, ptr)> 
        %19 = llvm.getelementptr %18[1] : (!llvm.ptr) -> !llvm.ptr, !llvm.ptr
        %20 = llvm.load %19 : !llvm.ptr -> !llvm.ptr
        llvm.intr.assume %4 ["align"(%20, %3 : !llvm.ptr, i64)] : i1
        llvm.br ^bb1(%13 : i64)
      ^bb1(%21: i64):  // 2 preds: ^bb0, ^bb10
        %22 = llvm.icmp "slt" %21, %12 : i64
        llvm.cond_br %22, ^bb2, ^bb11
      ^bb2:  // pred: ^bb1
        %23 = llvm.mul %21, %7 overflow<nsw> : i64
        %24 = llvm.mul %21, %5 overflow<nsw> : i64
        %25 = llvm.add %24, %11 : i64
        %26 = llvm.intr.smin(%25, %7) : (i64, i64) -> i64
        llvm.br ^bb3(%13 : i64)
      ^bb3(%27: i64):  // 2 preds: ^bb2, ^bb9
        %28 = llvm.icmp "slt" %27, %11 : i64
        llvm.cond_br %28, ^bb4, ^bb10
      ^bb4:  // pred: ^bb3
        %29 = llvm.intr.smin(%26, %8) : (i64, i64) -> i64
        %30 = llvm.trunc %29 : i64 to i32
        %31 = llvm.insertelement %30, %1[%0 : i32] : vector<8xi32>
        %32 = llvm.shufflevector %31, %1 [0, 0, 0, 0, 0, 0, 0, 0] : vector<8xi32> 
        %33 = llvm.icmp "sgt" %32, %9 : vector<8xi32>
        llvm.br ^bb5(%13, %6 : i64, vector<8xf32>)
      ^bb5(%34: i64, %35: vector<8xf32>):  // 2 preds: ^bb4, ^bb8
        %36 = llvm.icmp "slt" %34, %7 : i64
        llvm.cond_br %36, ^bb6, ^bb9
      ^bb6:  // pred: ^bb5
        %37 = llvm.extractelement %33[%34 : i64] : vector<8xi1>
        llvm.cond_br %37, ^bb7, ^bb8(%35 : vector<8xf32>)
      ^bb7:  // pred: ^bb6
        %38 = llvm.add %23, %34 : i64
        %39 = llvm.mul %38, %11 overflow<nsw, nuw> : i64
        %40 = llvm.add %39, %27 overflow<nsw, nuw> : i64
        %41 = llvm.getelementptr inbounds|nuw %16[%40] : (!llvm.ptr, i64) -> !llvm.ptr, f32
        %42 = llvm.load %41 : !llvm.ptr -> f32
        %43 = llvm.insertelement %42, %35[%34 : i64] : vector<8xf32>
        llvm.br ^bb8(%43 : vector<8xf32>)
      ^bb8(%44: vector<8xf32>):  // 2 preds: ^bb6, ^bb7
        %45 = llvm.add %34, %10 : i64
        llvm.br ^bb5(%45, %44 : i64, vector<8xf32>)
      ^bb9:  // pred: ^bb5
        %46 = llvm.mul %21, %2 : i64
        %47 = llvm.mul %27, %7 : i64
        %48 = llvm.add %46, %47 : i64
        %49 = llvm.add %48, %13 : i64
        %50 = llvm.add %49, %13 : i64
        %51 = llvm.getelementptr %20[%50] : (!llvm.ptr, i64) -> !llvm.ptr, f32
        llvm.store %35, %51 {alignment = 4 : i64} : vector<8xf32>, !llvm.ptr
        %52 = llvm.add %27, %10 : i64
        llvm.br ^bb3(%52 : i64)
      ^bb10:  // pred: ^bb3
        %53 = llvm.add %21, %10 : i64
        llvm.br ^bb1(%53 : i64)
      ^bb11:  // pred: ^bb1
        llvm.return %0 : i32
      }
    }
  }
}

