// -----// IR Dump After mlir::iree_compiler::detail::OpPipelineAdaptorPass: iree-op-pipeline-adaptor //----- //
module {
  func.func @_encoding_0_encode_500x500xf32_to_500x500xf32() {
    %cst = arith.constant dense<0.000000e+00> : vector<8xf32>
    %c8 = arith.constant 8 : index
    %c2147483647 = arith.constant 2147483647 : index
    %cst_0 = arith.constant dense<[0, 1, 2, 3, 4, 5, 6, 7]> : vector<8xi32>
    %c1 = arith.constant 1 : index
    %c500 = arith.constant 500 : index
    %c63 = arith.constant 63 : index
    %c0 = arith.constant 0 : index
    %0 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : memref<500x500xf32>
    %assume_align = memref.assume_alignment %0, 64 : memref<500x500xf32>
    %1 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags(Indirect) : memref<63x500x8x1xf32>
    %assume_align_1 = memref.assume_alignment %1, 64 : memref<63x500x8x1xf32>
    scf.for %arg0 = %c0 to %c63 step %c1 {
      %c8_2 = arith.constant 8 : index
      %2 = arith.muli %arg0, %c8_2 overflow<nsw> : index
      %c-8 = arith.constant -8 : index
      %3 = arith.muli %arg0, %c-8 overflow<nsw> : index
      %c500_3 = arith.constant 500 : index
      %4 = arith.addi %3, %c500_3 : index
      %c8_4 = arith.constant 8 : index
      %5 = arith.minsi %4, %c8_4 : index
      scf.for %arg1 = %c0 to %c500 step %c1 {
        %subview = memref.subview %assume_align_1[%arg0, %arg1, 0, 0] [1, 1, 8, 1] [1, 1, 1, 1] : memref<63x500x8x1xf32> to memref<1x1x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>>
        %subview_5 = memref.subview %assume_align[%2, %arg1] [%5, 1] [1, 1] : memref<500x500xf32> to memref<?x1xf32, strided<[500, 1], offset: ?>>
        %subview_6 = memref.subview %subview_5[0, 0] [%5, 1] [1, 1] : memref<?x1xf32, strided<[500, 1], offset: ?>> to memref<?xf32, strided<[500], offset: ?>>
        %6 = arith.minsi %5, %c2147483647 : index
        %7 = arith.index_cast %6 : index to i32
        %8 = vector.broadcast %7 : i32 to vector<8xi32>
        %9 = arith.cmpi sgt, %8, %cst_0 : vector<8xi32>
        %10 = scf.for %arg2 = %c0 to %c8 step %c1 iter_args(%arg3 = %cst) -> (vector<8xf32>) {
          %11 = vector.extract %9[%arg2] : i1 from vector<8xi1>
          %12 = scf.if %11 -> (vector<8xf32>) {
            %13 = memref.load %subview_6[%arg2] : memref<?xf32, strided<[500], offset: ?>>
            %14 = vector.insert %13, %arg3 [%arg2] : f32 into vector<8xf32>
            scf.yield %14 : vector<8xf32>
          } else {
            scf.yield %arg3 : vector<8xf32>
          }
          scf.yield %12 : vector<8xf32>
        }
        %subview_7 = memref.subview %subview[0, 0, 0, 0] [1, 1, 8, 1] [1, 1, 1, 1] : memref<1x1x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>> to memref<1x1x8xf32, strided<[4000, 8, 1], offset: ?>>
        %subview_8 = memref.subview %subview_7[0, 0, 0] [1, 1, 8] [1, 1, 1] : memref<1x1x8xf32, strided<[4000, 8, 1], offset: ?>> to memref<8xf32, affine_map<(d0)[s0] -> (d0 + s0)>>
        vector.store %10, %subview_8[%c0] : memref<8xf32, affine_map<(d0)[s0] -> (d0 + s0)>>, vector<8xf32>
      }
    }
    return
  }
  iree_codegen.dispatch_config @_encoding_0_encode_500x500xf32_to_500x500xf32 workgroup_size = [1, 1, 1] {
  ^bb0(%arg0: !hal.device):
    %c1 = arith.constant 1 : index
    iree_codegen.yield %c1, %c1, %c1 : index, index, index
  }
}

