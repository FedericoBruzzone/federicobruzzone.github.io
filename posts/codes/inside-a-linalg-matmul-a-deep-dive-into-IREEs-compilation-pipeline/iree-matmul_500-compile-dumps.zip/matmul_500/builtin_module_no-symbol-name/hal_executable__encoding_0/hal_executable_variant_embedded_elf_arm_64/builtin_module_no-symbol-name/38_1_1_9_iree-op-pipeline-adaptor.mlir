// -----// IR Dump After mlir::iree_compiler::detail::OpPipelineAdaptorPass: iree-op-pipeline-adaptor //----- //
module {
  func.func @_encoding_0_encode_500x500xf32_to_500x500xf32() {
    %c-8 = arith.constant -8 : index
    %cst = arith.constant dense<0.000000e+00> : vector<8xf32>
    %c8 = arith.constant 8 : index
    %c2147483647 = arith.constant 2147483647 : index
    %cst_0 = arith.constant dense<[0, 1, 2, 3, 4, 5, 6, 7]> : vector<8xi32>
    %c1 = arith.constant 1 : index
    %c500 = arith.constant 500 : index
    %c63 = arith.constant 63 : index
    %c0 = arith.constant 0 : index
    %0 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : memref<500x500xf32>
    %assume_align = memref.assume_alignment %0, 64 : memref<500x500xf32>
    %1 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags(Indirect) : memref<63x500x8x1xf32>
    %assume_align_1 = memref.assume_alignment %1, 64 : memref<63x500x8x1xf32>
    cf.br ^bb1(%c0 : index)
  ^bb1(%2: index):  // 2 preds: ^bb0, ^bb10
    %3 = arith.cmpi slt, %2, %c63 : index
    cf.cond_br %3, ^bb2, ^bb11
  ^bb2:  // pred: ^bb1
    %4 = arith.muli %2, %c8 overflow<nsw> : index
    %5 = arith.muli %2, %c-8 overflow<nsw> : index
    %6 = arith.addi %5, %c500 : index
    %7 = arith.minsi %6, %c8 : index
    cf.br ^bb3(%c0 : index)
  ^bb3(%8: index):  // 2 preds: ^bb2, ^bb9
    %9 = arith.cmpi slt, %8, %c500 : index
    cf.cond_br %9, ^bb4, ^bb10
  ^bb4:  // pred: ^bb3
    %10 = arith.minsi %7, %c2147483647 : index
    %11 = arith.index_cast %10 : index to i32
    %12 = vector.broadcast %11 : i32 to vector<8xi32>
    %13 = arith.cmpi sgt, %12, %cst_0 : vector<8xi32>
    cf.br ^bb5(%c0, %cst : index, vector<8xf32>)
  ^bb5(%14: index, %15: vector<8xf32>):  // 2 preds: ^bb4, ^bb8
    %16 = arith.cmpi slt, %14, %c8 : index
    cf.cond_br %16, ^bb6, ^bb9
  ^bb6:  // pred: ^bb5
    %17 = vector.extract %13[%14] : i1 from vector<8xi1>
    cf.cond_br %17, ^bb7, ^bb8(%15 : vector<8xf32>)
  ^bb7:  // pred: ^bb6
    %18 = affine.apply affine_map<()[s0, s1] -> (s0 + s1)>()[%4, %14]
    %19 = memref.load %assume_align[%18, %8] : memref<500x500xf32>
    %20 = vector.insert %19, %15 [%14] : f32 into vector<8xf32>
    cf.br ^bb8(%20 : vector<8xf32>)
  ^bb8(%21: vector<8xf32>):  // 2 preds: ^bb6, ^bb7
    %22 = arith.addi %14, %c1 : index
    cf.br ^bb5(%22, %21 : index, vector<8xf32>)
  ^bb9:  // pred: ^bb5
    vector.store %15, %assume_align_1[%2, %8, %c0, %c0] : memref<63x500x8x1xf32>, vector<8xf32>
    %23 = arith.addi %8, %c1 : index
    cf.br ^bb3(%23 : index)
  ^bb10:  // pred: ^bb3
    %24 = arith.addi %2, %c1 : index
    cf.br ^bb1(%24 : index)
  ^bb11:  // pred: ^bb1
    return
  }
  iree_codegen.dispatch_config @_encoding_0_encode_500x500xf32_to_500x500xf32 workgroup_size = [1, 1, 1] {
  ^bb0(%arg0: !hal.device):
    %c1 = arith.constant 1 : index
    iree_codegen.yield %c1, %c1, %c1 : index, index, index
  }
}

