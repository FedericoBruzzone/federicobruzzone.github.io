// -----// IR Dump After CanonicalizerPass: canonicalize{cse-between-iterations=false    max-iterations=10 max-num-rewrites=-1 region-simplify=normal test-convergence=false top-down=true} //----- //
func.func @_encoding_0_encode_500x500xf32_to_500x500xf32() attributes {translation_info = #iree_codegen.translation_info<pipeline = #iree_cpu.pipeline<DataTiling>, {enable_decomposition}>} {
  %c1 = arith.constant 1 : index
  %c500 = arith.constant 500 : index
  %c63 = arith.constant 63 : index
  %cst = arith.constant 0.000000e+00 : f32
  %c0 = arith.constant 0 : index
  %0 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : memref<500x500xf32, #hal.descriptor_type<storage_buffer>>
  %assume_align = memref.assume_alignment %0, 64 : memref<500x500xf32, #hal.descriptor_type<storage_buffer>>
  %1 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags(Indirect) : memref<63x500x8x1xf32, #hal.descriptor_type<storage_buffer>>
  %assume_align_0 = memref.assume_alignment %1, 64 : memref<63x500x8x1xf32, #hal.descriptor_type<storage_buffer>>
  scf.for %arg0 = %c0 to %c63 step %c1 {
    %2 = affine.apply affine_map<(d0) -> (d0 * 8)>(%arg0)
    %3 = affine.min affine_map<(d0) -> (d0 * -8 + 500, 8)>(%arg0)
    scf.for %arg1 = %c0 to %c500 step %c1 {
      %subview = memref.subview %assume_align_0[%arg0, %arg1, 0, 0] [1, 1, 8, 1] [1, 1, 1, 1] : memref<63x500x8x1xf32, #hal.descriptor_type<storage_buffer>> to memref<1x1x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
      %subview_1 = memref.subview %assume_align[%2, %arg1] [%3, 1] [1, 1] : memref<500x500xf32, #hal.descriptor_type<storage_buffer>> to memref<?x1xf32, strided<[500, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
      %subview_2 = memref.subview %subview_1[0, 0] [%3, 1] [1, 1] : memref<?x1xf32, strided<[500, 1], offset: ?>, #hal.descriptor_type<storage_buffer>> to memref<?xf32, strided<[500], offset: ?>, #hal.descriptor_type<storage_buffer>>
      %4 = vector.create_mask %3 : vector<8xi1>
      %5 = vector.transfer_read %subview_2[%c0], %cst, %4 {in_bounds = [true]} : memref<?xf32, strided<[500], offset: ?>, #hal.descriptor_type<storage_buffer>>, vector<8xf32>
      %subview_3 = memref.subview %subview[0, 0, 0, 0] [1, 1, 8, 1] [1, 1, 1, 1] : memref<1x1x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>, #hal.descriptor_type<storage_buffer>> to memref<1x1x8xf32, strided<[4000, 8, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
      %subview_4 = memref.subview %subview_3[0, 0, 0] [1, 1, 8] [1, 1, 1] : memref<1x1x8xf32, strided<[4000, 8, 1], offset: ?>, #hal.descriptor_type<storage_buffer>> to memref<8xf32, affine_map<(d0)[s0] -> (d0 + s0)>, #hal.descriptor_type<storage_buffer>>
      vector.transfer_write %5, %subview_4[%c0] {in_bounds = [true]} : vector<8xf32>, memref<8xf32, affine_map<(d0)[s0] -> (d0 + s0)>, #hal.descriptor_type<storage_buffer>>
    }
  }
  return
}

