// -----// IR Dump After LLVMCPULowerExecutableTargetPass: iree-llvmcpu-lower-executable-target{cpu-options=opaque} //----- //
func.func @_encoding_0_encode_500x500xf32_to_500x500xf32() attributes {translation_info = #iree_codegen.translation_info<pipeline = #iree_cpu.pipeline<DataTiling>, {enable_decomposition}>} {
  %cst = arith.constant dense<0.000000e+00> : vector<8xf32>
  %c8 = arith.constant 8 : index
  %c2147483647 = arith.constant 2147483647 : index
  %cst_0 = arith.constant dense<[0, 1, 2, 3, 4, 5, 6, 7]> : vector<8xi32>
  %c1 = arith.constant 1 : index
  %c500 = arith.constant 500 : index
  %c63 = arith.constant 63 : index
  %c0 = arith.constant 0 : index
  %0 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : memref<500x500xf32, #hal.descriptor_type<storage_buffer>>
  %assume_align = memref.assume_alignment %0, 64 : memref<500x500xf32, #hal.descriptor_type<storage_buffer>>
  %1 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags(Indirect) : memref<63x500x8x1xf32, #hal.descriptor_type<storage_buffer>>
  %assume_align_1 = memref.assume_alignment %1, 64 : memref<63x500x8x1xf32, #hal.descriptor_type<storage_buffer>>
  scf.for %arg0 = %c0 to %c63 step %c1 {
    %2 = affine.apply affine_map<(d0) -> (d0 * 8)>(%arg0)
    %3 = affine.min affine_map<(d0) -> (d0 * -8 + 500, 8)>(%arg0)
    scf.for %arg1 = %c0 to %c500 step %c1 {
      %subview = memref.subview %assume_align_1[%arg0, %arg1, 0, 0] [1, 1, 8, 1] [1, 1, 1, 1] : memref<63x500x8x1xf32, #hal.descriptor_type<storage_buffer>> to memref<1x1x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
      %subview_2 = memref.subview %assume_align[%2, %arg1] [%3, 1] [1, 1] : memref<500x500xf32, #hal.descriptor_type<storage_buffer>> to memref<?x1xf32, strided<[500, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
      %subview_3 = memref.subview %subview_2[0, 0] [%3, 1] [1, 1] : memref<?x1xf32, strided<[500, 1], offset: ?>, #hal.descriptor_type<storage_buffer>> to memref<?xf32, strided<[500], offset: ?>, #hal.descriptor_type<storage_buffer>>
      %4 = arith.minsi %3, %c2147483647 : index
      %5 = arith.index_cast %4 : index to i32
      %6 = vector.broadcast %5 : i32 to vector<8xi32>
      %7 = arith.cmpi sgt, %6, %cst_0 : vector<8xi32>
      %8 = scf.for %arg2 = %c0 to %c8 step %c1 iter_args(%arg3 = %cst) -> (vector<8xf32>) {
        %9 = vector.extract %7[%arg2] : i1 from vector<8xi1>
        %10 = scf.if %9 -> (vector<8xf32>) {
          %11 = memref.load %subview_3[%arg2] : memref<?xf32, strided<[500], offset: ?>, #hal.descriptor_type<storage_buffer>>
          %12 = vector.insert %11, %arg3 [%arg2] : f32 into vector<8xf32>
          scf.yield %12 : vector<8xf32>
        } else {
          scf.yield %arg3 : vector<8xf32>
        }
        scf.yield %10 : vector<8xf32>
      }
      %subview_4 = memref.subview %subview[0, 0, 0, 0] [1, 1, 8, 1] [1, 1, 1, 1] : memref<1x1x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>, #hal.descriptor_type<storage_buffer>> to memref<1x1x8xf32, strided<[4000, 8, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
      %subview_5 = memref.subview %subview_4[0, 0, 0] [1, 1, 8] [1, 1, 1] : memref<1x1x8xf32, strided<[4000, 8, 1], offset: ?>, #hal.descriptor_type<storage_buffer>> to memref<8xf32, affine_map<(d0)[s0] -> (d0 + s0)>, #hal.descriptor_type<storage_buffer>>
      vector.store %8, %subview_5[%c0] : memref<8xf32, affine_map<(d0)[s0] -> (d0 + s0)>, #hal.descriptor_type<storage_buffer>>, vector<8xf32>
    }
  }
  return
}

