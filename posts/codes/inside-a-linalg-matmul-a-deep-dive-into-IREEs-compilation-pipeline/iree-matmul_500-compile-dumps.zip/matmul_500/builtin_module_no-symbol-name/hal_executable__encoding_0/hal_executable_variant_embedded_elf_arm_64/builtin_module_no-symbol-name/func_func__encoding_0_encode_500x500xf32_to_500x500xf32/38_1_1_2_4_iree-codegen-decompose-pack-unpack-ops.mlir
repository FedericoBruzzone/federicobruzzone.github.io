// -----// IR Dump After DecomposePackUnPackOpsPass: iree-codegen-decompose-pack-unpack-ops{tile-outer-to-one=false use-only-reshapes=false} //----- //
func.func @_encoding_0_encode_500x500xf32_to_500x500xf32() attributes {translation_info = #iree_codegen.translation_info<pipeline = #iree_cpu.pipeline<DataTiling>, {enable_decomposition}>} {
  %c1 = arith.constant 1 : index
  %c500 = arith.constant 500 : index
  %c63 = arith.constant 63 : index
  %cst = arith.constant 0.000000e+00 : f32
  %c0 = arith.constant 0 : index
  %0 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : memref<500x500xf32, #hal.descriptor_type<storage_buffer>>
  %1 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags(Indirect) : memref<63x500x8x1xf32, #hal.descriptor_type<storage_buffer>>
  %2 = iree_codegen.load_from_buffer %0 : memref<500x500xf32, #hal.descriptor_type<storage_buffer>> -> tensor<500x500xf32>
  %3 = tensor.empty() : tensor<63x500x8x1xf32>
  %4 = scf.for %arg0 = %c0 to %c63 step %c1 iter_args(%arg1 = %3) -> (tensor<63x500x8x1xf32>) {
    %5 = scf.for %arg2 = %c0 to %c500 step %c1 iter_args(%arg3 = %arg1) -> (tensor<63x500x8x1xf32>) {
      %6 = affine.apply affine_map<(d0) -> (d0 * 8)>(%arg0)
      %7 = affine.min affine_map<(d0) -> (d0 * -8 + 500, 8)>(%arg0)
      %extracted_slice = tensor.extract_slice %2[%6, %arg2] [%7, 1] [1, 1] : tensor<500x500xf32> to tensor<?x1xf32>
      %extracted_slice_0 = tensor.extract_slice %arg3[%arg0, %arg2, 0, 0] [1, 1, 8, 1] [1, 1, 1, 1] : tensor<63x500x8x1xf32> to tensor<1x1x8x1xf32>
      %8 = affine.apply affine_map<(d0) -> (-d0 + 8)>(%7)
      %padded = tensor.pad %extracted_slice low[0, 0] high[%8, 0] {
      ^bb0(%arg4: index, %arg5: index):
        tensor.yield %cst : f32
      } : tensor<?x1xf32> to tensor<8x1xf32>
      %inserted_slice = tensor.insert_slice %padded into %extracted_slice_0[0, 0, 0, 0] [1, 1, 8, 1] [1, 1, 1, 1] : tensor<8x1xf32> into tensor<1x1x8x1xf32>
      %inserted_slice_1 = tensor.insert_slice %inserted_slice into %arg3[%arg0, %arg2, 0, 0] [1, 1, 8, 1] [1, 1, 1, 1] : tensor<1x1x8x1xf32> into tensor<63x500x8x1xf32>
      scf.yield %inserted_slice_1 : tensor<63x500x8x1xf32>
    }
    scf.yield %5 : tensor<63x500x8x1xf32>
  }
  iree_codegen.store_to_buffer %4, %1 : tensor<63x500x8x1xf32> into memref<63x500x8x1xf32, #hal.descriptor_type<storage_buffer>>
  return
}

