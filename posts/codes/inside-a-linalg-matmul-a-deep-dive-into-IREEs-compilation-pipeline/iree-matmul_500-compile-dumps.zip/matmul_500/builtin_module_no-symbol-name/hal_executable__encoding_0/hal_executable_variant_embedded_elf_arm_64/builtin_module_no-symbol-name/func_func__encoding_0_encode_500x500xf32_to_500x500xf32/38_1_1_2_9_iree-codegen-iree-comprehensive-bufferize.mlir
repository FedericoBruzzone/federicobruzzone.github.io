// -----// IR Dump After IREEComprehensiveBufferizePass: iree-codegen-iree-comprehensive-bufferize{print-conflicts=false test-analysis-only=false} //----- //
func.func @_encoding_0_encode_500x500xf32_to_500x500xf32() attributes {translation_info = #iree_codegen.translation_info<pipeline = #iree_cpu.pipeline<DataTiling>, {enable_decomposition}>} {
  %c1 = arith.constant 1 : index
  %c500 = arith.constant 500 : index
  %c63 = arith.constant 63 : index
  %cst = arith.constant 0.000000e+00 : f32
  %c0 = arith.constant 0 : index
  %0 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : memref<500x500xf32, #hal.descriptor_type<storage_buffer>>
  %1 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags(Indirect) : memref<63x500x8x1xf32, #hal.descriptor_type<storage_buffer>>
  %2 = scf.for %arg0 = %c0 to %c63 step %c1 iter_args(%arg1 = %1) -> (memref<63x500x8x1xf32, #hal.descriptor_type<storage_buffer>>) {
    %3 = affine.apply affine_map<(d0) -> (d0 * 8)>(%arg0)
    %4 = affine.min affine_map<(d0) -> (d0 * -8 + 500, 8)>(%arg0)
    %5 = vector.create_mask %4, %c1 : vector<8x1xi1>
    %6 = scf.for %arg2 = %c0 to %c500 step %c1 iter_args(%arg3 = %arg1) -> (memref<63x500x8x1xf32, #hal.descriptor_type<storage_buffer>>) {
      %subview = memref.subview %arg3[%arg0, %arg2, 0, 0] [1, 1, 8, 1] [1, 1, 1, 1] : memref<63x500x8x1xf32, #hal.descriptor_type<storage_buffer>> to memref<1x1x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
      %subview_0 = memref.subview %0[%3, %arg2] [%4, 1] [1, 1] : memref<500x500xf32, #hal.descriptor_type<storage_buffer>> to memref<?x1xf32, strided<[500, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
      %7 = vector.transfer_read %subview_0[%c0, %c0], %cst, %5 {in_bounds = [true, true]} : memref<?x1xf32, strided<[500, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>, vector<8x1xf32>
      vector.transfer_write %7, %subview[%c0, %c0, %c0, %c0] {in_bounds = [true, true]} : vector<8x1xf32>, memref<1x1x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
      %subview_1 = memref.subview %arg3[%arg0, %arg2, 0, 0] [1, 1, 8, 1] [1, 1, 1, 1] : memref<63x500x8x1xf32, #hal.descriptor_type<storage_buffer>> to memref<1x1x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
      linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%subview : memref<1x1x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>) outs(%subview_1 : memref<1x1x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>) {
      ^bb0(%in: f32, %out: f32):
        linalg.yield %in : f32
      }
      scf.yield %arg3 : memref<63x500x8x1xf32, #hal.descriptor_type<storage_buffer>>
    }
    scf.yield %6 : memref<63x500x8x1xf32, #hal.descriptor_type<storage_buffer>>
  }
  linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%2 : memref<63x500x8x1xf32, #hal.descriptor_type<storage_buffer>>) outs(%1 : memref<63x500x8x1xf32, #hal.descriptor_type<storage_buffer>>) {
  ^bb0(%in: f32, %out: f32):
    linalg.yield %in : f32
  }
  return
}

