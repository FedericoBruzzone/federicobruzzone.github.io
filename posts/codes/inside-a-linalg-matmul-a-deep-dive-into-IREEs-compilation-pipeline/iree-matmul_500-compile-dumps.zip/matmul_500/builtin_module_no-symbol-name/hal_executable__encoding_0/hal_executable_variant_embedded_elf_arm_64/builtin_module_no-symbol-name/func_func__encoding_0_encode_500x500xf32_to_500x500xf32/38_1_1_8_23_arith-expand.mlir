// -----// IR Dump After ArithExpandOpsPass: arith-expand{include-bf16=true include-f4e2m1=false include-f8e8m0=true include-flush-denormals=false} //----- //
func.func @_encoding_0_encode_500x500xf32_to_500x500xf32() {
  %c-8 = arith.constant -8 : index
  %cst = arith.constant dense<0.000000e+00> : vector<8xf32>
  %c8 = arith.constant 8 : index
  %c2147483647 = arith.constant 2147483647 : index
  %cst_0 = arith.constant dense<[0, 1, 2, 3, 4, 5, 6, 7]> : vector<8xi32>
  %c1 = arith.constant 1 : index
  %c500 = arith.constant 500 : index
  %c63 = arith.constant 63 : index
  %c0 = arith.constant 0 : index
  %0 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : memref<500x500xf32>
  %assume_align = memref.assume_alignment %0, 64 : memref<500x500xf32>
  %1 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags(Indirect) : memref<63x500x8x1xf32>
  %assume_align_1 = memref.assume_alignment %1, 64 : memref<63x500x8x1xf32>
  cf.br ^bb1(%c0 : index)
^bb1(%2: index):  // 2 preds: ^bb0, ^bb10
  %3 = arith.cmpi slt, %2, %c63 : index
  cf.cond_br %3, ^bb2, ^bb11
^bb2:  // pred: ^bb1
  %4 = arith.muli %2, %c8 overflow<nsw> : index
  %5 = arith.muli %2, %c-8 overflow<nsw> : index
  %6 = arith.addi %5, %c500 : index
  %7 = arith.cmpi slt, %6, %c8 : index
  %8 = arith.select %7, %6, %c8 : index
  cf.br ^bb3(%c0 : index)
^bb3(%9: index):  // 2 preds: ^bb2, ^bb9
  %10 = arith.cmpi slt, %9, %c500 : index
  cf.cond_br %10, ^bb4, ^bb10
^bb4:  // pred: ^bb3
  %11 = arith.cmpi slt, %8, %c2147483647 : index
  %12 = arith.select %11, %8, %c2147483647 : index
  %13 = arith.index_cast %12 : index to i32
  %14 = vector.broadcast %13 : i32 to vector<8xi32>
  %15 = arith.cmpi sgt, %14, %cst_0 : vector<8xi32>
  cf.br ^bb5(%c0, %cst : index, vector<8xf32>)
^bb5(%16: index, %17: vector<8xf32>):  // 2 preds: ^bb4, ^bb8
  %18 = arith.cmpi slt, %16, %c8 : index
  cf.cond_br %18, ^bb6, ^bb9
^bb6:  // pred: ^bb5
  %19 = vector.extract %15[%16] : i1 from vector<8xi1>
  cf.cond_br %19, ^bb7, ^bb8(%17 : vector<8xf32>)
^bb7:  // pred: ^bb6
  %20 = affine.apply affine_map<()[s0, s1] -> (s0 + s1)>()[%4, %16]
  %21 = memref.load %assume_align[%20, %9] : memref<500x500xf32>
  %22 = vector.insert %21, %17 [%16] : f32 into vector<8xf32>
  cf.br ^bb8(%22 : vector<8xf32>)
^bb8(%23: vector<8xf32>):  // 2 preds: ^bb6, ^bb7
  %24 = arith.addi %16, %c1 : index
  cf.br ^bb5(%24, %23 : index, vector<8xf32>)
^bb9:  // pred: ^bb5
  vector.store %17, %assume_align_1[%2, %9, %c0, %c0] : memref<63x500x8x1xf32>, vector<8xf32>
  %25 = arith.addi %9, %c1 : index
  cf.br ^bb3(%25 : index)
^bb10:  // pred: ^bb3
  %26 = arith.addi %2, %c1 : index
  cf.br ^bb1(%26 : index)
^bb11:  // pred: ^bb1
  return
}

