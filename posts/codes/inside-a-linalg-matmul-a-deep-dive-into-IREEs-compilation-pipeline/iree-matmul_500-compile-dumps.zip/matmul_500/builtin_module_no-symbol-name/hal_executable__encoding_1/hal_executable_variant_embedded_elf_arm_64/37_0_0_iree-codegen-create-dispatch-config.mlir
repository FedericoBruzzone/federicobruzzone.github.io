// -----// IR Dump After CreateDispatchConfigPass: iree-codegen-create-dispatch-config //----- //
hal.executable.variant public @embedded_elf_arm_64 target(<"llvm-cpu", "embedded-elf-arm_64", {cpu = "apple-m4", cpu_features = "+v8.7a,+aes,+bf16,+complxnum,+crc,+dotprod,+fp-armv8,+fp16fml,+fpac,+fullfp16,+i8mm,+jsconv,+lse,+neon,+pauth,+perfmon,+ras,+rcpc,+rdm,+sha2,+sha3,+sme,+sme-f64f64,+sme-i16i64,+sme2,+reserve-x18", data_layout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128-Fn32", iree.encoding.resolver = #iree_cpu.cpu_encoding_resolver<>, max_stack_allocation_size = 32768 : i64, native_vector_size = 16 : i64, target_triple = "arm64-unknown-unknown-eabi-elf", ukernels = "none"}>) {
  hal.executable.export public @_encoding_1_encode_500x500xf32_to_500x500xf32 ordinal(0) layout(#hal.pipeline.layout<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device) -> (index, index, index) {
    %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice()
    hal.return %x, %y, %z : index, index, index
  }
  builtin.module {
    func.func @_encoding_1_encode_500x500xf32_to_500x500xf32() {
      %c0 = arith.constant 0 : index
      %c1008000 = arith.constant 1008000 : index
      %0 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<500x500xf32>>
      %1 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c1008000) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<500x500xf32, #iree_encoding.layout<[#iree_cpu.cpu_encoding_resolver<configuration = {encoding_info = {innerDimsPos = [1, 0], innerTileSizes = [8, 1], outerDimsPerm = [1, 0]}}>]>>>
      %2 = iree_tensor_ext.dispatch.tensor.load %0, offsets = [0, 0], sizes = [500, 500], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<500x500xf32>> -> tensor<500x500xf32>
      %3 = iree_encoding.set_encoding %2 : tensor<500x500xf32> -> tensor<500x500xf32, #iree_encoding.layout<[#iree_cpu.cpu_encoding_resolver<configuration = {encoding_info = {innerDimsPos = [1, 0], innerTileSizes = [8, 1], outerDimsPerm = [1, 0]}}>]>>
      iree_tensor_ext.dispatch.tensor.store %3, %1, offsets = [0, 0], sizes = [500, 500], strides = [1, 1] : tensor<500x500xf32, #iree_encoding.layout<[#iree_cpu.cpu_encoding_resolver<configuration = {encoding_info = {innerDimsPos = [1, 0], innerTileSizes = [8, 1], outerDimsPerm = [1, 0]}}>]>> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<500x500xf32, #iree_encoding.layout<[#iree_cpu.cpu_encoding_resolver<configuration = {encoding_info = {innerDimsPos = [1, 0], innerTileSizes = [8, 1], outerDimsPerm = [1, 0]}}>]>>>
      return
    }
    iree_codegen.dispatch_config @_encoding_1_encode_500x500xf32_to_500x500xf32 {
    ^bb0(%arg0: !hal.device):
      %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice()
      iree_codegen.yield %x, %y, %z : index, index, index
    }
  }
}

