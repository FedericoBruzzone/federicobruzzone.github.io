// -----// IR Dump After PropagateDispatchConfigPass: iree-codegen-propagate-dispatch-config //----- //
hal.executable.variant public @embedded_elf_arm_64 target(<"llvm-cpu", "embedded-elf-arm_64", {cpu = "apple-m4", cpu_features = "+v8.7a,+aes,+bf16,+complxnum,+crc,+dotprod,+fp-armv8,+fp16fml,+fpac,+fullfp16,+i8mm,+jsconv,+lse,+neon,+pauth,+perfmon,+ras,+rcpc,+rdm,+sha2,+sha3,+sme,+sme-f64f64,+sme-i16i64,+sme2,+reserve-x18", data_layout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128-Fn32", iree.encoding.resolver = #iree_cpu.cpu_encoding_resolver<>, max_stack_allocation_size = 32768 : i64, native_vector_size = 16 : i64, target_triple = "arm64-unknown-unknown-eabi-elf", ukernels = "none"}>) {
  hal.executable.export public @_encoding_1_encode_500x500xf32_to_500x500xf32 ordinal(0) layout(#hal.pipeline.layout<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device) -> (index, index, index) {
    %c1 = arith.constant 1 : index
    hal.return %c1, %c1, %c1 : index, index, index
  } attributes {workgroup_size = [1 : index, 1 : index, 1 : index]}
  builtin.module attributes {llvm.data_layout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128-Fn32", llvm.target_triple = "arm64-unknown-unknown-eabi-elf"} {
    llvm.func @_encoding_1_encode_500x500xf32_to_500x500xf32(%arg0: !llvm.ptr {llvm.align = 16 : i64, llvm.noalias, llvm.nonnull, llvm.noundef}, %arg1: !llvm.ptr {llvm.align = 16 : i64, llvm.noalias, llvm.nonnull, llvm.noundef}, %arg2: !llvm.ptr {llvm.align = 16 : i64, llvm.noalias, llvm.nonnull, llvm.noundef}) -> i32 {
      %0 = llvm.mlir.constant(0 : i32) : i32
      %1 = llvm.mlir.poison : vector<8xi32>
      %2 = llvm.mlir.constant(4000 : index) : i64
      %3 = llvm.mlir.constant(64 : index) : i64
      %4 = llvm.mlir.constant(true) : i1
      %5 = llvm.mlir.constant(-8 : index) : i64
      %6 = llvm.mlir.constant(8 : index) : i64
      %7 = llvm.mlir.constant(dense<0.000000e+00> : vector<8xf32>) : vector<8xf32>
      %8 = llvm.mlir.constant(2147483647 : index) : i64
      %9 = llvm.mlir.constant(dense<[0, 1, 2, 3, 4, 5, 6, 7]> : vector<8xi32>) : vector<8xi32>
      %10 = llvm.mlir.constant(1 : index) : i64
      %11 = llvm.mlir.constant(500 : index) : i64
      %12 = llvm.mlir.constant(63 : index) : i64
      %13 = llvm.mlir.constant(0 : index) : i64
      %14 = llvm.load %arg1 : !llvm.ptr -> !llvm.struct<"iree_hal_executable_dispatch_state_v0_t", (i32, i32, i16, i16, i32, i32, i16, i8, i8, ptr, ptr, ptr)>
      %15 = llvm.extractvalue %14[10] : !llvm.struct<"iree_hal_executable_dispatch_state_v0_t", (i32, i32, i16, i16, i32, i32, i16, i8, i8, ptr, ptr, ptr)> 
      %16 = llvm.load %15 : !llvm.ptr -> !llvm.ptr
      llvm.intr.assume %4 ["align"(%16, %3 : !llvm.ptr, i64)] : i1
      %17 = llvm.load %arg1 : !llvm.ptr -> !llvm.struct<"iree_hal_executable_dispatch_state_v0_t", (i32, i32, i16, i16, i32, i32, i16, i8, i8, ptr, ptr, ptr)>
      %18 = llvm.extractvalue %17[10] : !llvm.struct<"iree_hal_executable_dispatch_state_v0_t", (i32, i32, i16, i16, i32, i32, i16, i8, i8, ptr, ptr, ptr)> 
      %19 = llvm.getelementptr %18[1] : (!llvm.ptr) -> !llvm.ptr, !llvm.ptr
      %20 = llvm.load %19 : !llvm.ptr -> !llvm.ptr
      %21 = llvm.getelementptr %20[1008000] : (!llvm.ptr) -> !llvm.ptr, i8
      llvm.intr.assume %4 ["align"(%21, %3 : !llvm.ptr, i64)] : i1
      llvm.br ^bb1(%13 : i64)
    ^bb1(%22: i64):  // 2 preds: ^bb0, ^bb5
      %23 = llvm.icmp "slt" %22, %12 : i64
      llvm.cond_br %23, ^bb2, ^bb6
    ^bb2:  // pred: ^bb1
      %24 = llvm.mul %22, %6 overflow<nsw> : i64
      %25 = llvm.mul %22, %5 overflow<nsw> : i64
      %26 = llvm.add %25, %11 : i64
      %27 = llvm.intr.smin(%26, %6) : (i64, i64) -> i64
      llvm.br ^bb3(%13 : i64)
    ^bb3(%28: i64):  // 2 preds: ^bb2, ^bb4
      %29 = llvm.icmp "slt" %28, %11 : i64
      llvm.cond_br %29, ^bb4, ^bb5
    ^bb4:  // pred: ^bb3
      %30 = llvm.intr.smin(%27, %8) : (i64, i64) -> i64
      %31 = llvm.trunc %30 : i64 to i32
      %32 = llvm.insertelement %31, %1[%0 : i32] : vector<8xi32>
      %33 = llvm.shufflevector %32, %1 [0, 0, 0, 0, 0, 0, 0, 0] : vector<8xi32> 
      %34 = llvm.icmp "sgt" %33, %9 : vector<8xi32>
      %35 = llvm.mul %28, %11 : i64
      %36 = llvm.add %35, %24 : i64
      %37 = llvm.getelementptr %16[%36] : (!llvm.ptr, i64) -> !llvm.ptr, f32
      %38 = llvm.intr.masked.load %37, %34, %7 {alignment = 4 : i32} : (!llvm.ptr, vector<8xi1>, vector<8xf32>) -> vector<8xf32>
      %39 = llvm.mul %22, %2 : i64
      %40 = llvm.mul %28, %6 : i64
      %41 = llvm.add %39, %40 : i64
      %42 = llvm.add %41, %13 : i64
      %43 = llvm.add %42, %13 : i64
      %44 = llvm.getelementptr %21[%43] : (!llvm.ptr, i64) -> !llvm.ptr, f32
      llvm.store %38, %44 {alignment = 4 : i64} : vector<8xf32>, !llvm.ptr
      %45 = llvm.add %28, %10 : i64
      llvm.br ^bb3(%45 : i64)
    ^bb5:  // pred: ^bb3
      %46 = llvm.add %22, %10 : i64
      llvm.br ^bb1(%46 : i64)
    ^bb6:  // pred: ^bb1
      llvm.return %0 : i32
    }
  }
}

