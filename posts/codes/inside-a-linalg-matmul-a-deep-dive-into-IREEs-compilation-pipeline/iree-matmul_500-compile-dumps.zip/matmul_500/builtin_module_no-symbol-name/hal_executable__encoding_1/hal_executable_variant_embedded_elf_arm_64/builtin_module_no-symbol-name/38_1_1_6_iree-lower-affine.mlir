// -----// IR Dump After IREELowerAffinePass: iree-lower-affine //----- //
module {
  func.func @_encoding_1_encode_500x500xf32_to_500x500xf32() {
    %cst = arith.constant dense<0.000000e+00> : vector<8xf32>
    %c2147483647 = arith.constant 2147483647 : index
    %cst_0 = arith.constant dense<[0, 1, 2, 3, 4, 5, 6, 7]> : vector<8xi32>
    %c1 = arith.constant 1 : index
    %c500 = arith.constant 500 : index
    %c63 = arith.constant 63 : index
    %c0 = arith.constant 0 : index
    %c1008000 = arith.constant 1008000 : index
    %0 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : memref<500x500xf32, #hal.descriptor_type<storage_buffer>>
    %assume_align = memref.assume_alignment %0, 64 : memref<500x500xf32, #hal.descriptor_type<storage_buffer>>
    %1 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c1008000) flags(Indirect) : memref<63x500x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
    %assume_align_1 = memref.assume_alignment %1, 64 : memref<63x500x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
    scf.for %arg0 = %c0 to %c63 step %c1 {
      %c8 = arith.constant 8 : index
      %2 = arith.muli %arg0, %c8 overflow<nsw> : index
      %c-8 = arith.constant -8 : index
      %3 = arith.muli %arg0, %c-8 overflow<nsw> : index
      %c500_2 = arith.constant 500 : index
      %4 = arith.addi %3, %c500_2 : index
      %c8_3 = arith.constant 8 : index
      %5 = arith.minsi %4, %c8_3 : index
      scf.for %arg1 = %c0 to %c500 step %c1 {
        %subview = memref.subview %assume_align_1[%arg0, %arg1, 0, 0] [1, 1, 8, 1] [1, 1, 1, 1] : memref<63x500x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>, #hal.descriptor_type<storage_buffer>> to memref<1x1x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
        %subview_4 = memref.subview %assume_align[%arg1, %2] [1, %5] [1, 1] : memref<500x500xf32, #hal.descriptor_type<storage_buffer>> to memref<1x?xf32, strided<[500, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
        %6 = arith.minsi %5, %c2147483647 : index
        %7 = arith.index_cast %6 : index to i32
        %8 = vector.broadcast %7 : i32 to vector<8xi32>
        %9 = arith.cmpi sgt, %8, %cst_0 : vector<8xi32>
        %subview_5 = memref.subview %subview_4[0, 0] [1, %5] [1, 1] : memref<1x?xf32, strided<[500, 1], offset: ?>, #hal.descriptor_type<storage_buffer>> to memref<?xf32, affine_map<(d0)[s0] -> (d0 + s0)>, #hal.descriptor_type<storage_buffer>>
        %10 = vector.maskedload %subview_5[%c0], %9, %cst : memref<?xf32, affine_map<(d0)[s0] -> (d0 + s0)>, #hal.descriptor_type<storage_buffer>>, vector<8xi1>, vector<8xf32> into vector<8xf32>
        %subview_6 = memref.subview %subview[0, 0, 0, 0] [1, 1, 8, 1] [1, 1, 1, 1] : memref<1x1x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>, #hal.descriptor_type<storage_buffer>> to memref<1x1x8xf32, strided<[4000, 8, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
        %subview_7 = memref.subview %subview_6[0, 0, 0] [1, 1, 8] [1, 1, 1] : memref<1x1x8xf32, strided<[4000, 8, 1], offset: ?>, #hal.descriptor_type<storage_buffer>> to memref<8xf32, affine_map<(d0)[s0] -> (d0 + s0)>, #hal.descriptor_type<storage_buffer>>
        vector.store %10, %subview_7[%c0] : memref<8xf32, affine_map<(d0)[s0] -> (d0 + s0)>, #hal.descriptor_type<storage_buffer>>, vector<8xf32>
      }
    }
    return
  }
  iree_codegen.dispatch_config @_encoding_1_encode_500x500xf32_to_500x500xf32 workgroup_size = [1, 1, 1] {
  ^bb0(%arg0: !hal.device):
    %c1 = arith.constant 1 : index
    iree_codegen.yield %c1, %c1, %c1 : index, index, index
  }
}

