// -----// IR Dump After MaterializeDeviceEncodingPass: iree-codegen-materialize-device-encoding{test-gpu-encoding-resolver=none} //----- //
func.func @_encoding_1_encode_500x500xf32_to_500x500xf32() {
  %cst = arith.constant 0.000000e+00 : f32
  %c0 = arith.constant 0 : index
  %c1008000 = arith.constant 1008000 : index
  %0 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<500x500xf32>>
  %1 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c1008000) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<63x500x8x1xf32>>
  %2 = iree_tensor_ext.dispatch.tensor.load %0, offsets = [0, 0], sizes = [500, 500], strides = [1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<500x500xf32>> -> tensor<500x500xf32>
  %3 = tensor.empty() : tensor<63x500x8x1xf32>
  %pack = linalg.pack %2 padding_value(%cst : f32) outer_dims_perm = [1, 0] inner_dims_pos = [1, 0] inner_tiles = [8, 1] into %3 : tensor<500x500xf32> -> tensor<63x500x8x1xf32>
  iree_tensor_ext.dispatch.tensor.store %pack, %1, offsets = [0, 0, 0, 0], sizes = [63, 500, 8, 1], strides = [1, 1, 1, 1] : tensor<63x500x8x1xf32> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<63x500x8x1xf32>>
  return
}

