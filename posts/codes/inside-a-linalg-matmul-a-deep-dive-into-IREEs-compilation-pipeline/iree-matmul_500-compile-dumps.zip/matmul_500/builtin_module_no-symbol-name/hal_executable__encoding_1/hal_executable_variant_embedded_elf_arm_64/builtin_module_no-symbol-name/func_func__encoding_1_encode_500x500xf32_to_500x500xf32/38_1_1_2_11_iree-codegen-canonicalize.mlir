// -----// IR Dump After IREECodegenCanonicalizerPass: iree-codegen-canonicalize{test-convergence=false} //----- //
func.func @_encoding_1_encode_500x500xf32_to_500x500xf32() attributes {translation_info = #iree_codegen.translation_info<pipeline = #iree_cpu.pipeline<DataTiling>, {enable_decomposition}>} {
  %c1 = arith.constant 1 : index
  %c500 = arith.constant 500 : index
  %c63 = arith.constant 63 : index
  %cst = arith.constant 0.000000e+00 : f32
  %c0 = arith.constant 0 : index
  %c1008000 = arith.constant 1008000 : index
  %0 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : memref<500x500xf32, #hal.descriptor_type<storage_buffer>>
  %assume_align = memref.assume_alignment %0, 64 : memref<500x500xf32, #hal.descriptor_type<storage_buffer>>
  %1 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c1008000) flags(Indirect) : memref<63x500x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
  %assume_align_0 = memref.assume_alignment %1, 64 : memref<63x500x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
  scf.for %arg0 = %c0 to %c63 step %c1 {
    %2 = affine.apply affine_map<(d0) -> (d0 * 8)>(%arg0)
    %3 = affine.min affine_map<(d0) -> (d0 * -8 + 500, 8)>(%arg0)
    %4 = vector.create_mask %c1, %3 : vector<1x8xi1>
    scf.for %arg1 = %c0 to %c500 step %c1 {
      %subview = memref.subview %assume_align_0[%arg0, %arg1, 0, 0] [1, 1, 8, 1] [1, 1, 1, 1] : memref<63x500x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>, #hal.descriptor_type<storage_buffer>> to memref<1x1x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
      %subview_1 = memref.subview %assume_align[%arg1, %2] [1, %3] [1, 1] : memref<500x500xf32, #hal.descriptor_type<storage_buffer>> to memref<1x?xf32, strided<[500, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
      %5 = vector.transfer_read %subview_1[%c0, %c0], %cst, %4 {in_bounds = [true, true]} : memref<1x?xf32, strided<[500, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>, vector<1x8xf32>
      %6 = vector.transpose %5, [1, 0] : vector<1x8xf32> to vector<8x1xf32>
      vector.transfer_write %6, %subview[%c0, %c0, %c0, %c0] {in_bounds = [true, true]} : vector<8x1xf32>, memref<1x1x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
      %subview_2 = memref.subview %assume_align_0[%arg0, %arg1, 0, 0] [1, 1, 8, 1] [1, 1, 1, 1] : memref<63x500x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>, #hal.descriptor_type<storage_buffer>> to memref<1x1x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
      linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%subview : memref<1x1x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>) outs(%subview_2 : memref<1x1x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>) {
      ^bb0(%in: f32, %out: f32):
        linalg.yield %in : f32
      }
    }
  }
  return
}

