// -----// IR Dump After VectorTransferLoweringPass: iree-codegen-vector-transfer-lowering{enable-scalable-lowerings=false} //----- //
func.func @_encoding_1_encode_500x500xf32_to_500x500xf32() attributes {translation_info = #iree_codegen.translation_info<pipeline = #iree_cpu.pipeline<DataTiling>, {enable_decomposition}>} {
  %cst = arith.constant dense<0.000000e+00> : vector<8xf32>
  %c2147483647 = arith.constant 2147483647 : index
  %cst_0 = arith.constant dense<[0, 1, 2, 3, 4, 5, 6, 7]> : vector<8xi32>
  %c1 = arith.constant 1 : index
  %c500 = arith.constant 500 : index
  %c63 = arith.constant 63 : index
  %c0 = arith.constant 0 : index
  %c1008000 = arith.constant 1008000 : index
  %0 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : memref<500x500xf32, #hal.descriptor_type<storage_buffer>>
  %assume_align = memref.assume_alignment %0, 64 : memref<500x500xf32, #hal.descriptor_type<storage_buffer>>
  %1 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c1008000) flags(Indirect) : memref<63x500x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
  %assume_align_1 = memref.assume_alignment %1, 64 : memref<63x500x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
  scf.for %arg0 = %c0 to %c63 step %c1 {
    %2 = affine.apply affine_map<(d0) -> (d0 * 8)>(%arg0)
    %3 = affine.min affine_map<(d0) -> (d0 * -8 + 500, 8)>(%arg0)
    scf.for %arg1 = %c0 to %c500 step %c1 {
      %subview = memref.subview %assume_align_1[%arg0, %arg1, 0, 0] [1, 1, 8, 1] [1, 1, 1, 1] : memref<63x500x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>, #hal.descriptor_type<storage_buffer>> to memref<1x1x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
      %subview_2 = memref.subview %assume_align[%arg1, %2] [1, %3] [1, 1] : memref<500x500xf32, #hal.descriptor_type<storage_buffer>> to memref<1x?xf32, strided<[500, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
      %4 = arith.minsi %3, %c2147483647 : index
      %5 = arith.index_cast %4 : index to i32
      %6 = vector.broadcast %5 : i32 to vector<8xi32>
      %7 = arith.cmpi sgt, %6, %cst_0 : vector<8xi32>
      %subview_3 = memref.subview %subview_2[0, 0] [1, %3] [1, 1] : memref<1x?xf32, strided<[500, 1], offset: ?>, #hal.descriptor_type<storage_buffer>> to memref<?xf32, affine_map<(d0)[s0] -> (d0 + s0)>, #hal.descriptor_type<storage_buffer>>
      %8 = vector.maskedload %subview_3[%c0], %7, %cst : memref<?xf32, affine_map<(d0)[s0] -> (d0 + s0)>, #hal.descriptor_type<storage_buffer>>, vector<8xi1>, vector<8xf32> into vector<8xf32>
      %subview_4 = memref.subview %subview[0, 0, 0, 0] [1, 1, 8, 1] [1, 1, 1, 1] : memref<1x1x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>, #hal.descriptor_type<storage_buffer>> to memref<1x1x8xf32, strided<[4000, 8, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
      %subview_5 = memref.subview %subview_4[0, 0, 0] [1, 1, 8] [1, 1, 1] : memref<1x1x8xf32, strided<[4000, 8, 1], offset: ?>, #hal.descriptor_type<storage_buffer>> to memref<8xf32, affine_map<(d0)[s0] -> (d0 + s0)>, #hal.descriptor_type<storage_buffer>>
      vector.store %8, %subview_5[%c0] : memref<8xf32, affine_map<(d0)[s0] -> (d0 + s0)>, #hal.descriptor_type<storage_buffer>>, vector<8xf32>
    }
  }
  return
}

