// -----// IR Dump After EmptyTensorToAllocTensorPass: empty-tensor-to-alloc-tensor //----- //
func.func @_encoding_1_encode_500x500xf32_to_500x500xf32() attributes {translation_info = #iree_codegen.translation_info<pipeline = #iree_cpu.pipeline<DataTiling>, {enable_decomposition}>} {
  %c1 = arith.constant 1 : index
  %c500 = arith.constant 500 : index
  %c63 = arith.constant 63 : index
  %cst = arith.constant 0.000000e+00 : f32
  %c0 = arith.constant 0 : index
  %c1008000 = arith.constant 1008000 : index
  %0 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : memref<500x500xf32, #hal.descriptor_type<storage_buffer>>
  %1 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c1008000) flags(Indirect) : memref<63x500x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
  %2 = iree_codegen.load_from_buffer %0 : memref<500x500xf32, #hal.descriptor_type<storage_buffer>> -> tensor<500x500xf32>
  %3 = iree_codegen.load_from_buffer %1 : memref<63x500x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>, #hal.descriptor_type<storage_buffer>> -> tensor<63x500x8x1xf32>
  %4 = scf.for %arg0 = %c0 to %c63 step %c1 iter_args(%arg1 = %3) -> (tensor<63x500x8x1xf32>) {
    %5 = affine.apply affine_map<(d0) -> (d0 * 8)>(%arg0)
    %6 = affine.min affine_map<(d0) -> (d0 * -8 + 500, 8)>(%arg0)
    %7 = vector.create_mask %c1, %6 : vector<1x8xi1>
    %8 = scf.for %arg2 = %c0 to %c500 step %c1 iter_args(%arg3 = %arg1) -> (tensor<63x500x8x1xf32>) {
      %extracted_slice = tensor.extract_slice %arg3[%arg0, %arg2, 0, 0] [1, 1, 8, 1] [1, 1, 1, 1] : tensor<63x500x8x1xf32> to tensor<1x1x8x1xf32>
      %extracted_slice_0 = tensor.extract_slice %2[%arg2, %5] [1, %6] [1, 1] : tensor<500x500xf32> to tensor<1x?xf32>
      %9 = vector.transfer_read %extracted_slice_0[%c0, %c0], %cst, %7 {in_bounds = [true, true]} : tensor<1x?xf32>, vector<1x8xf32>
      %10 = vector.transpose %9, [1, 0] : vector<1x8xf32> to vector<8x1xf32>
      %11 = vector.transfer_write %10, %extracted_slice[%c0, %c0, %c0, %c0] {in_bounds = [true, true]} : vector<8x1xf32>, tensor<1x1x8x1xf32>
      %inserted_slice = tensor.insert_slice %11 into %arg3[%arg0, %arg2, 0, 0] [1, 1, 8, 1] [1, 1, 1, 1] : tensor<1x1x8x1xf32> into tensor<63x500x8x1xf32>
      scf.yield %inserted_slice : tensor<63x500x8x1xf32>
    }
    scf.yield %8 : tensor<63x500x8x1xf32>
  }
  iree_codegen.store_to_buffer %4, %1 : tensor<63x500x8x1xf32> into memref<63x500x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
  return
}

