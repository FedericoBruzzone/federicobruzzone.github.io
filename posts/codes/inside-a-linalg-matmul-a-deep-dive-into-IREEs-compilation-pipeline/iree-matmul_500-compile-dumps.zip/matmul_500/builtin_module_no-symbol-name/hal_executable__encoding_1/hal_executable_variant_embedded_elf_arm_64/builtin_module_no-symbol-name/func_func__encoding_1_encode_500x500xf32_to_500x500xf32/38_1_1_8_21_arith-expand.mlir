// -----// IR Dump After ArithExpandOpsPass: arith-expand{include-bf16=true include-f4e2m1=false include-f8e8m0=true include-flush-denormals=false} //----- //
func.func @_encoding_1_encode_500x500xf32_to_500x500xf32() {
  %c-8 = arith.constant -8 : index
  %c8 = arith.constant 8 : index
  %cst = arith.constant dense<0.000000e+00> : vector<8xf32>
  %c2147483647 = arith.constant 2147483647 : index
  %cst_0 = arith.constant dense<[0, 1, 2, 3, 4, 5, 6, 7]> : vector<8xi32>
  %c1 = arith.constant 1 : index
  %c500 = arith.constant 500 : index
  %c63 = arith.constant 63 : index
  %c0 = arith.constant 0 : index
  %c1008000 = arith.constant 1008000 : index
  %0 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : memref<500x500xf32>
  %assume_align = memref.assume_alignment %0, 64 : memref<500x500xf32>
  %1 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c1008000) flags(Indirect) : memref<63x500x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>>
  %assume_align_1 = memref.assume_alignment %1, 64 : memref<63x500x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>>
  cf.br ^bb1(%c0 : index)
^bb1(%2: index):  // 2 preds: ^bb0, ^bb5
  %3 = arith.cmpi slt, %2, %c63 : index
  cf.cond_br %3, ^bb2, ^bb6
^bb2:  // pred: ^bb1
  %4 = arith.muli %2, %c8 overflow<nsw> : index
  %5 = arith.muli %2, %c-8 overflow<nsw> : index
  %6 = arith.addi %5, %c500 : index
  %7 = arith.cmpi slt, %6, %c8 : index
  %8 = arith.select %7, %6, %c8 : index
  cf.br ^bb3(%c0 : index)
^bb3(%9: index):  // 2 preds: ^bb2, ^bb4
  %10 = arith.cmpi slt, %9, %c500 : index
  cf.cond_br %10, ^bb4, ^bb5
^bb4:  // pred: ^bb3
  %11 = arith.cmpi slt, %8, %c2147483647 : index
  %12 = arith.select %11, %8, %c2147483647 : index
  %13 = arith.index_cast %12 : index to i32
  %14 = vector.broadcast %13 : i32 to vector<8xi32>
  %15 = arith.cmpi sgt, %14, %cst_0 : vector<8xi32>
  %16 = vector.maskedload %assume_align[%9, %4], %15, %cst : memref<500x500xf32>, vector<8xi1>, vector<8xf32> into vector<8xf32>
  vector.store %16, %assume_align_1[%2, %9, %c0, %c0] : memref<63x500x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>>, vector<8xf32>
  %17 = arith.addi %9, %c1 : index
  cf.br ^bb3(%17 : index)
^bb5:  // pred: ^bb3
  %18 = arith.addi %2, %c1 : index
  cf.br ^bb1(%18 : index)
^bb6:  // pred: ^bb1
  return
}

