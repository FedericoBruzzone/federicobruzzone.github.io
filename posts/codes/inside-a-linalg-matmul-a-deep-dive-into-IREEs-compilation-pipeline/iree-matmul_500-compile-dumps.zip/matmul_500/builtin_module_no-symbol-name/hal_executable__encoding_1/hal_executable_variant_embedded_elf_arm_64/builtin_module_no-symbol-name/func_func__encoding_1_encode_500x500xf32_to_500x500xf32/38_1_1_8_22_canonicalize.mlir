// -----// IR Dump After CanonicalizerPass: canonicalize{cse-between-iterations=false    max-iterations=10 max-num-rewrites=-1 region-simplify=normal test-convergence=false top-down=true} //----- //
func.func @_encoding_1_encode_500x500xf32_to_500x500xf32() {
  %c-8 = arith.constant -8 : index
  %c8 = arith.constant 8 : index
  %cst = arith.constant dense<0.000000e+00> : vector<8xf32>
  %c2147483647 = arith.constant 2147483647 : index
  %cst_0 = arith.constant dense<[0, 1, 2, 3, 4, 5, 6, 7]> : vector<8xi32>
  %c1 = arith.constant 1 : index
  %c500 = arith.constant 500 : index
  %c63 = arith.constant 63 : index
  %c0 = arith.constant 0 : index
  %c1008000 = arith.constant 1008000 : index
  %0 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : memref<500x500xf32>
  %assume_align = memref.assume_alignment %0, 64 : memref<500x500xf32>
  %1 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c1008000) flags(Indirect) : memref<63x500x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>>
  %assume_align_1 = memref.assume_alignment %1, 64 : memref<63x500x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>>
  cf.br ^bb1(%c0 : index)
^bb1(%2: index):  // 2 preds: ^bb0, ^bb5
  %3 = arith.cmpi slt, %2, %c63 : index
  cf.cond_br %3, ^bb2, ^bb6
^bb2:  // pred: ^bb1
  %4 = arith.muli %2, %c8 overflow<nsw> : index
  %5 = arith.muli %2, %c-8 overflow<nsw> : index
  %6 = arith.addi %5, %c500 : index
  %7 = arith.minsi %6, %c8 : index
  cf.br ^bb3(%c0 : index)
^bb3(%8: index):  // 2 preds: ^bb2, ^bb4
  %9 = arith.cmpi slt, %8, %c500 : index
  cf.cond_br %9, ^bb4, ^bb5
^bb4:  // pred: ^bb3
  %10 = arith.minsi %7, %c2147483647 : index
  %11 = arith.index_cast %10 : index to i32
  %12 = vector.broadcast %11 : i32 to vector<8xi32>
  %13 = arith.cmpi sgt, %12, %cst_0 : vector<8xi32>
  %14 = vector.maskedload %assume_align[%8, %4], %13, %cst : memref<500x500xf32>, vector<8xi1>, vector<8xf32> into vector<8xf32>
  vector.store %14, %assume_align_1[%2, %8, %c0, %c0] : memref<63x500x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>>, vector<8xf32>
  %15 = arith.addi %8, %c1 : index
  cf.br ^bb3(%15 : index)
^bb5:  // pred: ^bb3
  %16 = arith.addi %2, %c1 : index
  cf.br ^bb1(%16 : index)
^bb6:  // pred: ^bb1
  return
}

