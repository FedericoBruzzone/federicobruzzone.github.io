// -----// IR Dump After TranslateTargetExecutableVariantsPass: iree-hal-translate-target-executable-variants{target=llvm-cpu target-registry=1} //----- //
hal.executable.variant public @embedded_elf_arm_64 target(<"llvm-cpu", "embedded-elf-arm_64", {cpu = "apple-m4", cpu_features = "+v8.7a,+aes,+bf16,+complxnum,+crc,+dotprod,+fp-armv8,+fp16fml,+fpac,+fullfp16,+i8mm,+jsconv,+lse,+neon,+pauth,+perfmon,+ras,+rcpc,+rdm,+sha2,+sha3,+sme,+sme-f64f64,+sme-i16i64,+sme2,+reserve-x18", data_layout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128-Fn32", iree.encoding.resolver = #iree_cpu.cpu_encoding_resolver<>, max_stack_allocation_size = 32768 : i64, native_vector_size = 16 : i64, target_triple = "arm64-unknown-unknown-eabi-elf", ukernels = "none"}>) {
  hal.executable.export public @_encoding_2_encode_500x500xf32_to_500x500xf32 ordinal(0) layout(#hal.pipeline.layout<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) count(%arg0: !hal.device) -> (index, index, index) {
    %c1 = arith.constant 1 : index
    hal.return %c1, %c1, %c1 : index, index, index
  } attributes {workgroup_size = [1 : index, 1 : index, 1 : index]}
  builtin.module attributes {llvm.data_layout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128-Fn32", llvm.target_triple = "arm64-unknown-unknown-eabi-elf"} {
    llvm.func @_encoding_2_encode_500x500xf32_to_500x500xf32(%arg0: !llvm.ptr {llvm.align = 16 : i64, llvm.noalias, llvm.nonnull, llvm.noundef}, %arg1: !llvm.ptr {llvm.align = 16 : i64, llvm.noalias, llvm.nonnull, llvm.noundef}, %arg2: !llvm.ptr {llvm.align = 16 : i64, llvm.noalias, llvm.nonnull, llvm.noundef}) -> i32 {
      %0 = llvm.mlir.constant(0 : i32) : i32
      %1 = llvm.mlir.poison : vector<8xi64>
      %2 = llvm.mlir.constant(4032 : index) : i64
      %3 = llvm.mlir.constant(64 : index) : i64
      %4 = llvm.mlir.constant(true) : i1
      %5 = llvm.mlir.constant(dense<false> : vector<8xi1>) : vector<8xi1>
      %6 = llvm.mlir.constant(dense<[0, 1, 2, 3, 4, 5, 6, 7]> : vector<8xi64>) : vector<8xi64>
      %7 = llvm.mlir.constant(7 : index) : i64
      %8 = llvm.mlir.constant(6 : index) : i64
      %9 = llvm.mlir.constant(5 : index) : i64
      %10 = llvm.mlir.constant(4 : index) : i64
      %11 = llvm.mlir.constant(3 : index) : i64
      %12 = llvm.mlir.constant(2 : index) : i64
      %13 = llvm.mlir.constant(500 : index) : i64
      %14 = llvm.mlir.constant(-8 : index) : i64
      %15 = llvm.mlir.constant(8 : index) : i64
      %16 = llvm.mlir.constant(dense<0.000000e+00> : vector<8xf32>) : vector<8xf32>
      %17 = llvm.mlir.constant(1 : index) : i64
      %18 = llvm.mlir.constant(63 : index) : i64
      %19 = llvm.mlir.constant(0 : index) : i64
      %20 = llvm.load %arg1 : !llvm.ptr -> !llvm.struct<"iree_hal_executable_dispatch_state_v0_t", (i32, i32, i16, i16, i32, i32, i16, i8, i8, ptr, ptr, ptr)>
      %21 = llvm.extractvalue %20[10] : !llvm.struct<"iree_hal_executable_dispatch_state_v0_t", (i32, i32, i16, i16, i32, i32, i16, i8, i8, ptr, ptr, ptr)> 
      %22 = llvm.load %21 : !llvm.ptr -> !llvm.ptr
      llvm.intr.assume %4 ["align"(%22, %3 : !llvm.ptr, i64)] : i1
      %23 = llvm.load %arg1 : !llvm.ptr -> !llvm.struct<"iree_hal_executable_dispatch_state_v0_t", (i32, i32, i16, i16, i32, i32, i16, i8, i8, ptr, ptr, ptr)>
      %24 = llvm.extractvalue %23[10] : !llvm.struct<"iree_hal_executable_dispatch_state_v0_t", (i32, i32, i16, i16, i32, i32, i16, i8, i8, ptr, ptr, ptr)> 
      %25 = llvm.getelementptr %24[1] : (!llvm.ptr) -> !llvm.ptr, !llvm.ptr
      %26 = llvm.load %25 : !llvm.ptr -> !llvm.ptr
      %27 = llvm.getelementptr %26[2016000] : (!llvm.ptr) -> !llvm.ptr, i8
      llvm.intr.assume %4 ["align"(%27, %3 : !llvm.ptr, i64)] : i1
      llvm.br ^bb1(%19 : i64)
    ^bb1(%28: i64):  // 2 preds: ^bb0, ^bb5
      %29 = llvm.icmp "slt" %28, %18 : i64
      llvm.cond_br %29, ^bb2, ^bb6
    ^bb2:  // pred: ^bb1
      %30 = llvm.mul %28, %15 overflow<nsw> : i64
      %31 = llvm.mul %28, %14 overflow<nsw> : i64
      %32 = llvm.add %31, %13 : i64
      %33 = llvm.intr.smin(%32, %15) : (i64, i64) -> i64
      llvm.br ^bb3(%19 : i64)
    ^bb3(%34: i64):  // 2 preds: ^bb2, ^bb4
      %35 = llvm.icmp "slt" %34, %18 : i64
      llvm.cond_br %35, ^bb4, ^bb5
    ^bb4:  // pred: ^bb3
      %36 = llvm.mul %34, %15 overflow<nsw> : i64
      %37 = llvm.mul %34, %14 overflow<nsw> : i64
      %38 = llvm.add %37, %13 : i64
      %39 = llvm.intr.smin(%38, %15) : (i64, i64) -> i64
      %40 = llvm.insertelement %39, %1[%0 : i32] : vector<8xi64>
      %41 = llvm.shufflevector %40, %1 [0, 0, 0, 0, 0, 0, 0, 0] : vector<8xi64> 
      %42 = llvm.icmp "sgt" %41, %6 : vector<8xi64>
      %43 = llvm.icmp "sgt" %33, %19 : i64
      %44 = llvm.select %43, %42, %5 : i1, vector<8xi1>
      %45 = llvm.icmp "sgt" %33, %17 : i64
      %46 = llvm.select %45, %42, %5 : i1, vector<8xi1>
      %47 = llvm.icmp "sgt" %33, %12 : i64
      %48 = llvm.select %47, %42, %5 : i1, vector<8xi1>
      %49 = llvm.icmp "sgt" %33, %11 : i64
      %50 = llvm.select %49, %42, %5 : i1, vector<8xi1>
      %51 = llvm.icmp "sgt" %33, %10 : i64
      %52 = llvm.select %51, %42, %5 : i1, vector<8xi1>
      %53 = llvm.icmp "sgt" %33, %9 : i64
      %54 = llvm.select %53, %42, %5 : i1, vector<8xi1>
      %55 = llvm.icmp "sgt" %33, %8 : i64
      %56 = llvm.select %55, %42, %5 : i1, vector<8xi1>
      %57 = llvm.icmp "sgt" %33, %7 : i64
      %58 = llvm.select %57, %42, %5 : i1, vector<8xi1>
      %59 = llvm.mul %30, %13 : i64
      %60 = llvm.add %59, %36 : i64
      %61 = llvm.getelementptr %22[%60] : (!llvm.ptr, i64) -> !llvm.ptr, f32
      %62 = llvm.intr.masked.load %61, %44, %16 {alignment = 4 : i32} : (!llvm.ptr, vector<8xi1>, vector<8xf32>) -> vector<8xf32>
      %63 = llvm.add %30, %17 : i64
      %64 = llvm.mul %63, %13 : i64
      %65 = llvm.add %64, %36 : i64
      %66 = llvm.getelementptr %22[%65] : (!llvm.ptr, i64) -> !llvm.ptr, f32
      %67 = llvm.intr.masked.load %66, %46, %16 {alignment = 4 : i32} : (!llvm.ptr, vector<8xi1>, vector<8xf32>) -> vector<8xf32>
      %68 = llvm.add %30, %12 : i64
      %69 = llvm.mul %68, %13 : i64
      %70 = llvm.add %69, %36 : i64
      %71 = llvm.getelementptr %22[%70] : (!llvm.ptr, i64) -> !llvm.ptr, f32
      %72 = llvm.intr.masked.load %71, %48, %16 {alignment = 4 : i32} : (!llvm.ptr, vector<8xi1>, vector<8xf32>) -> vector<8xf32>
      %73 = llvm.add %30, %11 : i64
      %74 = llvm.mul %73, %13 : i64
      %75 = llvm.add %74, %36 : i64
      %76 = llvm.getelementptr %22[%75] : (!llvm.ptr, i64) -> !llvm.ptr, f32
      %77 = llvm.intr.masked.load %76, %50, %16 {alignment = 4 : i32} : (!llvm.ptr, vector<8xi1>, vector<8xf32>) -> vector<8xf32>
      %78 = llvm.add %30, %10 : i64
      %79 = llvm.mul %78, %13 : i64
      %80 = llvm.add %79, %36 : i64
      %81 = llvm.getelementptr %22[%80] : (!llvm.ptr, i64) -> !llvm.ptr, f32
      %82 = llvm.intr.masked.load %81, %52, %16 {alignment = 4 : i32} : (!llvm.ptr, vector<8xi1>, vector<8xf32>) -> vector<8xf32>
      %83 = llvm.add %30, %9 : i64
      %84 = llvm.mul %83, %13 : i64
      %85 = llvm.add %84, %36 : i64
      %86 = llvm.getelementptr %22[%85] : (!llvm.ptr, i64) -> !llvm.ptr, f32
      %87 = llvm.intr.masked.load %86, %54, %16 {alignment = 4 : i32} : (!llvm.ptr, vector<8xi1>, vector<8xf32>) -> vector<8xf32>
      %88 = llvm.add %30, %8 : i64
      %89 = llvm.mul %88, %13 : i64
      %90 = llvm.add %89, %36 : i64
      %91 = llvm.getelementptr %22[%90] : (!llvm.ptr, i64) -> !llvm.ptr, f32
      %92 = llvm.intr.masked.load %91, %56, %16 {alignment = 4 : i32} : (!llvm.ptr, vector<8xi1>, vector<8xf32>) -> vector<8xf32>
      %93 = llvm.add %30, %7 : i64
      %94 = llvm.mul %93, %13 : i64
      %95 = llvm.add %94, %36 : i64
      %96 = llvm.getelementptr %22[%95] : (!llvm.ptr, i64) -> !llvm.ptr, f32
      %97 = llvm.intr.masked.load %96, %58, %16 {alignment = 4 : i32} : (!llvm.ptr, vector<8xi1>, vector<8xf32>) -> vector<8xf32>
      %98 = llvm.mul %28, %2 : i64
      %99 = llvm.mul %34, %3 : i64
      %100 = llvm.add %98, %99 : i64
      %101 = llvm.mul %19, %15 : i64
      %102 = llvm.add %100, %101 : i64
      %103 = llvm.add %102, %19 : i64
      %104 = llvm.getelementptr %27[%103] : (!llvm.ptr, i64) -> !llvm.ptr, f32
      llvm.store %62, %104 {alignment = 4 : i64} : vector<8xf32>, !llvm.ptr
      %105 = llvm.mul %17, %15 : i64
      %106 = llvm.add %100, %105 : i64
      %107 = llvm.add %106, %19 : i64
      %108 = llvm.getelementptr %27[%107] : (!llvm.ptr, i64) -> !llvm.ptr, f32
      llvm.store %67, %108 {alignment = 4 : i64} : vector<8xf32>, !llvm.ptr
      %109 = llvm.mul %12, %15 : i64
      %110 = llvm.add %100, %109 : i64
      %111 = llvm.add %110, %19 : i64
      %112 = llvm.getelementptr %27[%111] : (!llvm.ptr, i64) -> !llvm.ptr, f32
      llvm.store %72, %112 {alignment = 4 : i64} : vector<8xf32>, !llvm.ptr
      %113 = llvm.mul %11, %15 : i64
      %114 = llvm.add %100, %113 : i64
      %115 = llvm.add %114, %19 : i64
      %116 = llvm.getelementptr %27[%115] : (!llvm.ptr, i64) -> !llvm.ptr, f32
      llvm.store %77, %116 {alignment = 4 : i64} : vector<8xf32>, !llvm.ptr
      %117 = llvm.mul %10, %15 : i64
      %118 = llvm.add %100, %117 : i64
      %119 = llvm.add %118, %19 : i64
      %120 = llvm.getelementptr %27[%119] : (!llvm.ptr, i64) -> !llvm.ptr, f32
      llvm.store %82, %120 {alignment = 4 : i64} : vector<8xf32>, !llvm.ptr
      %121 = llvm.mul %9, %15 : i64
      %122 = llvm.add %100, %121 : i64
      %123 = llvm.add %122, %19 : i64
      %124 = llvm.getelementptr %27[%123] : (!llvm.ptr, i64) -> !llvm.ptr, f32
      llvm.store %87, %124 {alignment = 4 : i64} : vector<8xf32>, !llvm.ptr
      %125 = llvm.mul %8, %15 : i64
      %126 = llvm.add %100, %125 : i64
      %127 = llvm.add %126, %19 : i64
      %128 = llvm.getelementptr %27[%127] : (!llvm.ptr, i64) -> !llvm.ptr, f32
      llvm.store %92, %128 {alignment = 4 : i64} : vector<8xf32>, !llvm.ptr
      %129 = llvm.mul %7, %15 : i64
      %130 = llvm.add %100, %129 : i64
      %131 = llvm.add %130, %19 : i64
      %132 = llvm.getelementptr %27[%131] : (!llvm.ptr, i64) -> !llvm.ptr, f32
      llvm.store %97, %132 {alignment = 4 : i64} : vector<8xf32>, !llvm.ptr
      %133 = llvm.add %34, %17 : i64
      llvm.br ^bb3(%133 : i64)
    ^bb5:  // pred: ^bb3
      %134 = llvm.add %28, %17 : i64
      llvm.br ^bb1(%134 : i64)
    ^bb6:  // pred: ^bb1
      llvm.return %0 : i32
    }
  }
}

