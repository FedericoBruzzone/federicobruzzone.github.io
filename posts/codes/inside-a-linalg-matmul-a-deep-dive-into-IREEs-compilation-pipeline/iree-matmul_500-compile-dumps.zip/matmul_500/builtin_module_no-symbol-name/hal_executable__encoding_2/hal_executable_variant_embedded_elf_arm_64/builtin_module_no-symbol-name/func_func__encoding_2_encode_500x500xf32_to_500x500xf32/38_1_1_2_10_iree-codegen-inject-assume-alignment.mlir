// -----// IR Dump After IREEInjectAssumeAlignmentPass: iree-codegen-inject-assume-alignment //----- //
func.func @_encoding_2_encode_500x500xf32_to_500x500xf32() attributes {translation_info = #iree_codegen.translation_info<pipeline = #iree_cpu.pipeline<DataTiling>, {enable_decomposition}>} {
  %c1 = arith.constant 1 : index
  %c63 = arith.constant 63 : index
  %cst = arith.constant 0.000000e+00 : f32
  %c0 = arith.constant 0 : index
  %c2016000 = arith.constant 2016000 : index
  %0 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : memref<500x500xf32, #hal.descriptor_type<storage_buffer>>
  %assume_align = memref.assume_alignment %0, 64 : memref<500x500xf32, #hal.descriptor_type<storage_buffer>>
  %1 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c2016000) flags(Indirect) : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
  %assume_align_0 = memref.assume_alignment %1, 64 : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
  %2 = scf.for %arg0 = %c0 to %c63 step %c1 iter_args(%arg1 = %assume_align_0) -> (memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>) {
    %3 = affine.apply affine_map<(d0) -> (d0 * 8)>(%arg0)
    %4 = affine.min affine_map<(d0) -> (d0 * -8 + 500, 8)>(%arg0)
    %5 = scf.for %arg2 = %c0 to %c63 step %c1 iter_args(%arg3 = %arg1) -> (memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>) {
      %subview = memref.subview %arg3[%arg0, %arg2, 0, 0] [1, 1, 8, 8] [1, 1, 1, 1] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>, #hal.descriptor_type<storage_buffer>> to memref<1x1x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
      %6 = affine.apply affine_map<(d0) -> (d0 * 8)>(%arg2)
      %7 = affine.min affine_map<(d0) -> (d0 * -8 + 500, 8)>(%arg2)
      %subview_1 = memref.subview %assume_align[%3, %6] [%4, %7] [1, 1] : memref<500x500xf32, #hal.descriptor_type<storage_buffer>> to memref<?x?xf32, strided<[500, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
      %8 = vector.create_mask %4, %7 : vector<8x8xi1>
      %9 = vector.transfer_read %subview_1[%c0, %c0], %cst, %8 {in_bounds = [true, true]} : memref<?x?xf32, strided<[500, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>, vector<8x8xf32>
      vector.transfer_write %9, %subview[%c0, %c0, %c0, %c0] {in_bounds = [true, true]} : vector<8x8xf32>, memref<1x1x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
      %subview_2 = memref.subview %arg3[%arg0, %arg2, 0, 0] [1, 1, 8, 8] [1, 1, 1, 1] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>, #hal.descriptor_type<storage_buffer>> to memref<1x1x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
      linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%subview : memref<1x1x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>) outs(%subview_2 : memref<1x1x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>) {
      ^bb0(%in: f32, %out: f32):
        linalg.yield %in : f32
      }
      scf.yield %arg3 : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
    }
    scf.yield %5 : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
  }
  linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%2 : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>) outs(%assume_align_0 : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>) {
  ^bb0(%in: f32, %out: f32):
    linalg.yield %in : f32
  }
  return
}

