// -----// IR Dump After LLVMCPUTilePass: iree-llvmcpu-tile{skip-root-op=false tiling-level=vector_common_parallel} //----- //
func.func @_encoding_2_encode_500x500xf32_to_500x500xf32() attributes {translation_info = #iree_codegen.translation_info<pipeline = #iree_cpu.pipeline<DataTiling>, {enable_decomposition}>} {
  %c1 = arith.constant 1 : index
  %c63 = arith.constant 63 : index
  %cst = arith.constant 0.000000e+00 : f32
  %c0 = arith.constant 0 : index
  %c2016000 = arith.constant 2016000 : index
  %0 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : memref<500x500xf32, #hal.descriptor_type<storage_buffer>>
  %1 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c2016000) flags(Indirect) : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
  %2 = iree_codegen.load_from_buffer %0 : memref<500x500xf32, #hal.descriptor_type<storage_buffer>> -> tensor<500x500xf32>
  %3 = tensor.empty() : tensor<63x63x8x8xf32>
  %4 = scf.for %arg0 = %c0 to %c63 step %c1 iter_args(%arg1 = %3) -> (tensor<63x63x8x8xf32>) {
    %5 = scf.for %arg2 = %c0 to %c63 step %c1 iter_args(%arg3 = %arg1) -> (tensor<63x63x8x8xf32>) {
      %6 = affine.apply affine_map<(d0) -> (d0 * 8)>(%arg0)
      %7 = affine.min affine_map<(d0) -> (d0 * -8 + 500, 8)>(%arg0)
      %8 = affine.apply affine_map<(d0) -> (d0 * 8)>(%arg2)
      %9 = affine.min affine_map<(d0) -> (d0 * -8 + 500, 8)>(%arg2)
      %extracted_slice = tensor.extract_slice %2[%6, %8] [%7, %9] [1, 1] : tensor<500x500xf32> to tensor<?x?xf32>
      %extracted_slice_0 = tensor.extract_slice %arg3[%arg0, %arg2, 0, 0] [1, 1, 8, 8] [1, 1, 1, 1] : tensor<63x63x8x8xf32> to tensor<1x1x8x8xf32>
      %pack = linalg.pack %extracted_slice padding_value(%cst : f32) outer_dims_perm = [0, 1] inner_dims_pos = [0, 1] inner_tiles = [8, 8] into %extracted_slice_0 {lowering_config = #iree_cpu.lowering_config<distribution = [0, 0], vector_common_parallel = [1, 1]>} : tensor<?x?xf32> -> tensor<1x1x8x8xf32>
      %inserted_slice = tensor.insert_slice %pack into %arg3[%arg0, %arg2, 0, 0] [1, 1, 8, 8] [1, 1, 1, 1] : tensor<1x1x8x8xf32> into tensor<63x63x8x8xf32>
      scf.yield %inserted_slice : tensor<63x63x8x8xf32>
    }
    scf.yield %5 : tensor<63x63x8x8xf32>
  }
  iree_codegen.store_to_buffer %4, %1 : tensor<63x63x8x8xf32> into memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
  return
}

