// -----// IR Dump After EraseHALDescriptorTypeFromMemRefPass: iree-codegen-erase-hal-descriptor-type-from-memref //----- //
func.func @_encoding_2_encode_500x500xf32_to_500x500xf32() {
  %c7 = arith.constant 7 : index
  %c6 = arith.constant 6 : index
  %c5 = arith.constant 5 : index
  %c4 = arith.constant 4 : index
  %c3 = arith.constant 3 : index
  %c2 = arith.constant 2 : index
  %cst = arith.constant dense<0.000000e+00> : vector<8xf32>
  %c1 = arith.constant 1 : index
  %c63 = arith.constant 63 : index
  %c0 = arith.constant 0 : index
  %c2016000 = arith.constant 2016000 : index
  %0 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : memref<500x500xf32>
  %assume_align = memref.assume_alignment %0, 64 : memref<500x500xf32>
  %1 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c2016000) flags(Indirect) : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>
  %assume_align_0 = memref.assume_alignment %1, 64 : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>
  scf.for %arg0 = %c0 to %c63 step %c1 {
    %c8 = arith.constant 8 : index
    %2 = arith.muli %arg0, %c8 overflow<nsw> : index
    %c-8 = arith.constant -8 : index
    %3 = arith.muli %arg0, %c-8 overflow<nsw> : index
    %c500 = arith.constant 500 : index
    %4 = arith.addi %3, %c500 : index
    %c8_1 = arith.constant 8 : index
    %5 = arith.minsi %4, %c8_1 : index
    scf.for %arg1 = %c0 to %c63 step %c1 {
      %subview = memref.subview %assume_align_0[%arg0, %arg1, 0, 0] [1, 1, 8, 8] [1, 1, 1, 1] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>> to memref<1x1x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>
      %c8_2 = arith.constant 8 : index
      %6 = arith.muli %arg1, %c8_2 overflow<nsw> : index
      %c-8_3 = arith.constant -8 : index
      %7 = arith.muli %arg1, %c-8_3 overflow<nsw> : index
      %c500_4 = arith.constant 500 : index
      %8 = arith.addi %7, %c500_4 : index
      %c8_5 = arith.constant 8 : index
      %9 = arith.minsi %8, %c8_5 : index
      %subview_6 = memref.subview %assume_align[%2, %6] [%5, %9] [1, 1] : memref<500x500xf32> to memref<?x?xf32, strided<[500, 1], offset: ?>>
      %10 = vector.create_mask %5, %9 : vector<8x8xi1>
      %11 = vector.extract %10[0] : vector<8xi1> from vector<8x8xi1>
      %12 = vector.maskedload %subview_6[%c0, %c0], %11, %cst : memref<?x?xf32, strided<[500, 1], offset: ?>>, vector<8xi1>, vector<8xf32> into vector<8xf32>
      %13 = vector.extract %10[1] : vector<8xi1> from vector<8x8xi1>
      %14 = vector.maskedload %subview_6[%c1, %c0], %13, %cst : memref<?x?xf32, strided<[500, 1], offset: ?>>, vector<8xi1>, vector<8xf32> into vector<8xf32>
      %15 = vector.extract %10[2] : vector<8xi1> from vector<8x8xi1>
      %16 = vector.maskedload %subview_6[%c2, %c0], %15, %cst : memref<?x?xf32, strided<[500, 1], offset: ?>>, vector<8xi1>, vector<8xf32> into vector<8xf32>
      %17 = vector.extract %10[3] : vector<8xi1> from vector<8x8xi1>
      %18 = vector.maskedload %subview_6[%c3, %c0], %17, %cst : memref<?x?xf32, strided<[500, 1], offset: ?>>, vector<8xi1>, vector<8xf32> into vector<8xf32>
      %19 = vector.extract %10[4] : vector<8xi1> from vector<8x8xi1>
      %20 = vector.maskedload %subview_6[%c4, %c0], %19, %cst : memref<?x?xf32, strided<[500, 1], offset: ?>>, vector<8xi1>, vector<8xf32> into vector<8xf32>
      %21 = vector.extract %10[5] : vector<8xi1> from vector<8x8xi1>
      %22 = vector.maskedload %subview_6[%c5, %c0], %21, %cst : memref<?x?xf32, strided<[500, 1], offset: ?>>, vector<8xi1>, vector<8xf32> into vector<8xf32>
      %23 = vector.extract %10[6] : vector<8xi1> from vector<8x8xi1>
      %24 = vector.maskedload %subview_6[%c6, %c0], %23, %cst : memref<?x?xf32, strided<[500, 1], offset: ?>>, vector<8xi1>, vector<8xf32> into vector<8xf32>
      %25 = vector.extract %10[7] : vector<8xi1> from vector<8x8xi1>
      %26 = vector.maskedload %subview_6[%c7, %c0], %25, %cst : memref<?x?xf32, strided<[500, 1], offset: ?>>, vector<8xi1>, vector<8xf32> into vector<8xf32>
      %subview_7 = memref.subview %subview[0, 0, 0, 0] [1, 1, 8, 8] [1, 1, 1, 1] : memref<1x1x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>> to memref<8x8xf32, affine_map<(d0, d1)[s0] -> (d0 * 8 + d1 + s0)>>
      vector.store %12, %subview_7[%c0, %c0] : memref<8x8xf32, affine_map<(d0, d1)[s0] -> (d0 * 8 + d1 + s0)>>, vector<8xf32>
      vector.store %14, %subview_7[%c1, %c0] : memref<8x8xf32, affine_map<(d0, d1)[s0] -> (d0 * 8 + d1 + s0)>>, vector<8xf32>
      vector.store %16, %subview_7[%c2, %c0] : memref<8x8xf32, affine_map<(d0, d1)[s0] -> (d0 * 8 + d1 + s0)>>, vector<8xf32>
      vector.store %18, %subview_7[%c3, %c0] : memref<8x8xf32, affine_map<(d0, d1)[s0] -> (d0 * 8 + d1 + s0)>>, vector<8xf32>
      vector.store %20, %subview_7[%c4, %c0] : memref<8x8xf32, affine_map<(d0, d1)[s0] -> (d0 * 8 + d1 + s0)>>, vector<8xf32>
      vector.store %22, %subview_7[%c5, %c0] : memref<8x8xf32, affine_map<(d0, d1)[s0] -> (d0 * 8 + d1 + s0)>>, vector<8xf32>
      vector.store %24, %subview_7[%c6, %c0] : memref<8x8xf32, affine_map<(d0, d1)[s0] -> (d0 * 8 + d1 + s0)>>, vector<8xf32>
      vector.store %26, %subview_7[%c7, %c0] : memref<8x8xf32, affine_map<(d0, d1)[s0] -> (d0 * 8 + d1 + s0)>>, vector<8xf32>
    }
  }
  return
}

