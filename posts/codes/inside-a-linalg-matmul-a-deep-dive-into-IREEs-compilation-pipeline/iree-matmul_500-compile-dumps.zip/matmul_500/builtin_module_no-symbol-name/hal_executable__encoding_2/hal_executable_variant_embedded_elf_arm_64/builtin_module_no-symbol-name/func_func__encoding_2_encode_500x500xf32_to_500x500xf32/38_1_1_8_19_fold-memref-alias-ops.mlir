// -----// IR Dump After FoldMemRefAliasOpsPass: fold-memref-alias-ops //----- //
func.func @_encoding_2_encode_500x500xf32_to_500x500xf32() {
  %c7 = arith.constant 7 : index
  %c6 = arith.constant 6 : index
  %c5 = arith.constant 5 : index
  %c4 = arith.constant 4 : index
  %c3 = arith.constant 3 : index
  %c2 = arith.constant 2 : index
  %c500 = arith.constant 500 : index
  %c-8 = arith.constant -8 : index
  %c8 = arith.constant 8 : index
  %cst = arith.constant dense<0.000000e+00> : vector<8xf32>
  %c1 = arith.constant 1 : index
  %c63 = arith.constant 63 : index
  %c0 = arith.constant 0 : index
  %c2016000 = arith.constant 2016000 : index
  %0 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : memref<500x500xf32>
  %assume_align = memref.assume_alignment %0, 64 : memref<500x500xf32>
  %1 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c2016000) flags(Indirect) : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>
  %assume_align_0 = memref.assume_alignment %1, 64 : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>
  scf.for %arg0 = %c0 to %c63 step %c1 {
    %2 = arith.muli %arg0, %c8 overflow<nsw> : index
    %3 = arith.muli %arg0, %c-8 overflow<nsw> : index
    %4 = arith.addi %3, %c500 : index
    %5 = arith.minsi %4, %c8 : index
    scf.for %arg1 = %c0 to %c63 step %c1 {
      %6 = arith.muli %arg1, %c8 overflow<nsw> : index
      %7 = arith.muli %arg1, %c-8 overflow<nsw> : index
      %8 = arith.addi %7, %c500 : index
      %9 = arith.minsi %8, %c8 : index
      %10 = vector.create_mask %5, %9 : vector<8x8xi1>
      %11 = vector.extract %10[0] : vector<8xi1> from vector<8x8xi1>
      %12 = vector.maskedload %assume_align[%2, %6], %11, %cst : memref<500x500xf32>, vector<8xi1>, vector<8xf32> into vector<8xf32>
      %13 = vector.extract %10[1] : vector<8xi1> from vector<8x8xi1>
      %14 = affine.apply affine_map<()[s0] -> (s0 + 1)>()[%2]
      %15 = vector.maskedload %assume_align[%14, %6], %13, %cst : memref<500x500xf32>, vector<8xi1>, vector<8xf32> into vector<8xf32>
      %16 = vector.extract %10[2] : vector<8xi1> from vector<8x8xi1>
      %17 = affine.apply affine_map<()[s0] -> (s0 + 2)>()[%2]
      %18 = vector.maskedload %assume_align[%17, %6], %16, %cst : memref<500x500xf32>, vector<8xi1>, vector<8xf32> into vector<8xf32>
      %19 = vector.extract %10[3] : vector<8xi1> from vector<8x8xi1>
      %20 = affine.apply affine_map<()[s0] -> (s0 + 3)>()[%2]
      %21 = vector.maskedload %assume_align[%20, %6], %19, %cst : memref<500x500xf32>, vector<8xi1>, vector<8xf32> into vector<8xf32>
      %22 = vector.extract %10[4] : vector<8xi1> from vector<8x8xi1>
      %23 = affine.apply affine_map<()[s0] -> (s0 + 4)>()[%2]
      %24 = vector.maskedload %assume_align[%23, %6], %22, %cst : memref<500x500xf32>, vector<8xi1>, vector<8xf32> into vector<8xf32>
      %25 = vector.extract %10[5] : vector<8xi1> from vector<8x8xi1>
      %26 = affine.apply affine_map<()[s0] -> (s0 + 5)>()[%2]
      %27 = vector.maskedload %assume_align[%26, %6], %25, %cst : memref<500x500xf32>, vector<8xi1>, vector<8xf32> into vector<8xf32>
      %28 = vector.extract %10[6] : vector<8xi1> from vector<8x8xi1>
      %29 = affine.apply affine_map<()[s0] -> (s0 + 6)>()[%2]
      %30 = vector.maskedload %assume_align[%29, %6], %28, %cst : memref<500x500xf32>, vector<8xi1>, vector<8xf32> into vector<8xf32>
      %31 = vector.extract %10[7] : vector<8xi1> from vector<8x8xi1>
      %32 = affine.apply affine_map<()[s0] -> (s0 + 7)>()[%2]
      %33 = vector.maskedload %assume_align[%32, %6], %31, %cst : memref<500x500xf32>, vector<8xi1>, vector<8xf32> into vector<8xf32>
      vector.store %12, %assume_align_0[%arg0, %arg1, %c0, %c0] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>, vector<8xf32>
      vector.store %15, %assume_align_0[%arg0, %arg1, %c1, %c0] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>, vector<8xf32>
      vector.store %18, %assume_align_0[%arg0, %arg1, %c2, %c0] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>, vector<8xf32>
      vector.store %21, %assume_align_0[%arg0, %arg1, %c3, %c0] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>, vector<8xf32>
      vector.store %24, %assume_align_0[%arg0, %arg1, %c4, %c0] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>, vector<8xf32>
      vector.store %27, %assume_align_0[%arg0, %arg1, %c5, %c0] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>, vector<8xf32>
      vector.store %30, %assume_align_0[%arg0, %arg1, %c6, %c0] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>, vector<8xf32>
      vector.store %33, %assume_align_0[%arg0, %arg1, %c7, %c0] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>, vector<8xf32>
    }
  }
  return
}

