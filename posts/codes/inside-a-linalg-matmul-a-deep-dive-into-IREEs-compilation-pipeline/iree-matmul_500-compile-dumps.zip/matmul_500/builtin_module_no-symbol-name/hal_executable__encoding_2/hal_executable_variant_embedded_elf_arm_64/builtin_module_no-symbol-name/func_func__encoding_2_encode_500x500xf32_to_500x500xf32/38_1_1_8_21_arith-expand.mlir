// -----// IR Dump After ArithExpandOpsPass: arith-expand{include-bf16=true include-f4e2m1=false include-f8e8m0=true include-flush-denormals=false} //----- //
func.func @_encoding_2_encode_500x500xf32_to_500x500xf32() {
  %c7 = arith.constant 7 : index
  %c6 = arith.constant 6 : index
  %c5 = arith.constant 5 : index
  %c4 = arith.constant 4 : index
  %c3 = arith.constant 3 : index
  %c2 = arith.constant 2 : index
  %c500 = arith.constant 500 : index
  %c-8 = arith.constant -8 : index
  %c8 = arith.constant 8 : index
  %cst = arith.constant dense<0.000000e+00> : vector<8xf32>
  %c1 = arith.constant 1 : index
  %c63 = arith.constant 63 : index
  %c0 = arith.constant 0 : index
  %c2016000 = arith.constant 2016000 : index
  %0 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : memref<500x500xf32>
  %assume_align = memref.assume_alignment %0, 64 : memref<500x500xf32>
  %1 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c2016000) flags(Indirect) : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>
  %assume_align_0 = memref.assume_alignment %1, 64 : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>
  cf.br ^bb1(%c0 : index)
^bb1(%2: index):  // 2 preds: ^bb0, ^bb5
  %3 = arith.cmpi slt, %2, %c63 : index
  cf.cond_br %3, ^bb2, ^bb6
^bb2:  // pred: ^bb1
  %4 = arith.muli %2, %c8 overflow<nsw> : index
  %5 = arith.muli %2, %c-8 overflow<nsw> : index
  %6 = arith.addi %5, %c500 : index
  %7 = arith.cmpi slt, %6, %c8 : index
  %8 = arith.select %7, %6, %c8 : index
  cf.br ^bb3(%c0 : index)
^bb3(%9: index):  // 2 preds: ^bb2, ^bb4
  %10 = arith.cmpi slt, %9, %c63 : index
  cf.cond_br %10, ^bb4, ^bb5
^bb4:  // pred: ^bb3
  %11 = arith.muli %9, %c8 overflow<nsw> : index
  %12 = arith.muli %9, %c-8 overflow<nsw> : index
  %13 = arith.addi %12, %c500 : index
  %14 = arith.cmpi slt, %13, %c8 : index
  %15 = arith.select %14, %13, %c8 : index
  %16 = vector.create_mask %8, %15 : vector<8x8xi1>
  %17 = vector.extract %16[0] : vector<8xi1> from vector<8x8xi1>
  %18 = vector.maskedload %assume_align[%4, %11], %17, %cst : memref<500x500xf32>, vector<8xi1>, vector<8xf32> into vector<8xf32>
  %19 = vector.extract %16[1] : vector<8xi1> from vector<8x8xi1>
  %20 = affine.apply affine_map<()[s0] -> (s0 + 1)>()[%4]
  %21 = vector.maskedload %assume_align[%20, %11], %19, %cst : memref<500x500xf32>, vector<8xi1>, vector<8xf32> into vector<8xf32>
  %22 = vector.extract %16[2] : vector<8xi1> from vector<8x8xi1>
  %23 = affine.apply affine_map<()[s0] -> (s0 + 2)>()[%4]
  %24 = vector.maskedload %assume_align[%23, %11], %22, %cst : memref<500x500xf32>, vector<8xi1>, vector<8xf32> into vector<8xf32>
  %25 = vector.extract %16[3] : vector<8xi1> from vector<8x8xi1>
  %26 = affine.apply affine_map<()[s0] -> (s0 + 3)>()[%4]
  %27 = vector.maskedload %assume_align[%26, %11], %25, %cst : memref<500x500xf32>, vector<8xi1>, vector<8xf32> into vector<8xf32>
  %28 = vector.extract %16[4] : vector<8xi1> from vector<8x8xi1>
  %29 = affine.apply affine_map<()[s0] -> (s0 + 4)>()[%4]
  %30 = vector.maskedload %assume_align[%29, %11], %28, %cst : memref<500x500xf32>, vector<8xi1>, vector<8xf32> into vector<8xf32>
  %31 = vector.extract %16[5] : vector<8xi1> from vector<8x8xi1>
  %32 = affine.apply affine_map<()[s0] -> (s0 + 5)>()[%4]
  %33 = vector.maskedload %assume_align[%32, %11], %31, %cst : memref<500x500xf32>, vector<8xi1>, vector<8xf32> into vector<8xf32>
  %34 = vector.extract %16[6] : vector<8xi1> from vector<8x8xi1>
  %35 = affine.apply affine_map<()[s0] -> (s0 + 6)>()[%4]
  %36 = vector.maskedload %assume_align[%35, %11], %34, %cst : memref<500x500xf32>, vector<8xi1>, vector<8xf32> into vector<8xf32>
  %37 = vector.extract %16[7] : vector<8xi1> from vector<8x8xi1>
  %38 = affine.apply affine_map<()[s0] -> (s0 + 7)>()[%4]
  %39 = vector.maskedload %assume_align[%38, %11], %37, %cst : memref<500x500xf32>, vector<8xi1>, vector<8xf32> into vector<8xf32>
  vector.store %18, %assume_align_0[%2, %9, %c0, %c0] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>, vector<8xf32>
  vector.store %21, %assume_align_0[%2, %9, %c1, %c0] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>, vector<8xf32>
  vector.store %24, %assume_align_0[%2, %9, %c2, %c0] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>, vector<8xf32>
  vector.store %27, %assume_align_0[%2, %9, %c3, %c0] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>, vector<8xf32>
  vector.store %30, %assume_align_0[%2, %9, %c4, %c0] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>, vector<8xf32>
  vector.store %33, %assume_align_0[%2, %9, %c5, %c0] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>, vector<8xf32>
  vector.store %36, %assume_align_0[%2, %9, %c6, %c0] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>, vector<8xf32>
  vector.store %39, %assume_align_0[%2, %9, %c7, %c0] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>, vector<8xf32>
  %40 = arith.addi %9, %c1 : index
  cf.br ^bb3(%40 : index)
^bb5:  // pred: ^bb3
  %41 = arith.addi %2, %c1 : index
  cf.br ^bb1(%41 : index)
^bb6:  // pred: ^bb1
  return
}

