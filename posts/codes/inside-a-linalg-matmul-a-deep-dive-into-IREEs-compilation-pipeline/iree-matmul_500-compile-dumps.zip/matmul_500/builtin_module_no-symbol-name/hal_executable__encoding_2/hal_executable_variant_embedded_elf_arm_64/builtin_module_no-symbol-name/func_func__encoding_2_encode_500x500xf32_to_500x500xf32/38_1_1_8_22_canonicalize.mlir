// -----// IR Dump After CanonicalizerPass: canonicalize{cse-between-iterations=false    max-iterations=10 max-num-rewrites=-1 region-simplify=normal test-convergence=false top-down=true} //----- //
func.func @_encoding_2_encode_500x500xf32_to_500x500xf32() {
  %c7 = arith.constant 7 : index
  %c6 = arith.constant 6 : index
  %c5 = arith.constant 5 : index
  %c4 = arith.constant 4 : index
  %c3 = arith.constant 3 : index
  %c2 = arith.constant 2 : index
  %c500 = arith.constant 500 : index
  %c-8 = arith.constant -8 : index
  %c8 = arith.constant 8 : index
  %cst = arith.constant dense<0.000000e+00> : vector<8xf32>
  %c1 = arith.constant 1 : index
  %c63 = arith.constant 63 : index
  %c0 = arith.constant 0 : index
  %c2016000 = arith.constant 2016000 : index
  %0 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : memref<500x500xf32>
  %assume_align = memref.assume_alignment %0, 64 : memref<500x500xf32>
  %1 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c2016000) flags(Indirect) : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>
  %assume_align_0 = memref.assume_alignment %1, 64 : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>
  cf.br ^bb1(%c0 : index)
^bb1(%2: index):  // 2 preds: ^bb0, ^bb5
  %3 = arith.cmpi slt, %2, %c63 : index
  cf.cond_br %3, ^bb2, ^bb6
^bb2:  // pred: ^bb1
  %4 = arith.muli %2, %c8 overflow<nsw> : index
  %5 = arith.muli %2, %c-8 overflow<nsw> : index
  %6 = arith.addi %5, %c500 : index
  %7 = arith.minsi %6, %c8 : index
  cf.br ^bb3(%c0 : index)
^bb3(%8: index):  // 2 preds: ^bb2, ^bb4
  %9 = arith.cmpi slt, %8, %c63 : index
  cf.cond_br %9, ^bb4, ^bb5
^bb4:  // pred: ^bb3
  %10 = arith.muli %8, %c8 overflow<nsw> : index
  %11 = arith.muli %8, %c-8 overflow<nsw> : index
  %12 = arith.addi %11, %c500 : index
  %13 = arith.minsi %12, %c8 : index
  %14 = vector.create_mask %7, %13 : vector<8x8xi1>
  %15 = vector.extract %14[0] : vector<8xi1> from vector<8x8xi1>
  %16 = vector.maskedload %assume_align[%4, %10], %15, %cst : memref<500x500xf32>, vector<8xi1>, vector<8xf32> into vector<8xf32>
  %17 = vector.extract %14[1] : vector<8xi1> from vector<8x8xi1>
  %18 = affine.apply affine_map<()[s0] -> (s0 + 1)>()[%4]
  %19 = vector.maskedload %assume_align[%18, %10], %17, %cst : memref<500x500xf32>, vector<8xi1>, vector<8xf32> into vector<8xf32>
  %20 = vector.extract %14[2] : vector<8xi1> from vector<8x8xi1>
  %21 = affine.apply affine_map<()[s0] -> (s0 + 2)>()[%4]
  %22 = vector.maskedload %assume_align[%21, %10], %20, %cst : memref<500x500xf32>, vector<8xi1>, vector<8xf32> into vector<8xf32>
  %23 = vector.extract %14[3] : vector<8xi1> from vector<8x8xi1>
  %24 = affine.apply affine_map<()[s0] -> (s0 + 3)>()[%4]
  %25 = vector.maskedload %assume_align[%24, %10], %23, %cst : memref<500x500xf32>, vector<8xi1>, vector<8xf32> into vector<8xf32>
  %26 = vector.extract %14[4] : vector<8xi1> from vector<8x8xi1>
  %27 = affine.apply affine_map<()[s0] -> (s0 + 4)>()[%4]
  %28 = vector.maskedload %assume_align[%27, %10], %26, %cst : memref<500x500xf32>, vector<8xi1>, vector<8xf32> into vector<8xf32>
  %29 = vector.extract %14[5] : vector<8xi1> from vector<8x8xi1>
  %30 = affine.apply affine_map<()[s0] -> (s0 + 5)>()[%4]
  %31 = vector.maskedload %assume_align[%30, %10], %29, %cst : memref<500x500xf32>, vector<8xi1>, vector<8xf32> into vector<8xf32>
  %32 = vector.extract %14[6] : vector<8xi1> from vector<8x8xi1>
  %33 = affine.apply affine_map<()[s0] -> (s0 + 6)>()[%4]
  %34 = vector.maskedload %assume_align[%33, %10], %32, %cst : memref<500x500xf32>, vector<8xi1>, vector<8xf32> into vector<8xf32>
  %35 = vector.extract %14[7] : vector<8xi1> from vector<8x8xi1>
  %36 = affine.apply affine_map<()[s0] -> (s0 + 7)>()[%4]
  %37 = vector.maskedload %assume_align[%36, %10], %35, %cst : memref<500x500xf32>, vector<8xi1>, vector<8xf32> into vector<8xf32>
  vector.store %16, %assume_align_0[%2, %8, %c0, %c0] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>, vector<8xf32>
  vector.store %19, %assume_align_0[%2, %8, %c1, %c0] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>, vector<8xf32>
  vector.store %22, %assume_align_0[%2, %8, %c2, %c0] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>, vector<8xf32>
  vector.store %25, %assume_align_0[%2, %8, %c3, %c0] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>, vector<8xf32>
  vector.store %28, %assume_align_0[%2, %8, %c4, %c0] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>, vector<8xf32>
  vector.store %31, %assume_align_0[%2, %8, %c5, %c0] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>, vector<8xf32>
  vector.store %34, %assume_align_0[%2, %8, %c6, %c0] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>, vector<8xf32>
  vector.store %37, %assume_align_0[%2, %8, %c7, %c0] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>, vector<8xf32>
  %38 = arith.addi %8, %c1 : index
  cf.br ^bb3(%38 : index)
^bb5:  // pred: ^bb3
  %39 = arith.addi %2, %c1 : index
  cf.br ^bb1(%39 : index)
^bb6:  // pred: ^bb1
  return
}

