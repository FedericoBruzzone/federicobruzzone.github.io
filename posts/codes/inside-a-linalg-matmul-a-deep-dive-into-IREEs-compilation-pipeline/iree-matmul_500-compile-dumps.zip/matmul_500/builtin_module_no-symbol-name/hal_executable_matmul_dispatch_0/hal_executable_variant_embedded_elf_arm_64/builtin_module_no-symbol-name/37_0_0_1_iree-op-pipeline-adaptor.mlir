// -----// IR Dump After mlir::iree_compiler::detail::OpPipelineAdaptorPass: iree-op-pipeline-adaptor //----- //
module {
  func.func @matmul_dispatch_0_matmul_like_500x500x500_f32() {
    %cst = arith.constant 0.000000e+00 : f32
    %c0 = arith.constant 0 : index
    %c1008000 = arith.constant 1008000 : index
    %c2016000 = arith.constant 2016000 : index
    %0 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : memref<63x500x8x1xf32, #hal.descriptor_type<storage_buffer>>
    %1 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c1008000) flags("ReadOnly|Indirect") : memref<63x500x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
    %2 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c2016000) flags("ReadOnly|Indirect") : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
    %3 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags(Indirect) : memref<500x500xf32, #hal.descriptor_type<storage_buffer>>
    %4 = iree_codegen.load_from_buffer %0 : memref<63x500x8x1xf32, #hal.descriptor_type<storage_buffer>> -> tensor<63x500x8x1xf32>
    %5 = iree_codegen.load_from_buffer %1 : memref<63x500x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>, #hal.descriptor_type<storage_buffer>> -> tensor<63x500x8x1xf32>
    %6 = iree_codegen.load_from_buffer %2 : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>, #hal.descriptor_type<storage_buffer>> -> tensor<63x63x8x8xf32>
    %7 = tensor.empty() : tensor<63x63x8x8xf32>
    %8 = linalg.fill ins(%cst : f32) outs(%7 : tensor<63x63x8x8xf32>) -> tensor<63x63x8x8xf32>
    %9 = linalg.mmt4d ins(%4, %5 : tensor<63x500x8x1xf32>, tensor<63x500x8x1xf32>) outs(%8 : tensor<63x63x8x8xf32>) -> tensor<63x63x8x8xf32>
    %10 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%9, %6 : tensor<63x63x8x8xf32>, tensor<63x63x8x8xf32>) outs(%7 : tensor<63x63x8x8xf32>) {
    ^bb0(%in: f32, %in_0: f32, %out: f32):
      %12 = arith.addf %in, %in_0 : f32
      linalg.yield %12 : f32
    } -> tensor<63x63x8x8xf32>
    %11 = tensor.empty() : tensor<500x500xf32>
    %unpack = linalg.unpack %10 outer_dims_perm = [0, 1] inner_dims_pos = [0, 1] inner_tiles = [8, 8] into %11 : tensor<63x63x8x8xf32> -> tensor<500x500xf32>
    iree_codegen.store_to_buffer %unpack, %3 : tensor<500x500xf32> into memref<500x500xf32, #hal.descriptor_type<storage_buffer>>
    return
  }
  iree_codegen.dispatch_config @matmul_dispatch_0_matmul_like_500x500x500_f32 {
  ^bb0(%arg0: !hal.device):
    %x, %y, %z = iree_tensor_ext.dispatch.workgroup_count_from_slice()
    iree_codegen.yield %x, %y, %z : index, index, index
  }
}

