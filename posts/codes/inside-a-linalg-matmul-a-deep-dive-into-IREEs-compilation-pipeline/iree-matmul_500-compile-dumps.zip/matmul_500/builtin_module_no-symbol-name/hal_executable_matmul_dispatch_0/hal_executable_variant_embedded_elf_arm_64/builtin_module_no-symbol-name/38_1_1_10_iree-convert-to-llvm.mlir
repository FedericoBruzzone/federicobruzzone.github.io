// -----// IR Dump After ConvertToLLVMPass: iree-convert-to-llvm{reassociateFpReductions=true target-data-layout= target-triple=} //----- //
module attributes {llvm.data_layout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128-Fn32", llvm.target_triple = "arm64-unknown-unknown-eabi-elf"} {
  llvm.func @matmul_dispatch_0_matmul_like_500x500x500_f32(%arg0: !llvm.ptr {llvm.align = 16 : i64, llvm.noalias, llvm.nonnull, llvm.noundef}, %arg1: !llvm.ptr {llvm.align = 16 : i64, llvm.noalias, llvm.nonnull, llvm.noundef}, %arg2: !llvm.ptr {llvm.align = 16 : i64, llvm.noalias, llvm.nonnull, llvm.noundef}) -> i32 {
    %0 = llvm.mlir.poison : vector<8xi64>
    %1 = llvm.mlir.constant(7 : i64) : i64
    %2 = llvm.mlir.constant(6 : i64) : i64
    %3 = llvm.mlir.constant(5 : i64) : i64
    %4 = llvm.mlir.constant(4 : i64) : i64
    %5 = llvm.mlir.constant(3 : i64) : i64
    %6 = llvm.mlir.constant(2 : i64) : i64
    %7 = llvm.mlir.constant(1 : i64) : i64
    %8 = llvm.mlir.constant(0 : i32) : i32
    %9 = llvm.mlir.poison : vector<8xf32>
    %10 = llvm.mlir.constant(4032 : index) : i64
    %11 = llvm.mlir.constant(0 : i64) : i64
    %12 = llvm.mlir.constant(64 : index) : i64
    %13 = llvm.mlir.constant(true) : i1
    %14 = llvm.mlir.constant(4000 : index) : i64
    %15 = llvm.mlir.constant(dense<false> : vector<8xi1>) : vector<8xi1>
    %16 = llvm.mlir.constant(dense<[0, 1, 2, 3, 4, 5, 6, 7]> : vector<8xi64>) : vector<8xi64>
    %17 = llvm.mlir.poison : !llvm.array<8 x vector<8xf32>>
    %18 = llvm.mlir.constant(-8 : index) : i64
    %19 = llvm.mlir.constant(8 : index) : i64
    %20 = llvm.mlir.constant(7 : index) : i64
    %21 = llvm.mlir.constant(6 : index) : i64
    %22 = llvm.mlir.constant(5 : index) : i64
    %23 = llvm.mlir.constant(4 : index) : i64
    %24 = llvm.mlir.constant(3 : index) : i64
    %25 = llvm.mlir.constant(2 : index) : i64
    %26 = llvm.mlir.constant(dense<0.000000e+00> : vector<8x8xf32>) : !llvm.array<8 x vector<8xf32>>
    %27 = llvm.mlir.constant(63 : index) : i64
    %28 = llvm.mlir.constant(1 : index) : i64
    %29 = llvm.mlir.constant(500 : index) : i64
    %30 = llvm.mlir.constant(0 : index) : i64
    %31 = llvm.load %arg1 : !llvm.ptr -> !llvm.struct<"iree_hal_executable_dispatch_state_v0_t", (i32, i32, i16, i16, i32, i32, i16, i8, i8, ptr, ptr, ptr)>
    %32 = llvm.extractvalue %31[10] : !llvm.struct<"iree_hal_executable_dispatch_state_v0_t", (i32, i32, i16, i16, i32, i32, i16, i8, i8, ptr, ptr, ptr)> 
    %33 = llvm.load %32 : !llvm.ptr -> !llvm.ptr
    llvm.intr.assume %13 ["align"(%33, %12 : !llvm.ptr, i64)] : i1
    %34 = llvm.load %arg1 : !llvm.ptr -> !llvm.struct<"iree_hal_executable_dispatch_state_v0_t", (i32, i32, i16, i16, i32, i32, i16, i8, i8, ptr, ptr, ptr)>
    %35 = llvm.extractvalue %34[10] : !llvm.struct<"iree_hal_executable_dispatch_state_v0_t", (i32, i32, i16, i16, i32, i32, i16, i8, i8, ptr, ptr, ptr)> 
    %36 = llvm.load %35 : !llvm.ptr -> !llvm.ptr
    %37 = llvm.getelementptr %36[1008000] : (!llvm.ptr) -> !llvm.ptr, i8
    llvm.intr.assume %13 ["align"(%37, %12 : !llvm.ptr, i64)] : i1
    %38 = llvm.load %arg1 : !llvm.ptr -> !llvm.struct<"iree_hal_executable_dispatch_state_v0_t", (i32, i32, i16, i16, i32, i32, i16, i8, i8, ptr, ptr, ptr)>
    %39 = llvm.extractvalue %38[10] : !llvm.struct<"iree_hal_executable_dispatch_state_v0_t", (i32, i32, i16, i16, i32, i32, i16, i8, i8, ptr, ptr, ptr)> 
    %40 = llvm.load %39 : !llvm.ptr -> !llvm.ptr
    %41 = llvm.getelementptr %40[2016000] : (!llvm.ptr) -> !llvm.ptr, i8
    llvm.intr.assume %13 ["align"(%41, %12 : !llvm.ptr, i64)] : i1
    %42 = llvm.load %arg1 : !llvm.ptr -> !llvm.struct<"iree_hal_executable_dispatch_state_v0_t", (i32, i32, i16, i16, i32, i32, i16, i8, i8, ptr, ptr, ptr)>
    %43 = llvm.extractvalue %42[10] : !llvm.struct<"iree_hal_executable_dispatch_state_v0_t", (i32, i32, i16, i16, i32, i32, i16, i8, i8, ptr, ptr, ptr)> 
    %44 = llvm.getelementptr %43[1] : (!llvm.ptr) -> !llvm.ptr, !llvm.ptr
    %45 = llvm.load %44 : !llvm.ptr -> !llvm.ptr
    llvm.intr.assume %13 ["align"(%45, %12 : !llvm.ptr, i64)] : i1
    llvm.br ^bb1(%30 : i64)
  ^bb1(%46: i64):  // 2 preds: ^bb0, ^bb7
    %47 = llvm.icmp "slt" %46, %27 : i64
    llvm.cond_br %47, ^bb2, ^bb8
  ^bb2:  // pred: ^bb1
    %48 = llvm.mul %46, %19 overflow<nsw> : i64
    %49 = llvm.mul %46, %18 overflow<nsw> : i64
    %50 = llvm.add %49, %29 : i64
    %51 = llvm.intr.smin(%50, %19) : (i64, i64) -> i64
    llvm.br ^bb3(%30 : i64)
  ^bb3(%52: i64):  // 2 preds: ^bb2, ^bb6
    %53 = llvm.icmp "slt" %52, %27 : i64
    llvm.cond_br %53, ^bb4(%30, %26 : i64, !llvm.array<8 x vector<8xf32>>), ^bb7
  ^bb4(%54: i64, %55: !llvm.array<8 x vector<8xf32>>):  // 2 preds: ^bb3, ^bb5
    %56 = llvm.icmp "slt" %54, %29 : i64
    llvm.cond_br %56, ^bb5, ^bb6
  ^bb5:  // pred: ^bb4
    %57 = llvm.mul %46, %14 : i64
    %58 = llvm.mul %54, %19 : i64
    %59 = llvm.add %57, %58 : i64
    %60 = llvm.add %59, %30 : i64
    %61 = llvm.add %60, %30 : i64
    %62 = llvm.getelementptr %33[%61] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    %63 = llvm.load %62 {alignment = 4 : i64} : !llvm.ptr -> vector<8xf32>
    %64 = llvm.mul %52, %14 : i64
    %65 = llvm.mul %54, %19 : i64
    %66 = llvm.add %64, %65 : i64
    %67 = llvm.add %66, %30 : i64
    %68 = llvm.add %67, %30 : i64
    %69 = llvm.getelementptr %37[%68] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    %70 = llvm.load %69 {alignment = 4 : i64} : !llvm.ptr -> vector<8xf32>
    %71 = llvm.extractelement %63[%11 : i64] : vector<8xf32>
    %72 = llvm.insertelement %71, %9[%8 : i32] : vector<8xf32>
    %73 = llvm.shufflevector %72, %9 [0, 0, 0, 0, 0, 0, 0, 0] : vector<8xf32> 
    %74 = llvm.extractvalue %55[0] : !llvm.array<8 x vector<8xf32>> 
    %75 = llvm.intr.fmuladd(%73, %70, %74) : (vector<8xf32>, vector<8xf32>, vector<8xf32>) -> vector<8xf32>
    %76 = llvm.extractelement %63[%7 : i64] : vector<8xf32>
    %77 = llvm.insertelement %76, %9[%8 : i32] : vector<8xf32>
    %78 = llvm.shufflevector %77, %9 [0, 0, 0, 0, 0, 0, 0, 0] : vector<8xf32> 
    %79 = llvm.extractvalue %55[1] : !llvm.array<8 x vector<8xf32>> 
    %80 = llvm.intr.fmuladd(%78, %70, %79) : (vector<8xf32>, vector<8xf32>, vector<8xf32>) -> vector<8xf32>
    %81 = llvm.extractelement %63[%6 : i64] : vector<8xf32>
    %82 = llvm.insertelement %81, %9[%8 : i32] : vector<8xf32>
    %83 = llvm.shufflevector %82, %9 [0, 0, 0, 0, 0, 0, 0, 0] : vector<8xf32> 
    %84 = llvm.extractvalue %55[2] : !llvm.array<8 x vector<8xf32>> 
    %85 = llvm.intr.fmuladd(%83, %70, %84) : (vector<8xf32>, vector<8xf32>, vector<8xf32>) -> vector<8xf32>
    %86 = llvm.extractelement %63[%5 : i64] : vector<8xf32>
    %87 = llvm.insertelement %86, %9[%8 : i32] : vector<8xf32>
    %88 = llvm.shufflevector %87, %9 [0, 0, 0, 0, 0, 0, 0, 0] : vector<8xf32> 
    %89 = llvm.extractvalue %55[3] : !llvm.array<8 x vector<8xf32>> 
    %90 = llvm.intr.fmuladd(%88, %70, %89) : (vector<8xf32>, vector<8xf32>, vector<8xf32>) -> vector<8xf32>
    %91 = llvm.extractelement %63[%4 : i64] : vector<8xf32>
    %92 = llvm.insertelement %91, %9[%8 : i32] : vector<8xf32>
    %93 = llvm.shufflevector %92, %9 [0, 0, 0, 0, 0, 0, 0, 0] : vector<8xf32> 
    %94 = llvm.extractvalue %55[4] : !llvm.array<8 x vector<8xf32>> 
    %95 = llvm.intr.fmuladd(%93, %70, %94) : (vector<8xf32>, vector<8xf32>, vector<8xf32>) -> vector<8xf32>
    %96 = llvm.extractelement %63[%3 : i64] : vector<8xf32>
    %97 = llvm.insertelement %96, %9[%8 : i32] : vector<8xf32>
    %98 = llvm.shufflevector %97, %9 [0, 0, 0, 0, 0, 0, 0, 0] : vector<8xf32> 
    %99 = llvm.extractvalue %55[5] : !llvm.array<8 x vector<8xf32>> 
    %100 = llvm.intr.fmuladd(%98, %70, %99) : (vector<8xf32>, vector<8xf32>, vector<8xf32>) -> vector<8xf32>
    %101 = llvm.extractelement %63[%2 : i64] : vector<8xf32>
    %102 = llvm.insertelement %101, %9[%8 : i32] : vector<8xf32>
    %103 = llvm.shufflevector %102, %9 [0, 0, 0, 0, 0, 0, 0, 0] : vector<8xf32> 
    %104 = llvm.extractvalue %55[6] : !llvm.array<8 x vector<8xf32>> 
    %105 = llvm.intr.fmuladd(%103, %70, %104) : (vector<8xf32>, vector<8xf32>, vector<8xf32>) -> vector<8xf32>
    %106 = llvm.extractelement %63[%1 : i64] : vector<8xf32>
    %107 = llvm.insertelement %106, %9[%8 : i32] : vector<8xf32>
    %108 = llvm.shufflevector %107, %9 [0, 0, 0, 0, 0, 0, 0, 0] : vector<8xf32> 
    %109 = llvm.extractvalue %55[7] : !llvm.array<8 x vector<8xf32>> 
    %110 = llvm.intr.fmuladd(%108, %70, %109) : (vector<8xf32>, vector<8xf32>, vector<8xf32>) -> vector<8xf32>
    %111 = llvm.insertvalue %75, %17[0] : !llvm.array<8 x vector<8xf32>> 
    %112 = llvm.insertvalue %80, %111[1] : !llvm.array<8 x vector<8xf32>> 
    %113 = llvm.insertvalue %85, %112[2] : !llvm.array<8 x vector<8xf32>> 
    %114 = llvm.insertvalue %90, %113[3] : !llvm.array<8 x vector<8xf32>> 
    %115 = llvm.insertvalue %95, %114[4] : !llvm.array<8 x vector<8xf32>> 
    %116 = llvm.insertvalue %100, %115[5] : !llvm.array<8 x vector<8xf32>> 
    %117 = llvm.insertvalue %105, %116[6] : !llvm.array<8 x vector<8xf32>> 
    %118 = llvm.insertvalue %110, %117[7] : !llvm.array<8 x vector<8xf32>> 
    %119 = llvm.add %54, %28 : i64
    llvm.br ^bb4(%119, %118 : i64, !llvm.array<8 x vector<8xf32>>)
  ^bb6:  // pred: ^bb4
    %120 = llvm.mul %46, %10 : i64
    %121 = llvm.mul %52, %12 : i64
    %122 = llvm.add %120, %121 : i64
    %123 = llvm.mul %30, %19 : i64
    %124 = llvm.add %122, %123 : i64
    %125 = llvm.add %124, %30 : i64
    %126 = llvm.getelementptr %41[%125] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    %127 = llvm.load %126 {alignment = 4 : i64} : !llvm.ptr -> vector<8xf32>
    %128 = llvm.mul %46, %10 : i64
    %129 = llvm.mul %52, %12 : i64
    %130 = llvm.add %128, %129 : i64
    %131 = llvm.mul %28, %19 : i64
    %132 = llvm.add %130, %131 : i64
    %133 = llvm.add %132, %30 : i64
    %134 = llvm.getelementptr %41[%133] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    %135 = llvm.load %134 {alignment = 4 : i64} : !llvm.ptr -> vector<8xf32>
    %136 = llvm.mul %46, %10 : i64
    %137 = llvm.mul %52, %12 : i64
    %138 = llvm.add %136, %137 : i64
    %139 = llvm.mul %25, %19 : i64
    %140 = llvm.add %138, %139 : i64
    %141 = llvm.add %140, %30 : i64
    %142 = llvm.getelementptr %41[%141] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    %143 = llvm.load %142 {alignment = 4 : i64} : !llvm.ptr -> vector<8xf32>
    %144 = llvm.mul %46, %10 : i64
    %145 = llvm.mul %52, %12 : i64
    %146 = llvm.add %144, %145 : i64
    %147 = llvm.mul %24, %19 : i64
    %148 = llvm.add %146, %147 : i64
    %149 = llvm.add %148, %30 : i64
    %150 = llvm.getelementptr %41[%149] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    %151 = llvm.load %150 {alignment = 4 : i64} : !llvm.ptr -> vector<8xf32>
    %152 = llvm.mul %46, %10 : i64
    %153 = llvm.mul %52, %12 : i64
    %154 = llvm.add %152, %153 : i64
    %155 = llvm.mul %23, %19 : i64
    %156 = llvm.add %154, %155 : i64
    %157 = llvm.add %156, %30 : i64
    %158 = llvm.getelementptr %41[%157] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    %159 = llvm.load %158 {alignment = 4 : i64} : !llvm.ptr -> vector<8xf32>
    %160 = llvm.mul %46, %10 : i64
    %161 = llvm.mul %52, %12 : i64
    %162 = llvm.add %160, %161 : i64
    %163 = llvm.mul %22, %19 : i64
    %164 = llvm.add %162, %163 : i64
    %165 = llvm.add %164, %30 : i64
    %166 = llvm.getelementptr %41[%165] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    %167 = llvm.load %166 {alignment = 4 : i64} : !llvm.ptr -> vector<8xf32>
    %168 = llvm.mul %46, %10 : i64
    %169 = llvm.mul %52, %12 : i64
    %170 = llvm.add %168, %169 : i64
    %171 = llvm.mul %21, %19 : i64
    %172 = llvm.add %170, %171 : i64
    %173 = llvm.add %172, %30 : i64
    %174 = llvm.getelementptr %41[%173] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    %175 = llvm.load %174 {alignment = 4 : i64} : !llvm.ptr -> vector<8xf32>
    %176 = llvm.mul %46, %10 : i64
    %177 = llvm.mul %52, %12 : i64
    %178 = llvm.add %176, %177 : i64
    %179 = llvm.mul %20, %19 : i64
    %180 = llvm.add %178, %179 : i64
    %181 = llvm.add %180, %30 : i64
    %182 = llvm.getelementptr %41[%181] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    %183 = llvm.load %182 {alignment = 4 : i64} : !llvm.ptr -> vector<8xf32>
    %184 = llvm.extractvalue %55[0] : !llvm.array<8 x vector<8xf32>> 
    %185 = llvm.fadd %184, %127 : vector<8xf32>
    %186 = llvm.extractvalue %55[1] : !llvm.array<8 x vector<8xf32>> 
    %187 = llvm.fadd %186, %135 : vector<8xf32>
    %188 = llvm.extractvalue %55[2] : !llvm.array<8 x vector<8xf32>> 
    %189 = llvm.fadd %188, %143 : vector<8xf32>
    %190 = llvm.extractvalue %55[3] : !llvm.array<8 x vector<8xf32>> 
    %191 = llvm.fadd %190, %151 : vector<8xf32>
    %192 = llvm.extractvalue %55[4] : !llvm.array<8 x vector<8xf32>> 
    %193 = llvm.fadd %192, %159 : vector<8xf32>
    %194 = llvm.extractvalue %55[5] : !llvm.array<8 x vector<8xf32>> 
    %195 = llvm.fadd %194, %167 : vector<8xf32>
    %196 = llvm.extractvalue %55[6] : !llvm.array<8 x vector<8xf32>> 
    %197 = llvm.fadd %196, %175 : vector<8xf32>
    %198 = llvm.extractvalue %55[7] : !llvm.array<8 x vector<8xf32>> 
    %199 = llvm.fadd %198, %183 : vector<8xf32>
    %200 = llvm.mul %52, %19 overflow<nsw> : i64
    %201 = llvm.mul %52, %18 overflow<nsw> : i64
    %202 = llvm.add %201, %29 : i64
    %203 = llvm.intr.smin(%202, %19) : (i64, i64) -> i64
    %204 = llvm.insertelement %203, %0[%8 : i32] : vector<8xi64>
    %205 = llvm.shufflevector %204, %0 [0, 0, 0, 0, 0, 0, 0, 0] : vector<8xi64> 
    %206 = llvm.icmp "sgt" %205, %16 : vector<8xi64>
    %207 = llvm.icmp "sgt" %51, %30 : i64
    %208 = llvm.select %207, %206, %15 : i1, vector<8xi1>
    %209 = llvm.icmp "sgt" %51, %28 : i64
    %210 = llvm.select %209, %206, %15 : i1, vector<8xi1>
    %211 = llvm.icmp "sgt" %51, %25 : i64
    %212 = llvm.select %211, %206, %15 : i1, vector<8xi1>
    %213 = llvm.icmp "sgt" %51, %24 : i64
    %214 = llvm.select %213, %206, %15 : i1, vector<8xi1>
    %215 = llvm.icmp "sgt" %51, %23 : i64
    %216 = llvm.select %215, %206, %15 : i1, vector<8xi1>
    %217 = llvm.icmp "sgt" %51, %22 : i64
    %218 = llvm.select %217, %206, %15 : i1, vector<8xi1>
    %219 = llvm.icmp "sgt" %51, %21 : i64
    %220 = llvm.select %219, %206, %15 : i1, vector<8xi1>
    %221 = llvm.icmp "sgt" %51, %20 : i64
    %222 = llvm.select %221, %206, %15 : i1, vector<8xi1>
    %223 = llvm.mul %48, %29 : i64
    %224 = llvm.add %223, %200 : i64
    %225 = llvm.getelementptr %45[%224] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    llvm.intr.masked.store %185, %225, %208 {alignment = 4 : i32} : vector<8xf32>, vector<8xi1> into !llvm.ptr
    %226 = llvm.add %48, %28 : i64
    %227 = llvm.mul %226, %29 : i64
    %228 = llvm.add %227, %200 : i64
    %229 = llvm.getelementptr %45[%228] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    llvm.intr.masked.store %187, %229, %210 {alignment = 4 : i32} : vector<8xf32>, vector<8xi1> into !llvm.ptr
    %230 = llvm.add %48, %25 : i64
    %231 = llvm.mul %230, %29 : i64
    %232 = llvm.add %231, %200 : i64
    %233 = llvm.getelementptr %45[%232] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    llvm.intr.masked.store %189, %233, %212 {alignment = 4 : i32} : vector<8xf32>, vector<8xi1> into !llvm.ptr
    %234 = llvm.add %48, %24 : i64
    %235 = llvm.mul %234, %29 : i64
    %236 = llvm.add %235, %200 : i64
    %237 = llvm.getelementptr %45[%236] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    llvm.intr.masked.store %191, %237, %214 {alignment = 4 : i32} : vector<8xf32>, vector<8xi1> into !llvm.ptr
    %238 = llvm.add %48, %23 : i64
    %239 = llvm.mul %238, %29 : i64
    %240 = llvm.add %239, %200 : i64
    %241 = llvm.getelementptr %45[%240] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    llvm.intr.masked.store %193, %241, %216 {alignment = 4 : i32} : vector<8xf32>, vector<8xi1> into !llvm.ptr
    %242 = llvm.add %48, %22 : i64
    %243 = llvm.mul %242, %29 : i64
    %244 = llvm.add %243, %200 : i64
    %245 = llvm.getelementptr %45[%244] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    llvm.intr.masked.store %195, %245, %218 {alignment = 4 : i32} : vector<8xf32>, vector<8xi1> into !llvm.ptr
    %246 = llvm.add %48, %21 : i64
    %247 = llvm.mul %246, %29 : i64
    %248 = llvm.add %247, %200 : i64
    %249 = llvm.getelementptr %45[%248] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    llvm.intr.masked.store %197, %249, %220 {alignment = 4 : i32} : vector<8xf32>, vector<8xi1> into !llvm.ptr
    %250 = llvm.add %48, %20 : i64
    %251 = llvm.mul %250, %29 : i64
    %252 = llvm.add %251, %200 : i64
    %253 = llvm.getelementptr %45[%252] : (!llvm.ptr, i64) -> !llvm.ptr, f32
    llvm.intr.masked.store %199, %253, %222 {alignment = 4 : i32} : vector<8xf32>, vector<8xi1> into !llvm.ptr
    %254 = llvm.add %52, %28 : i64
    llvm.br ^bb3(%254 : i64)
  ^bb7:  // pred: ^bb3
    %255 = llvm.add %46, %28 : i64
    llvm.br ^bb1(%255 : i64)
  ^bb8:  // pred: ^bb1
    llvm.return %8 : i32
  }
  iree_codegen.dispatch_config @matmul_dispatch_0_matmul_like_500x500x500_f32 workgroup_size = [1, 1, 1] {
  ^bb0(%arg0: !hal.device):
    %c1 = arith.constant 1 : index
    iree_codegen.yield %c1, %c1, %c1 : index, index, index
  }
}

