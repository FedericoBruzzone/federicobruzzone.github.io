// -----// IR Dump After mlir::iree_compiler::detail::OpPipelineAdaptorPass: iree-op-pipeline-adaptor //----- //
module {
  func.func @matmul_dispatch_0_matmul_like_500x500x500_f32() {
    %c-8 = arith.constant -8 : index
    %c8 = arith.constant 8 : index
    %c7 = arith.constant 7 : index
    %c6 = arith.constant 6 : index
    %c5 = arith.constant 5 : index
    %c4 = arith.constant 4 : index
    %c3 = arith.constant 3 : index
    %c2 = arith.constant 2 : index
    %cst = arith.constant dense<0.000000e+00> : vector<8x8xf32>
    %c63 = arith.constant 63 : index
    %c1 = arith.constant 1 : index
    %c500 = arith.constant 500 : index
    %c0 = arith.constant 0 : index
    %c1008000 = arith.constant 1008000 : index
    %c2016000 = arith.constant 2016000 : index
    %0 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : memref<63x500x8x1xf32>
    %assume_align = memref.assume_alignment %0, 64 : memref<63x500x8x1xf32>
    %1 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c1008000) flags("ReadOnly|Indirect") : memref<63x500x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>>
    %assume_align_0 = memref.assume_alignment %1, 64 : memref<63x500x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>>
    %2 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c2016000) flags("ReadOnly|Indirect") : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>
    %assume_align_1 = memref.assume_alignment %2, 64 : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>
    %3 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags(Indirect) : memref<500x500xf32>
    %assume_align_2 = memref.assume_alignment %3, 64 : memref<500x500xf32>
    cf.br ^bb1(%c0 : index)
  ^bb1(%4: index):  // 2 preds: ^bb0, ^bb7
    %5 = arith.cmpi slt, %4, %c63 : index
    cf.cond_br %5, ^bb2, ^bb8
  ^bb2:  // pred: ^bb1
    %6 = arith.muli %4, %c8 overflow<nsw> : index
    %7 = arith.muli %4, %c-8 overflow<nsw> : index
    %8 = arith.addi %7, %c500 : index
    %9 = arith.minsi %8, %c8 : index
    cf.br ^bb3(%c0 : index)
  ^bb3(%10: index):  // 2 preds: ^bb2, ^bb6
    %11 = arith.cmpi slt, %10, %c63 : index
    cf.cond_br %11, ^bb4(%c0, %cst : index, vector<8x8xf32>), ^bb7
  ^bb4(%12: index, %13: vector<8x8xf32>):  // 2 preds: ^bb3, ^bb5
    %14 = arith.cmpi slt, %12, %c500 : index
    cf.cond_br %14, ^bb5, ^bb6
  ^bb5:  // pred: ^bb4
    %15 = vector.load %assume_align[%4, %12, %c0, %c0] : memref<63x500x8x1xf32>, vector<8xf32>
    %16 = vector.load %assume_align_0[%10, %12, %c0, %c0] : memref<63x500x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>>, vector<8xf32>
    %17 = vector.extract %15[0] : f32 from vector<8xf32>
    %18 = vector.broadcast %17 : f32 to vector<8xf32>
    %19 = vector.extract %13[0] : vector<8xf32> from vector<8x8xf32>
    %20 = vector.fma %18, %16, %19 : vector<8xf32>
    %21 = vector.extract %15[1] : f32 from vector<8xf32>
    %22 = vector.broadcast %21 : f32 to vector<8xf32>
    %23 = vector.extract %13[1] : vector<8xf32> from vector<8x8xf32>
    %24 = vector.fma %22, %16, %23 : vector<8xf32>
    %25 = vector.extract %15[2] : f32 from vector<8xf32>
    %26 = vector.broadcast %25 : f32 to vector<8xf32>
    %27 = vector.extract %13[2] : vector<8xf32> from vector<8x8xf32>
    %28 = vector.fma %26, %16, %27 : vector<8xf32>
    %29 = vector.extract %15[3] : f32 from vector<8xf32>
    %30 = vector.broadcast %29 : f32 to vector<8xf32>
    %31 = vector.extract %13[3] : vector<8xf32> from vector<8x8xf32>
    %32 = vector.fma %30, %16, %31 : vector<8xf32>
    %33 = vector.extract %15[4] : f32 from vector<8xf32>
    %34 = vector.broadcast %33 : f32 to vector<8xf32>
    %35 = vector.extract %13[4] : vector<8xf32> from vector<8x8xf32>
    %36 = vector.fma %34, %16, %35 : vector<8xf32>
    %37 = vector.extract %15[5] : f32 from vector<8xf32>
    %38 = vector.broadcast %37 : f32 to vector<8xf32>
    %39 = vector.extract %13[5] : vector<8xf32> from vector<8x8xf32>
    %40 = vector.fma %38, %16, %39 : vector<8xf32>
    %41 = vector.extract %15[6] : f32 from vector<8xf32>
    %42 = vector.broadcast %41 : f32 to vector<8xf32>
    %43 = vector.extract %13[6] : vector<8xf32> from vector<8x8xf32>
    %44 = vector.fma %42, %16, %43 : vector<8xf32>
    %45 = vector.extract %15[7] : f32 from vector<8xf32>
    %46 = vector.broadcast %45 : f32 to vector<8xf32>
    %47 = vector.extract %13[7] : vector<8xf32> from vector<8x8xf32>
    %48 = vector.fma %46, %16, %47 : vector<8xf32>
    %49:8 = vector.to_elements %20 : vector<8xf32>
    %50:8 = vector.to_elements %24 : vector<8xf32>
    %51:8 = vector.to_elements %28 : vector<8xf32>
    %52:8 = vector.to_elements %32 : vector<8xf32>
    %53:8 = vector.to_elements %36 : vector<8xf32>
    %54:8 = vector.to_elements %40 : vector<8xf32>
    %55:8 = vector.to_elements %44 : vector<8xf32>
    %56:8 = vector.to_elements %48 : vector<8xf32>
    %57 = vector.from_elements %49#0, %49#1, %49#2, %49#3, %49#4, %49#5, %49#6, %49#7, %50#0, %50#1, %50#2, %50#3, %50#4, %50#5, %50#6, %50#7, %51#0, %51#1, %51#2, %51#3, %51#4, %51#5, %51#6, %51#7, %52#0, %52#1, %52#2, %52#3, %52#4, %52#5, %52#6, %52#7, %53#0, %53#1, %53#2, %53#3, %53#4, %53#5, %53#6, %53#7, %54#0, %54#1, %54#2, %54#3, %54#4, %54#5, %54#6, %54#7, %55#0, %55#1, %55#2, %55#3, %55#4, %55#5, %55#6, %55#7, %56#0, %56#1, %56#2, %56#3, %56#4, %56#5, %56#6, %56#7 : vector<8x8xf32>
    %58 = arith.addi %12, %c1 : index
    cf.br ^bb4(%58, %57 : index, vector<8x8xf32>)
  ^bb6:  // pred: ^bb4
    %59 = vector.load %assume_align_1[%4, %10, %c0, %c0] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>, vector<8xf32>
    %60 = vector.load %assume_align_1[%4, %10, %c1, %c0] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>, vector<8xf32>
    %61 = vector.load %assume_align_1[%4, %10, %c2, %c0] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>, vector<8xf32>
    %62 = vector.load %assume_align_1[%4, %10, %c3, %c0] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>, vector<8xf32>
    %63 = vector.load %assume_align_1[%4, %10, %c4, %c0] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>, vector<8xf32>
    %64 = vector.load %assume_align_1[%4, %10, %c5, %c0] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>, vector<8xf32>
    %65 = vector.load %assume_align_1[%4, %10, %c6, %c0] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>, vector<8xf32>
    %66 = vector.load %assume_align_1[%4, %10, %c7, %c0] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>, vector<8xf32>
    %67:8 = vector.to_elements %59 : vector<8xf32>
    %68:8 = vector.to_elements %60 : vector<8xf32>
    %69:8 = vector.to_elements %61 : vector<8xf32>
    %70:8 = vector.to_elements %62 : vector<8xf32>
    %71:8 = vector.to_elements %63 : vector<8xf32>
    %72:8 = vector.to_elements %64 : vector<8xf32>
    %73:8 = vector.to_elements %65 : vector<8xf32>
    %74:8 = vector.to_elements %66 : vector<8xf32>
    %75 = vector.from_elements %67#0, %67#1, %67#2, %67#3, %67#4, %67#5, %67#6, %67#7, %68#0, %68#1, %68#2, %68#3, %68#4, %68#5, %68#6, %68#7, %69#0, %69#1, %69#2, %69#3, %69#4, %69#5, %69#6, %69#7, %70#0, %70#1, %70#2, %70#3, %70#4, %70#5, %70#6, %70#7, %71#0, %71#1, %71#2, %71#3, %71#4, %71#5, %71#6, %71#7, %72#0, %72#1, %72#2, %72#3, %72#4, %72#5, %72#6, %72#7, %73#0, %73#1, %73#2, %73#3, %73#4, %73#5, %73#6, %73#7, %74#0, %74#1, %74#2, %74#3, %74#4, %74#5, %74#6, %74#7 : vector<8x8xf32>
    %76 = arith.addf %13, %75 : vector<8x8xf32>
    %77 = arith.muli %10, %c8 overflow<nsw> : index
    %78 = arith.muli %10, %c-8 overflow<nsw> : index
    %79 = arith.addi %78, %c500 : index
    %80 = arith.minsi %79, %c8 : index
    %81 = vector.create_mask %9, %80 : vector<8x8xi1>
    %82 = vector.extract %76[0] : vector<8xf32> from vector<8x8xf32>
    %83 = vector.extract %81[0] : vector<8xi1> from vector<8x8xi1>
    vector.maskedstore %assume_align_2[%6, %77], %83, %82 : memref<500x500xf32>, vector<8xi1>, vector<8xf32>
    %84 = vector.extract %76[1] : vector<8xf32> from vector<8x8xf32>
    %85 = vector.extract %81[1] : vector<8xi1> from vector<8x8xi1>
    %86 = affine.apply affine_map<()[s0] -> (s0 + 1)>()[%6]
    vector.maskedstore %assume_align_2[%86, %77], %85, %84 : memref<500x500xf32>, vector<8xi1>, vector<8xf32>
    %87 = vector.extract %76[2] : vector<8xf32> from vector<8x8xf32>
    %88 = vector.extract %81[2] : vector<8xi1> from vector<8x8xi1>
    %89 = affine.apply affine_map<()[s0] -> (s0 + 2)>()[%6]
    vector.maskedstore %assume_align_2[%89, %77], %88, %87 : memref<500x500xf32>, vector<8xi1>, vector<8xf32>
    %90 = vector.extract %76[3] : vector<8xf32> from vector<8x8xf32>
    %91 = vector.extract %81[3] : vector<8xi1> from vector<8x8xi1>
    %92 = affine.apply affine_map<()[s0] -> (s0 + 3)>()[%6]
    vector.maskedstore %assume_align_2[%92, %77], %91, %90 : memref<500x500xf32>, vector<8xi1>, vector<8xf32>
    %93 = vector.extract %76[4] : vector<8xf32> from vector<8x8xf32>
    %94 = vector.extract %81[4] : vector<8xi1> from vector<8x8xi1>
    %95 = affine.apply affine_map<()[s0] -> (s0 + 4)>()[%6]
    vector.maskedstore %assume_align_2[%95, %77], %94, %93 : memref<500x500xf32>, vector<8xi1>, vector<8xf32>
    %96 = vector.extract %76[5] : vector<8xf32> from vector<8x8xf32>
    %97 = vector.extract %81[5] : vector<8xi1> from vector<8x8xi1>
    %98 = affine.apply affine_map<()[s0] -> (s0 + 5)>()[%6]
    vector.maskedstore %assume_align_2[%98, %77], %97, %96 : memref<500x500xf32>, vector<8xi1>, vector<8xf32>
    %99 = vector.extract %76[6] : vector<8xf32> from vector<8x8xf32>
    %100 = vector.extract %81[6] : vector<8xi1> from vector<8x8xi1>
    %101 = affine.apply affine_map<()[s0] -> (s0 + 6)>()[%6]
    vector.maskedstore %assume_align_2[%101, %77], %100, %99 : memref<500x500xf32>, vector<8xi1>, vector<8xf32>
    %102 = vector.extract %76[7] : vector<8xf32> from vector<8x8xf32>
    %103 = vector.extract %81[7] : vector<8xi1> from vector<8x8xi1>
    %104 = affine.apply affine_map<()[s0] -> (s0 + 7)>()[%6]
    vector.maskedstore %assume_align_2[%104, %77], %103, %102 : memref<500x500xf32>, vector<8xi1>, vector<8xf32>
    %105 = arith.addi %10, %c1 : index
    cf.br ^bb3(%105 : index)
  ^bb7:  // pred: ^bb3
    %106 = arith.addi %4, %c1 : index
    cf.br ^bb1(%106 : index)
  ^bb8:  // pred: ^bb1
    return
  }
  iree_codegen.dispatch_config @matmul_dispatch_0_matmul_like_500x500x500_f32 workgroup_size = [1, 1, 1] {
  ^bb0(%arg0: !hal.device):
    %c1 = arith.constant 1 : index
    iree_codegen.yield %c1, %c1, %c1 : index, index, index
  }
}

