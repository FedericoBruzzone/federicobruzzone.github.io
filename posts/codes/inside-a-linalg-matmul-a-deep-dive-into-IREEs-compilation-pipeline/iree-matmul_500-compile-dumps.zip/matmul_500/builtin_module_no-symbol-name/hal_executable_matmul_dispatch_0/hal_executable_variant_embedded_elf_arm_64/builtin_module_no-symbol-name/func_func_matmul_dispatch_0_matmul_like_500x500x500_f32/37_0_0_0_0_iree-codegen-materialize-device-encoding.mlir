// -----// IR Dump After MaterializeDeviceEncodingPass: iree-codegen-materialize-device-encoding{test-gpu-encoding-resolver=none} //----- //
func.func @matmul_dispatch_0_matmul_like_500x500x500_f32() {
  %c0 = arith.constant 0 : index
  %c1008000 = arith.constant 1008000 : index
  %c2016000 = arith.constant 2016000 : index
  %0 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<63x500x8x1xf32>>
  %1 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c1008000) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<63x500x8x1xf32>>
  %2 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c2016000) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<63x63x8x8xf32>>
  %3 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<500x500xf32>>
  %4 = iree_tensor_ext.dispatch.tensor.load %0, offsets = [0, 0, 0, 0], sizes = [63, 500, 8, 1], strides = [1, 1, 1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<63x500x8x1xf32>> -> tensor<63x500x8x1xf32>
  %5 = iree_tensor_ext.dispatch.tensor.load %1, offsets = [0, 0, 0, 0], sizes = [63, 500, 8, 1], strides = [1, 1, 1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<63x500x8x1xf32>> -> tensor<63x500x8x1xf32>
  %6 = iree_tensor_ext.dispatch.tensor.load %2, offsets = [0, 0, 0, 0], sizes = [63, 63, 8, 8], strides = [1, 1, 1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<63x63x8x8xf32>> -> tensor<63x63x8x8xf32>
  %7 = linalg.mmt4d ins(%4, %5 : tensor<63x500x8x1xf32>, tensor<63x500x8x1xf32>) outs(%6 : tensor<63x63x8x8xf32>) -> tensor<63x63x8x8xf32>
  %8 = tensor.empty() : tensor<500x500xf32>
  %unpack = linalg.unpack %7 outer_dims_perm = [0, 1] inner_dims_pos = [0, 1] inner_tiles = [8, 8] into %8 : tensor<63x63x8x8xf32> -> tensor<500x500xf32>
  iree_tensor_ext.dispatch.tensor.store %unpack, %3, offsets = [0, 0], sizes = [500, 500], strides = [1, 1] : tensor<500x500xf32> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<500x500xf32>>
  return
}

