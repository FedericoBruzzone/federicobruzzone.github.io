// -----// IR Dump After ConvertAccGEMMToGEMMPass: iree-convert-accgemm-to-gemm //----- //
func.func @matmul_dispatch_0_matmul_like_500x500x500_f32() {
  %c0 = arith.constant 0 : index
  %c1008000 = arith.constant 1008000 : index
  %c2016000 = arith.constant 2016000 : index
  %0 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<63x500x8x1xf32>>
  %1 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c1008000) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<63x500x8x1xf32>>
  %2 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c2016000) flags("ReadOnly|Indirect") : !iree_tensor_ext.dispatch.tensor<readonly:tensor<63x63x8x8xf32>>
  %3 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags(Indirect) : !iree_tensor_ext.dispatch.tensor<writeonly:tensor<500x500xf32>>
  %4 = iree_tensor_ext.dispatch.tensor.load %0, offsets = [0, 0, 0, 0], sizes = [63, 500, 8, 1], strides = [1, 1, 1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<63x500x8x1xf32>> -> tensor<63x500x8x1xf32>
  %5 = iree_tensor_ext.dispatch.tensor.load %1, offsets = [0, 0, 0, 0], sizes = [63, 500, 8, 1], strides = [1, 1, 1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<63x500x8x1xf32>> -> tensor<63x500x8x1xf32>
  %6 = iree_tensor_ext.dispatch.tensor.load %2, offsets = [0, 0, 0, 0], sizes = [63, 63, 8, 8], strides = [1, 1, 1, 1] : !iree_tensor_ext.dispatch.tensor<readonly:tensor<63x63x8x8xf32>> -> tensor<63x63x8x8xf32>
  %7 = tensor.empty() : tensor<63x63x8x8xf32>
  %cst = arith.constant 0.000000e+00 : f32
  %8 = linalg.fill ins(%cst : f32) outs(%7 : tensor<63x63x8x8xf32>) -> tensor<63x63x8x8xf32>
  %9 = linalg.mmt4d ins(%4, %5 : tensor<63x500x8x1xf32>, tensor<63x500x8x1xf32>) outs(%8 : tensor<63x63x8x8xf32>) -> tensor<63x63x8x8xf32>
  %10 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%9, %6 : tensor<63x63x8x8xf32>, tensor<63x63x8x8xf32>) outs(%7 : tensor<63x63x8x8xf32>) {
  ^bb0(%in: f32, %in_0: f32, %out: f32):
    %12 = arith.addf %in, %in_0 : f32
    linalg.yield %12 : f32
  } -> tensor<63x63x8x8xf32>
  %11 = tensor.empty() : tensor<500x500xf32>
  %unpack = linalg.unpack %10 outer_dims_perm = [0, 1] inner_dims_pos = [0, 1] inner_tiles = [8, 8] into %11 : tensor<63x63x8x8xf32> -> tensor<500x500xf32>
  iree_tensor_ext.dispatch.tensor.store %unpack, %3, offsets = [0, 0], sizes = [500, 500], strides = [1, 1] : tensor<500x500xf32> -> !iree_tensor_ext.dispatch.tensor<writeonly:tensor<500x500xf32>>
  return
}

