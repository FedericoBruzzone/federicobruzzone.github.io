// -----// IR Dump After CSEPass: cse //----- //
func.func @matmul_dispatch_0_matmul_like_500x500x500_f32() attributes {translation_info = #iree_codegen.translation_info<pipeline = #iree_cpu.pipeline<Mmt4dTilingExpert>>} {
  %cst = arith.constant dense<0.000000e+00> : vector<1x1x8x8xf32>
  %0 = ub.poison : f32
  %c63 = arith.constant 63 : index
  %c1 = arith.constant 1 : index
  %c500 = arith.constant 500 : index
  %c0 = arith.constant 0 : index
  %c1008000 = arith.constant 1008000 : index
  %c2016000 = arith.constant 2016000 : index
  %1 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : memref<63x500x8x1xf32, #hal.descriptor_type<storage_buffer>>
  %assume_align = memref.assume_alignment %1, 64 : memref<63x500x8x1xf32, #hal.descriptor_type<storage_buffer>>
  %2 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c1008000) flags("ReadOnly|Indirect") : memref<63x500x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
  %assume_align_0 = memref.assume_alignment %2, 64 : memref<63x500x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
  %3 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c2016000) flags("ReadOnly|Indirect") : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
  %assume_align_1 = memref.assume_alignment %3, 64 : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
  %4 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags(Indirect) : memref<500x500xf32, #hal.descriptor_type<storage_buffer>>
  %assume_align_2 = memref.assume_alignment %4, 64 : memref<500x500xf32, #hal.descriptor_type<storage_buffer>>
  scf.for %arg0 = %c0 to %c63 step %c1 {
    %5 = affine.apply affine_map<(d0) -> (d0 * 8)>(%arg0)
    %6 = affine.min affine_map<(d0) -> (d0 * -8 + 500, 8)>(%arg0)
    scf.for %arg1 = %c0 to %c63 step %c1 {
      %7 = scf.for %arg2 = %c0 to %c500 step %c1 iter_args(%arg3 = %cst) -> (vector<1x1x8x8xf32>) {
        %14 = vector.transfer_read %assume_align[%arg0, %arg2, %c0, %c0], %0 {in_bounds = [true, true, true, true]} : memref<63x500x8x1xf32, #hal.descriptor_type<storage_buffer>>, vector<1x1x8x1xf32>
        %15 = vector.transfer_read %assume_align_0[%arg1, %arg2, %c0, %c0], %0 {in_bounds = [true, true, true, true]} : memref<63x500x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>, vector<1x1x8x1xf32>
        %16 = vector.contract {indexing_maps = [affine_map<(d0, d1, d2, d3, d4, d5) -> (d0, d2, d3, d5)>, affine_map<(d0, d1, d2, d3, d4, d5) -> (d1, d2, d4, d5)>, affine_map<(d0, d1, d2, d3, d4, d5) -> (d0, d1, d3, d4)>], iterator_types = ["parallel", "parallel", "reduction", "parallel", "parallel", "reduction"], kind = #vector.kind<add>} %14, %15, %arg3 : vector<1x1x8x1xf32>, vector<1x1x8x1xf32> into vector<1x1x8x8xf32>
        scf.yield %16 : vector<1x1x8x8xf32>
      }
      %8 = vector.transfer_read %assume_align_1[%arg0, %arg1, %c0, %c0], %0 {in_bounds = [true, true, true, true]} : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>, vector<1x1x8x8xf32>
      %9 = arith.addf %7, %8 : vector<1x1x8x8xf32>
      %10 = affine.apply affine_map<(d0) -> (d0 * 8)>(%arg1)
      %11 = affine.min affine_map<(d0) -> (d0 * -8 + 500, 8)>(%arg1)
      %subview = memref.subview %assume_align_2[%5, %10] [%6, %11] [1, 1] : memref<500x500xf32, #hal.descriptor_type<storage_buffer>> to memref<?x?xf32, strided<[500, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
      %12 = vector.shape_cast %9 : vector<1x1x8x8xf32> to vector<8x8xf32>
      %13 = vector.create_mask %6, %11 : vector<8x8xi1>
      vector.transfer_write %12, %subview[%c0, %c0], %13 {in_bounds = [true, true]} : vector<8x8xf32>, memref<?x?xf32, strided<[500, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
      linalg.generic {indexing_maps = [affine_map<(d0, d1) -> (d0, d1)>, affine_map<(d0, d1) -> (d0, d1)>], iterator_types = ["parallel", "parallel"]} ins(%subview : memref<?x?xf32, strided<[500, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>) outs(%subview : memref<?x?xf32, strided<[500, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>) {
      ^bb0(%in: f32, %out: f32):
        linalg.yield %in : f32
      }
    }
  }
  return
}

