// -----// IR Dump After LLVMCPUVirtualVectorLoweringPass: iree-llvmcpu-virtual-vector-lowering{enable-arm-i8mm=true split-transfers=linalg-copy} //----- //
func.func @matmul_dispatch_0_matmul_like_500x500x500_f32() attributes {translation_info = #iree_codegen.translation_info<pipeline = #iree_cpu.pipeline<Mmt4dTilingExpert>>} {
  %cst = arith.constant dense<0.000000e+00> : vector<8x8xf32>
  %0 = ub.poison : f32
  %c63 = arith.constant 63 : index
  %c1 = arith.constant 1 : index
  %c500 = arith.constant 500 : index
  %c0 = arith.constant 0 : index
  %c1008000 = arith.constant 1008000 : index
  %c2016000 = arith.constant 2016000 : index
  %1 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : memref<63x500x8x1xf32, #hal.descriptor_type<storage_buffer>>
  %assume_align = memref.assume_alignment %1, 64 : memref<63x500x8x1xf32, #hal.descriptor_type<storage_buffer>>
  %2 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c1008000) flags("ReadOnly|Indirect") : memref<63x500x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
  %assume_align_0 = memref.assume_alignment %2, 64 : memref<63x500x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
  %3 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c2016000) flags("ReadOnly|Indirect") : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
  %assume_align_1 = memref.assume_alignment %3, 64 : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
  %4 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags(Indirect) : memref<500x500xf32, #hal.descriptor_type<storage_buffer>>
  %assume_align_2 = memref.assume_alignment %4, 64 : memref<500x500xf32, #hal.descriptor_type<storage_buffer>>
  scf.for %arg0 = %c0 to %c63 step %c1 {
    %5 = affine.apply affine_map<(d0) -> (d0 * 8)>(%arg0)
    %6 = affine.min affine_map<(d0) -> (d0 * -8 + 500, 8)>(%arg0)
    scf.for %arg1 = %c0 to %c63 step %c1 {
      %7 = scf.for %arg2 = %c0 to %c500 step %c1 iter_args(%arg3 = %cst) -> (vector<8x8xf32>) {
        %subview_3 = memref.subview %assume_align[0, 0, 0, 0] [63, 500, 8, 1] [1, 1, 1, 1] : memref<63x500x8x1xf32, #hal.descriptor_type<storage_buffer>> to memref<63x500x8xf32, strided<[4000, 8, 1]>, #hal.descriptor_type<storage_buffer>>
        %13 = vector.transfer_read %subview_3[%arg0, %arg2, %c0], %0 {in_bounds = [true]} : memref<63x500x8xf32, strided<[4000, 8, 1]>, #hal.descriptor_type<storage_buffer>>, vector<8xf32>
        %subview_4 = memref.subview %assume_align_0[0, 0, 0, 0] [63, 500, 8, 1] [1, 1, 1, 1] : memref<63x500x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>, #hal.descriptor_type<storage_buffer>> to memref<63x500x8xf32, strided<[4000, 8, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
        %14 = vector.transfer_read %subview_4[%arg1, %arg2, %c0], %0 {in_bounds = [true]} : memref<63x500x8xf32, strided<[4000, 8, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>, vector<8xf32>
        %15 = vector.shape_cast %14 : vector<8xf32> to vector<8x1xf32>
        %16 = vector.transpose %15, [1, 0] : vector<8x1xf32> to vector<1x8xf32>
        %17 = vector.extract %16[0] : vector<8xf32> from vector<1x8xf32>
        %18 = vector.extract %13[0] : f32 from vector<8xf32>
        %19 = vector.broadcast %18 : f32 to vector<8xf32>
        %20 = vector.extract %arg3[0] : vector<8xf32> from vector<8x8xf32>
        %21 = vector.fma %19, %17, %20 : vector<8xf32>
        %22 = vector.insert %21, %cst [0] : vector<8xf32> into vector<8x8xf32>
        %23 = vector.extract %13[1] : f32 from vector<8xf32>
        %24 = vector.broadcast %23 : f32 to vector<8xf32>
        %25 = vector.extract %arg3[1] : vector<8xf32> from vector<8x8xf32>
        %26 = vector.fma %24, %17, %25 : vector<8xf32>
        %27 = vector.insert %26, %22 [1] : vector<8xf32> into vector<8x8xf32>
        %28 = vector.extract %13[2] : f32 from vector<8xf32>
        %29 = vector.broadcast %28 : f32 to vector<8xf32>
        %30 = vector.extract %arg3[2] : vector<8xf32> from vector<8x8xf32>
        %31 = vector.fma %29, %17, %30 : vector<8xf32>
        %32 = vector.insert %31, %27 [2] : vector<8xf32> into vector<8x8xf32>
        %33 = vector.extract %13[3] : f32 from vector<8xf32>
        %34 = vector.broadcast %33 : f32 to vector<8xf32>
        %35 = vector.extract %arg3[3] : vector<8xf32> from vector<8x8xf32>
        %36 = vector.fma %34, %17, %35 : vector<8xf32>
        %37 = vector.insert %36, %32 [3] : vector<8xf32> into vector<8x8xf32>
        %38 = vector.extract %13[4] : f32 from vector<8xf32>
        %39 = vector.broadcast %38 : f32 to vector<8xf32>
        %40 = vector.extract %arg3[4] : vector<8xf32> from vector<8x8xf32>
        %41 = vector.fma %39, %17, %40 : vector<8xf32>
        %42 = vector.insert %41, %37 [4] : vector<8xf32> into vector<8x8xf32>
        %43 = vector.extract %13[5] : f32 from vector<8xf32>
        %44 = vector.broadcast %43 : f32 to vector<8xf32>
        %45 = vector.extract %arg3[5] : vector<8xf32> from vector<8x8xf32>
        %46 = vector.fma %44, %17, %45 : vector<8xf32>
        %47 = vector.insert %46, %42 [5] : vector<8xf32> into vector<8x8xf32>
        %48 = vector.extract %13[6] : f32 from vector<8xf32>
        %49 = vector.broadcast %48 : f32 to vector<8xf32>
        %50 = vector.extract %arg3[6] : vector<8xf32> from vector<8x8xf32>
        %51 = vector.fma %49, %17, %50 : vector<8xf32>
        %52 = vector.insert %51, %47 [6] : vector<8xf32> into vector<8x8xf32>
        %53 = vector.extract %13[7] : f32 from vector<8xf32>
        %54 = vector.broadcast %53 : f32 to vector<8xf32>
        %55 = vector.extract %arg3[7] : vector<8xf32> from vector<8x8xf32>
        %56 = vector.fma %54, %17, %55 : vector<8xf32>
        %57 = vector.insert %56, %52 [7] : vector<8xf32> into vector<8x8xf32>
        scf.yield %57 : vector<8x8xf32>
      }
      %8 = vector.transfer_read %assume_align_1[%arg0, %arg1, %c0, %c0], %0 {in_bounds = [true, true]} : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>, vector<8x8xf32>
      %9 = arith.addf %7, %8 : vector<8x8xf32>
      %10 = affine.apply affine_map<(d0) -> (d0 * 8)>(%arg1)
      %11 = affine.min affine_map<(d0) -> (d0 * -8 + 500, 8)>(%arg1)
      %subview = memref.subview %assume_align_2[%5, %10] [%6, %11] [1, 1] : memref<500x500xf32, #hal.descriptor_type<storage_buffer>> to memref<?x?xf32, strided<[500, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
      %12 = vector.create_mask %6, %11 : vector<8x8xi1>
      vector.transfer_write %9, %subview[%c0, %c0], %12 {in_bounds = [true, true]} : vector<8x8xf32>, memref<?x?xf32, strided<[500, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
    }
  }
  return
}

