// -----// IR Dump After VectorTransferLoweringPass: iree-codegen-vector-transfer-lowering{enable-scalable-lowerings=false} //----- //
func.func @matmul_dispatch_0_matmul_like_500x500x500_f32() attributes {translation_info = #iree_codegen.translation_info<pipeline = #iree_cpu.pipeline<Mmt4dTilingExpert>>} {
  %c7 = arith.constant 7 : index
  %c6 = arith.constant 6 : index
  %c5 = arith.constant 5 : index
  %c4 = arith.constant 4 : index
  %c3 = arith.constant 3 : index
  %c2 = arith.constant 2 : index
  %0 = ub.poison : vector<8x8xf32>
  %cst = arith.constant dense<0.000000e+00> : vector<8x8xf32>
  %c63 = arith.constant 63 : index
  %c1 = arith.constant 1 : index
  %c500 = arith.constant 500 : index
  %c0 = arith.constant 0 : index
  %c1008000 = arith.constant 1008000 : index
  %c2016000 = arith.constant 2016000 : index
  %1 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : memref<63x500x8x1xf32, #hal.descriptor_type<storage_buffer>>
  %assume_align = memref.assume_alignment %1, 64 : memref<63x500x8x1xf32, #hal.descriptor_type<storage_buffer>>
  %2 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c1008000) flags("ReadOnly|Indirect") : memref<63x500x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
  %assume_align_0 = memref.assume_alignment %2, 64 : memref<63x500x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
  %3 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c2016000) flags("ReadOnly|Indirect") : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
  %assume_align_1 = memref.assume_alignment %3, 64 : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
  %4 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags(Indirect) : memref<500x500xf32, #hal.descriptor_type<storage_buffer>>
  %assume_align_2 = memref.assume_alignment %4, 64 : memref<500x500xf32, #hal.descriptor_type<storage_buffer>>
  scf.for %arg0 = %c0 to %c63 step %c1 {
    %5 = affine.apply affine_map<(d0) -> (d0 * 8)>(%arg0)
    %6 = affine.min affine_map<(d0) -> (d0 * -8 + 500, 8)>(%arg0)
    scf.for %arg1 = %c0 to %c63 step %c1 {
      %7 = scf.for %arg2 = %c0 to %c500 step %c1 iter_args(%arg3 = %cst) -> (vector<8x8xf32>) {
        %subview_3 = memref.subview %assume_align[0, 0, 0, 0] [63, 500, 8, 1] [1, 1, 1, 1] : memref<63x500x8x1xf32, #hal.descriptor_type<storage_buffer>> to memref<63x500x8xf32, strided<[4000, 8, 1]>, #hal.descriptor_type<storage_buffer>>
        %44 = vector.load %subview_3[%arg0, %arg2, %c0] : memref<63x500x8xf32, strided<[4000, 8, 1]>, #hal.descriptor_type<storage_buffer>>, vector<8xf32>
        %subview_4 = memref.subview %assume_align_0[0, 0, 0, 0] [63, 500, 8, 1] [1, 1, 1, 1] : memref<63x500x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>, #hal.descriptor_type<storage_buffer>> to memref<63x500x8xf32, strided<[4000, 8, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
        %45 = vector.load %subview_4[%arg1, %arg2, %c0] : memref<63x500x8xf32, strided<[4000, 8, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>, vector<8xf32>
        %46 = vector.extract %44[0] : f32 from vector<8xf32>
        %47 = vector.broadcast %46 : f32 to vector<8xf32>
        %48 = vector.extract %arg3[0] : vector<8xf32> from vector<8x8xf32>
        %49 = vector.fma %47, %45, %48 : vector<8xf32>
        %50 = vector.extract %44[1] : f32 from vector<8xf32>
        %51 = vector.broadcast %50 : f32 to vector<8xf32>
        %52 = vector.extract %arg3[1] : vector<8xf32> from vector<8x8xf32>
        %53 = vector.fma %51, %45, %52 : vector<8xf32>
        %54 = vector.extract %44[2] : f32 from vector<8xf32>
        %55 = vector.broadcast %54 : f32 to vector<8xf32>
        %56 = vector.extract %arg3[2] : vector<8xf32> from vector<8x8xf32>
        %57 = vector.fma %55, %45, %56 : vector<8xf32>
        %58 = vector.extract %44[3] : f32 from vector<8xf32>
        %59 = vector.broadcast %58 : f32 to vector<8xf32>
        %60 = vector.extract %arg3[3] : vector<8xf32> from vector<8x8xf32>
        %61 = vector.fma %59, %45, %60 : vector<8xf32>
        %62 = vector.extract %44[4] : f32 from vector<8xf32>
        %63 = vector.broadcast %62 : f32 to vector<8xf32>
        %64 = vector.extract %arg3[4] : vector<8xf32> from vector<8x8xf32>
        %65 = vector.fma %63, %45, %64 : vector<8xf32>
        %66 = vector.extract %44[5] : f32 from vector<8xf32>
        %67 = vector.broadcast %66 : f32 to vector<8xf32>
        %68 = vector.extract %arg3[5] : vector<8xf32> from vector<8x8xf32>
        %69 = vector.fma %67, %45, %68 : vector<8xf32>
        %70 = vector.extract %44[6] : f32 from vector<8xf32>
        %71 = vector.broadcast %70 : f32 to vector<8xf32>
        %72 = vector.extract %arg3[6] : vector<8xf32> from vector<8x8xf32>
        %73 = vector.fma %71, %45, %72 : vector<8xf32>
        %74 = vector.extract %44[7] : f32 from vector<8xf32>
        %75 = vector.broadcast %74 : f32 to vector<8xf32>
        %76 = vector.extract %arg3[7] : vector<8xf32> from vector<8x8xf32>
        %77 = vector.fma %75, %45, %76 : vector<8xf32>
        %78:8 = vector.to_elements %49 : vector<8xf32>
        %79:8 = vector.to_elements %53 : vector<8xf32>
        %80:8 = vector.to_elements %57 : vector<8xf32>
        %81:8 = vector.to_elements %61 : vector<8xf32>
        %82:8 = vector.to_elements %65 : vector<8xf32>
        %83:8 = vector.to_elements %69 : vector<8xf32>
        %84:8 = vector.to_elements %73 : vector<8xf32>
        %85:8 = vector.to_elements %77 : vector<8xf32>
        %86 = vector.from_elements %78#0, %78#1, %78#2, %78#3, %78#4, %78#5, %78#6, %78#7, %79#0, %79#1, %79#2, %79#3, %79#4, %79#5, %79#6, %79#7, %80#0, %80#1, %80#2, %80#3, %80#4, %80#5, %80#6, %80#7, %81#0, %81#1, %81#2, %81#3, %81#4, %81#5, %81#6, %81#7, %82#0, %82#1, %82#2, %82#3, %82#4, %82#5, %82#6, %82#7, %83#0, %83#1, %83#2, %83#3, %83#4, %83#5, %83#6, %83#7, %84#0, %84#1, %84#2, %84#3, %84#4, %84#5, %84#6, %84#7, %85#0, %85#1, %85#2, %85#3, %85#4, %85#5, %85#6, %85#7 : vector<8x8xf32>
        scf.yield %86 : vector<8x8xf32>
      }
      %8 = vector.load %assume_align_1[%arg0, %arg1, %c0, %c0] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>, vector<8xf32>
      %9 = vector.insert %8, %0 [0] : vector<8xf32> into vector<8x8xf32>
      %10 = vector.load %assume_align_1[%arg0, %arg1, %c1, %c0] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>, vector<8xf32>
      %11 = vector.insert %10, %9 [1] : vector<8xf32> into vector<8x8xf32>
      %12 = vector.load %assume_align_1[%arg0, %arg1, %c2, %c0] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>, vector<8xf32>
      %13 = vector.insert %12, %11 [2] : vector<8xf32> into vector<8x8xf32>
      %14 = vector.load %assume_align_1[%arg0, %arg1, %c3, %c0] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>, vector<8xf32>
      %15 = vector.insert %14, %13 [3] : vector<8xf32> into vector<8x8xf32>
      %16 = vector.load %assume_align_1[%arg0, %arg1, %c4, %c0] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>, vector<8xf32>
      %17 = vector.insert %16, %15 [4] : vector<8xf32> into vector<8x8xf32>
      %18 = vector.load %assume_align_1[%arg0, %arg1, %c5, %c0] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>, vector<8xf32>
      %19 = vector.insert %18, %17 [5] : vector<8xf32> into vector<8x8xf32>
      %20 = vector.load %assume_align_1[%arg0, %arg1, %c6, %c0] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>, vector<8xf32>
      %21 = vector.insert %20, %19 [6] : vector<8xf32> into vector<8x8xf32>
      %22 = vector.load %assume_align_1[%arg0, %arg1, %c7, %c0] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>, vector<8xf32>
      %23 = vector.insert %22, %21 [7] : vector<8xf32> into vector<8x8xf32>
      %24 = arith.addf %7, %23 : vector<8x8xf32>
      %25 = affine.apply affine_map<(d0) -> (d0 * 8)>(%arg1)
      %26 = affine.min affine_map<(d0) -> (d0 * -8 + 500, 8)>(%arg1)
      %subview = memref.subview %assume_align_2[%5, %25] [%6, %26] [1, 1] : memref<500x500xf32, #hal.descriptor_type<storage_buffer>> to memref<?x?xf32, strided<[500, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
      %27 = vector.create_mask %6, %26 : vector<8x8xi1>
      %28 = vector.extract %24[0] : vector<8xf32> from vector<8x8xf32>
      %29 = vector.extract %27[0] : vector<8xi1> from vector<8x8xi1>
      vector.maskedstore %subview[%c0, %c0], %29, %28 : memref<?x?xf32, strided<[500, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>, vector<8xi1>, vector<8xf32>
      %30 = vector.extract %24[1] : vector<8xf32> from vector<8x8xf32>
      %31 = vector.extract %27[1] : vector<8xi1> from vector<8x8xi1>
      vector.maskedstore %subview[%c1, %c0], %31, %30 : memref<?x?xf32, strided<[500, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>, vector<8xi1>, vector<8xf32>
      %32 = vector.extract %24[2] : vector<8xf32> from vector<8x8xf32>
      %33 = vector.extract %27[2] : vector<8xi1> from vector<8x8xi1>
      vector.maskedstore %subview[%c2, %c0], %33, %32 : memref<?x?xf32, strided<[500, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>, vector<8xi1>, vector<8xf32>
      %34 = vector.extract %24[3] : vector<8xf32> from vector<8x8xf32>
      %35 = vector.extract %27[3] : vector<8xi1> from vector<8x8xi1>
      vector.maskedstore %subview[%c3, %c0], %35, %34 : memref<?x?xf32, strided<[500, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>, vector<8xi1>, vector<8xf32>
      %36 = vector.extract %24[4] : vector<8xf32> from vector<8x8xf32>
      %37 = vector.extract %27[4] : vector<8xi1> from vector<8x8xi1>
      vector.maskedstore %subview[%c4, %c0], %37, %36 : memref<?x?xf32, strided<[500, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>, vector<8xi1>, vector<8xf32>
      %38 = vector.extract %24[5] : vector<8xf32> from vector<8x8xf32>
      %39 = vector.extract %27[5] : vector<8xi1> from vector<8x8xi1>
      vector.maskedstore %subview[%c5, %c0], %39, %38 : memref<?x?xf32, strided<[500, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>, vector<8xi1>, vector<8xf32>
      %40 = vector.extract %24[6] : vector<8xf32> from vector<8x8xf32>
      %41 = vector.extract %27[6] : vector<8xi1> from vector<8x8xi1>
      vector.maskedstore %subview[%c6, %c0], %41, %40 : memref<?x?xf32, strided<[500, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>, vector<8xi1>, vector<8xf32>
      %42 = vector.extract %24[7] : vector<8xf32> from vector<8x8xf32>
      %43 = vector.extract %27[7] : vector<8xi1> from vector<8x8xi1>
      vector.maskedstore %subview[%c7, %c0], %43, %42 : memref<?x?xf32, strided<[500, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>, vector<8xi1>, vector<8xf32>
    }
  }
  return
}

