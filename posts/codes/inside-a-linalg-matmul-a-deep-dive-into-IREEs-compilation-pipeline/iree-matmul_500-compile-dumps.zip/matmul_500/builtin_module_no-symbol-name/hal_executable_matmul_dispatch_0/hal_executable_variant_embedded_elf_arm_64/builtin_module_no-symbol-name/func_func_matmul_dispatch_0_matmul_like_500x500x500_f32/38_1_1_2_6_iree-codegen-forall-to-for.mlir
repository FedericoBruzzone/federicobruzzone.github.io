// -----// IR Dump After ForallToForPass: iree-codegen-forall-to-for //----- //
func.func @matmul_dispatch_0_matmul_like_500x500x500_f32() attributes {translation_info = #iree_codegen.translation_info<pipeline = #iree_cpu.pipeline<Mmt4dTilingExpert>>} {
  %c1 = arith.constant 1 : index
  %c500 = arith.constant 500 : index
  %cst = arith.constant 0.000000e+00 : f32
  %c0 = arith.constant 0 : index
  %c1008000 = arith.constant 1008000 : index
  %c2016000 = arith.constant 2016000 : index
  %0 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : memref<63x500x8x1xf32, #hal.descriptor_type<storage_buffer>>
  %1 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c1008000) flags("ReadOnly|Indirect") : memref<63x500x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
  %2 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c2016000) flags("ReadOnly|Indirect") : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
  %3 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags(Indirect) : memref<500x500xf32, #hal.descriptor_type<storage_buffer>>
  %4 = iree_codegen.load_from_buffer %0 : memref<63x500x8x1xf32, #hal.descriptor_type<storage_buffer>> -> tensor<63x500x8x1xf32>
  %5 = iree_codegen.load_from_buffer %1 : memref<63x500x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>, #hal.descriptor_type<storage_buffer>> -> tensor<63x500x8x1xf32>
  %6 = iree_codegen.load_from_buffer %2 : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>, #hal.descriptor_type<storage_buffer>> -> tensor<63x63x8x8xf32>
  %7 = tensor.empty() : tensor<500x500xf32>
  %c0_0 = arith.constant 0 : index
  %c0_1 = arith.constant 0 : index
  %c63 = arith.constant 63 : index
  %c63_2 = arith.constant 63 : index
  %c1_3 = arith.constant 1 : index
  %c1_4 = arith.constant 1 : index
  %8 = scf.for %arg0 = %c0_0 to %c63 step %c1_3 iter_args(%arg1 = %7) -> (tensor<500x500xf32>) {
    %9 = scf.for %arg2 = %c0_1 to %c63_2 step %c1_4 iter_args(%arg3 = %arg1) -> (tensor<500x500xf32>) {
      %10 = tensor.empty() : tensor<1x1x8x8xf32>
      %11 = linalg.fill {lowering_config = #iree_cpu.lowering_config<vector_common_parallel = [1, 1, 8, 8]>} ins(%cst : f32) outs(%10 : tensor<1x1x8x8xf32>) -> tensor<1x1x8x8xf32>
      %12 = scf.for %arg4 = %c0 to %c500 step %c1 iter_args(%arg5 = %11) -> (tensor<1x1x8x8xf32>) {
        %extracted_slice_6 = tensor.extract_slice %4[%arg0, %arg4, 0, 0] [1, 1, 8, 1] [1, 1, 1, 1] : tensor<63x500x8x1xf32> to tensor<1x1x8x1xf32>
        %extracted_slice_7 = tensor.extract_slice %5[%arg2, %arg4, 0, 0] [1, 1, 8, 1] [1, 1, 1, 1] : tensor<63x500x8x1xf32> to tensor<1x1x8x1xf32>
        %19 = linalg.mmt4d {lowering_config = #iree_cpu.lowering_config<distribution = [0, 0, 0, 0, 0, 0], vector_common_parallel = [1, 1, 0, 8, 8, 0], vector_reduction = [0, 0, 1, 0, 0, 1]>} ins(%extracted_slice_6, %extracted_slice_7 : tensor<1x1x8x1xf32>, tensor<1x1x8x1xf32>) outs(%arg5 : tensor<1x1x8x8xf32>) -> tensor<1x1x8x8xf32>
        scf.yield %19 : tensor<1x1x8x8xf32>
      }
      %extracted_slice = tensor.extract_slice %6[%arg0, %arg2, 0, 0] [1, 1, 8, 8] [1, 1, 1, 1] : tensor<63x63x8x8xf32> to tensor<1x1x8x8xf32>
      %13 = tensor.empty() : tensor<1x1x8x8xf32>
      %14 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>, affine_map<(d0, d1, d2, d3) -> (d0, d1, d2, d3)>], iterator_types = ["parallel", "parallel", "parallel", "parallel"]} ins(%12, %extracted_slice : tensor<1x1x8x8xf32>, tensor<1x1x8x8xf32>) outs(%13 : tensor<1x1x8x8xf32>) attrs =  {lowering_config = #iree_cpu.lowering_config<vector_common_parallel = [1, 1, 8, 8]>} {
      ^bb0(%in: f32, %in_6: f32, %out: f32):
        %19 = arith.addf %in, %in_6 : f32
        linalg.yield %19 : f32
      } -> tensor<1x1x8x8xf32>
      %15 = affine.apply affine_map<(d0) -> (d0 * 8)>(%arg0)
      %16 = affine.min affine_map<(d0) -> (d0 * -8 + 500, 8)>(%arg0)
      %17 = affine.apply affine_map<(d0) -> (d0 * 8)>(%arg2)
      %18 = affine.min affine_map<(d0) -> (d0 * -8 + 500, 8)>(%arg2)
      %extracted_slice_5 = tensor.extract_slice %arg3[%15, %17] [%16, %18] [1, 1] : tensor<500x500xf32> to tensor<?x?xf32>
      %unpack = linalg.unpack %14 outer_dims_perm = [0, 1] inner_dims_pos = [0, 1] inner_tiles = [8, 8] into %extracted_slice_5 {lowering_config = #iree_cpu.lowering_config<vector_common_parallel = [8, 8]>} : tensor<1x1x8x8xf32> -> tensor<?x?xf32>
      %inserted_slice = tensor.insert_slice %unpack into %arg3[%15, %17] [%16, %18] [1, 1] : tensor<?x?xf32> into tensor<500x500xf32>
      scf.yield %inserted_slice : tensor<500x500xf32>
    }
    scf.yield %9 : tensor<500x500xf32>
  }
  iree_codegen.store_to_buffer %8, %3 : tensor<500x500xf32> into memref<500x500xf32, #hal.descriptor_type<storage_buffer>>
  return
}

