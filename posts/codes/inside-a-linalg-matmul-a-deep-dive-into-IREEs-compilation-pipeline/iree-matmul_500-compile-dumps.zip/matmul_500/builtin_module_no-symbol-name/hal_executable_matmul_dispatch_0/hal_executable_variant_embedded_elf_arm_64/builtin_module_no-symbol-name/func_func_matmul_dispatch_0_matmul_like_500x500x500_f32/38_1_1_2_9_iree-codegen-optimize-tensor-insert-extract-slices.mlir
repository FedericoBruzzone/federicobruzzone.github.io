// -----// IR Dump After OptimizeTensorInsertExtractSlicesPass: iree-codegen-optimize-tensor-insert-extract-slices{fold-identity-slices=false} //----- //
func.func @matmul_dispatch_0_matmul_like_500x500x500_f32() attributes {translation_info = #iree_codegen.translation_info<pipeline = #iree_cpu.pipeline<Mmt4dTilingExpert>>} {
  %cst = arith.constant dense<0.000000e+00> : vector<1x1x8x8xf32>
  %0 = ub.poison : f32
  %c63 = arith.constant 63 : index
  %c1 = arith.constant 1 : index
  %c500 = arith.constant 500 : index
  %c0 = arith.constant 0 : index
  %c1008000 = arith.constant 1008000 : index
  %c2016000 = arith.constant 2016000 : index
  %1 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : memref<63x500x8x1xf32, #hal.descriptor_type<storage_buffer>>
  %2 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c1008000) flags("ReadOnly|Indirect") : memref<63x500x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
  %3 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c2016000) flags("ReadOnly|Indirect") : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>, #hal.descriptor_type<storage_buffer>>
  %4 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags(Indirect) : memref<500x500xf32, #hal.descriptor_type<storage_buffer>>
  %5 = iree_codegen.load_from_buffer %1 : memref<63x500x8x1xf32, #hal.descriptor_type<storage_buffer>> -> tensor<63x500x8x1xf32>
  %6 = iree_codegen.load_from_buffer %2 : memref<63x500x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>, #hal.descriptor_type<storage_buffer>> -> tensor<63x500x8x1xf32>
  %7 = iree_codegen.load_from_buffer %3 : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>, #hal.descriptor_type<storage_buffer>> -> tensor<63x63x8x8xf32>
  %8 = tensor.empty() : tensor<500x500xf32>
  %9 = scf.for %arg0 = %c0 to %c63 step %c1 iter_args(%arg1 = %8) -> (tensor<500x500xf32>) {
    %10 = affine.apply affine_map<(d0) -> (d0 * 8)>(%arg0)
    %11 = affine.min affine_map<(d0) -> (d0 * -8 + 500, 8)>(%arg0)
    %12 = scf.for %arg2 = %c0 to %c63 step %c1 iter_args(%arg3 = %arg1) -> (tensor<500x500xf32>) {
      %13 = scf.for %arg4 = %c0 to %c500 step %c1 iter_args(%arg5 = %cst) -> (vector<1x1x8x8xf32>) {
        %21 = vector.transfer_read %5[%arg0, %arg4, %c0, %c0], %0 {in_bounds = [true, true, true, true]} : tensor<63x500x8x1xf32>, vector<1x1x8x1xf32>
        %22 = vector.transfer_read %6[%arg2, %arg4, %c0, %c0], %0 {in_bounds = [true, true, true, true]} : tensor<63x500x8x1xf32>, vector<1x1x8x1xf32>
        %23 = vector.contract {indexing_maps = [affine_map<(d0, d1, d2, d3, d4, d5) -> (d0, d2, d3, d5)>, affine_map<(d0, d1, d2, d3, d4, d5) -> (d1, d2, d4, d5)>, affine_map<(d0, d1, d2, d3, d4, d5) -> (d0, d1, d3, d4)>], iterator_types = ["parallel", "parallel", "reduction", "parallel", "parallel", "reduction"], kind = #vector.kind<add>} %21, %22, %arg5 : vector<1x1x8x1xf32>, vector<1x1x8x1xf32> into vector<1x1x8x8xf32>
        scf.yield %23 : vector<1x1x8x8xf32>
      }
      %14 = vector.transfer_read %7[%arg0, %arg2, %c0, %c0], %0 {in_bounds = [true, true, true, true]} : tensor<63x63x8x8xf32>, vector<1x1x8x8xf32>
      %15 = arith.addf %13, %14 : vector<1x1x8x8xf32>
      %16 = affine.apply affine_map<(d0) -> (d0 * 8)>(%arg2)
      %17 = affine.min affine_map<(d0) -> (d0 * -8 + 500, 8)>(%arg2)
      %extracted_slice = tensor.extract_slice %arg3[%10, %16] [%11, %17] [1, 1] : tensor<500x500xf32> to tensor<?x?xf32>
      %18 = vector.shape_cast %15 : vector<1x1x8x8xf32> to vector<8x8xf32>
      %19 = vector.create_mask %11, %17 : vector<8x8xi1>
      %20 = vector.transfer_write %18, %extracted_slice[%c0, %c0], %19 {in_bounds = [true, true]} : vector<8x8xf32>, tensor<?x?xf32>
      %inserted_slice = tensor.insert_slice %20 into %arg3[%10, %16] [%11, %17] [1, 1] : tensor<?x?xf32> into tensor<500x500xf32>
      scf.yield %inserted_slice : tensor<500x500xf32>
    }
    scf.yield %12 : tensor<500x500xf32>
  }
  iree_codegen.store_to_buffer %9, %4 : tensor<500x500xf32> into memref<500x500xf32, #hal.descriptor_type<storage_buffer>>
  return
}

