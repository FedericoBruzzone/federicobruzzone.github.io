// -----// IR Dump After FoldMemRefAliasOpsPass: fold-memref-alias-ops //----- //
func.func @matmul_dispatch_0_matmul_like_500x500x500_f32() {
  %c-8 = arith.constant -8 : index
  %c8 = arith.constant 8 : index
  %c7 = arith.constant 7 : index
  %c6 = arith.constant 6 : index
  %c5 = arith.constant 5 : index
  %c4 = arith.constant 4 : index
  %c3 = arith.constant 3 : index
  %c2 = arith.constant 2 : index
  %cst = arith.constant dense<0.000000e+00> : vector<8x8xf32>
  %c63 = arith.constant 63 : index
  %c1 = arith.constant 1 : index
  %c500 = arith.constant 500 : index
  %c0 = arith.constant 0 : index
  %c1008000 = arith.constant 1008000 : index
  %c2016000 = arith.constant 2016000 : index
  %0 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : memref<63x500x8x1xf32>
  %assume_align = memref.assume_alignment %0, 64 : memref<63x500x8x1xf32>
  %1 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c1008000) flags("ReadOnly|Indirect") : memref<63x500x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>>
  %assume_align_0 = memref.assume_alignment %1, 64 : memref<63x500x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>>
  %2 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c2016000) flags("ReadOnly|Indirect") : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>
  %assume_align_1 = memref.assume_alignment %2, 64 : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>
  %3 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags(Indirect) : memref<500x500xf32>
  %assume_align_2 = memref.assume_alignment %3, 64 : memref<500x500xf32>
  scf.for %arg0 = %c0 to %c63 step %c1 {
    %4 = arith.muli %arg0, %c8 overflow<nsw> : index
    %5 = arith.muli %arg0, %c-8 overflow<nsw> : index
    %6 = arith.addi %5, %c500 : index
    %7 = arith.minsi %6, %c8 : index
    scf.for %arg1 = %c0 to %c63 step %c1 {
      %8 = scf.for %arg2 = %c0 to %c500 step %c1 iter_args(%arg3 = %cst) -> (vector<8x8xf32>) {
        %55 = vector.load %assume_align[%arg0, %arg2, %c0, %c0] : memref<63x500x8x1xf32>, vector<8xf32>
        %56 = vector.load %assume_align_0[%arg1, %arg2, %c0, %c0] : memref<63x500x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>>, vector<8xf32>
        %57 = vector.extract %55[0] : f32 from vector<8xf32>
        %58 = vector.broadcast %57 : f32 to vector<8xf32>
        %59 = vector.extract %arg3[0] : vector<8xf32> from vector<8x8xf32>
        %60 = vector.fma %58, %56, %59 : vector<8xf32>
        %61 = vector.extract %55[1] : f32 from vector<8xf32>
        %62 = vector.broadcast %61 : f32 to vector<8xf32>
        %63 = vector.extract %arg3[1] : vector<8xf32> from vector<8x8xf32>
        %64 = vector.fma %62, %56, %63 : vector<8xf32>
        %65 = vector.extract %55[2] : f32 from vector<8xf32>
        %66 = vector.broadcast %65 : f32 to vector<8xf32>
        %67 = vector.extract %arg3[2] : vector<8xf32> from vector<8x8xf32>
        %68 = vector.fma %66, %56, %67 : vector<8xf32>
        %69 = vector.extract %55[3] : f32 from vector<8xf32>
        %70 = vector.broadcast %69 : f32 to vector<8xf32>
        %71 = vector.extract %arg3[3] : vector<8xf32> from vector<8x8xf32>
        %72 = vector.fma %70, %56, %71 : vector<8xf32>
        %73 = vector.extract %55[4] : f32 from vector<8xf32>
        %74 = vector.broadcast %73 : f32 to vector<8xf32>
        %75 = vector.extract %arg3[4] : vector<8xf32> from vector<8x8xf32>
        %76 = vector.fma %74, %56, %75 : vector<8xf32>
        %77 = vector.extract %55[5] : f32 from vector<8xf32>
        %78 = vector.broadcast %77 : f32 to vector<8xf32>
        %79 = vector.extract %arg3[5] : vector<8xf32> from vector<8x8xf32>
        %80 = vector.fma %78, %56, %79 : vector<8xf32>
        %81 = vector.extract %55[6] : f32 from vector<8xf32>
        %82 = vector.broadcast %81 : f32 to vector<8xf32>
        %83 = vector.extract %arg3[6] : vector<8xf32> from vector<8x8xf32>
        %84 = vector.fma %82, %56, %83 : vector<8xf32>
        %85 = vector.extract %55[7] : f32 from vector<8xf32>
        %86 = vector.broadcast %85 : f32 to vector<8xf32>
        %87 = vector.extract %arg3[7] : vector<8xf32> from vector<8x8xf32>
        %88 = vector.fma %86, %56, %87 : vector<8xf32>
        %89:8 = vector.to_elements %60 : vector<8xf32>
        %90:8 = vector.to_elements %64 : vector<8xf32>
        %91:8 = vector.to_elements %68 : vector<8xf32>
        %92:8 = vector.to_elements %72 : vector<8xf32>
        %93:8 = vector.to_elements %76 : vector<8xf32>
        %94:8 = vector.to_elements %80 : vector<8xf32>
        %95:8 = vector.to_elements %84 : vector<8xf32>
        %96:8 = vector.to_elements %88 : vector<8xf32>
        %97 = vector.from_elements %89#0, %89#1, %89#2, %89#3, %89#4, %89#5, %89#6, %89#7, %90#0, %90#1, %90#2, %90#3, %90#4, %90#5, %90#6, %90#7, %91#0, %91#1, %91#2, %91#3, %91#4, %91#5, %91#6, %91#7, %92#0, %92#1, %92#2, %92#3, %92#4, %92#5, %92#6, %92#7, %93#0, %93#1, %93#2, %93#3, %93#4, %93#5, %93#6, %93#7, %94#0, %94#1, %94#2, %94#3, %94#4, %94#5, %94#6, %94#7, %95#0, %95#1, %95#2, %95#3, %95#4, %95#5, %95#6, %95#7, %96#0, %96#1, %96#2, %96#3, %96#4, %96#5, %96#6, %96#7 : vector<8x8xf32>
        scf.yield %97 : vector<8x8xf32>
      }
      %9 = vector.load %assume_align_1[%arg0, %arg1, %c0, %c0] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>, vector<8xf32>
      %10 = vector.load %assume_align_1[%arg0, %arg1, %c1, %c0] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>, vector<8xf32>
      %11 = vector.load %assume_align_1[%arg0, %arg1, %c2, %c0] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>, vector<8xf32>
      %12 = vector.load %assume_align_1[%arg0, %arg1, %c3, %c0] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>, vector<8xf32>
      %13 = vector.load %assume_align_1[%arg0, %arg1, %c4, %c0] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>, vector<8xf32>
      %14 = vector.load %assume_align_1[%arg0, %arg1, %c5, %c0] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>, vector<8xf32>
      %15 = vector.load %assume_align_1[%arg0, %arg1, %c6, %c0] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>, vector<8xf32>
      %16 = vector.load %assume_align_1[%arg0, %arg1, %c7, %c0] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>, vector<8xf32>
      %17:8 = vector.to_elements %9 : vector<8xf32>
      %18:8 = vector.to_elements %10 : vector<8xf32>
      %19:8 = vector.to_elements %11 : vector<8xf32>
      %20:8 = vector.to_elements %12 : vector<8xf32>
      %21:8 = vector.to_elements %13 : vector<8xf32>
      %22:8 = vector.to_elements %14 : vector<8xf32>
      %23:8 = vector.to_elements %15 : vector<8xf32>
      %24:8 = vector.to_elements %16 : vector<8xf32>
      %25 = vector.from_elements %17#0, %17#1, %17#2, %17#3, %17#4, %17#5, %17#6, %17#7, %18#0, %18#1, %18#2, %18#3, %18#4, %18#5, %18#6, %18#7, %19#0, %19#1, %19#2, %19#3, %19#4, %19#5, %19#6, %19#7, %20#0, %20#1, %20#2, %20#3, %20#4, %20#5, %20#6, %20#7, %21#0, %21#1, %21#2, %21#3, %21#4, %21#5, %21#6, %21#7, %22#0, %22#1, %22#2, %22#3, %22#4, %22#5, %22#6, %22#7, %23#0, %23#1, %23#2, %23#3, %23#4, %23#5, %23#6, %23#7, %24#0, %24#1, %24#2, %24#3, %24#4, %24#5, %24#6, %24#7 : vector<8x8xf32>
      %26 = arith.addf %8, %25 : vector<8x8xf32>
      %27 = arith.muli %arg1, %c8 overflow<nsw> : index
      %28 = arith.muli %arg1, %c-8 overflow<nsw> : index
      %29 = arith.addi %28, %c500 : index
      %30 = arith.minsi %29, %c8 : index
      %31 = vector.create_mask %7, %30 : vector<8x8xi1>
      %32 = vector.extract %26[0] : vector<8xf32> from vector<8x8xf32>
      %33 = vector.extract %31[0] : vector<8xi1> from vector<8x8xi1>
      vector.maskedstore %assume_align_2[%4, %27], %33, %32 : memref<500x500xf32>, vector<8xi1>, vector<8xf32>
      %34 = vector.extract %26[1] : vector<8xf32> from vector<8x8xf32>
      %35 = vector.extract %31[1] : vector<8xi1> from vector<8x8xi1>
      %36 = affine.apply affine_map<()[s0] -> (s0 + 1)>()[%4]
      vector.maskedstore %assume_align_2[%36, %27], %35, %34 : memref<500x500xf32>, vector<8xi1>, vector<8xf32>
      %37 = vector.extract %26[2] : vector<8xf32> from vector<8x8xf32>
      %38 = vector.extract %31[2] : vector<8xi1> from vector<8x8xi1>
      %39 = affine.apply affine_map<()[s0] -> (s0 + 2)>()[%4]
      vector.maskedstore %assume_align_2[%39, %27], %38, %37 : memref<500x500xf32>, vector<8xi1>, vector<8xf32>
      %40 = vector.extract %26[3] : vector<8xf32> from vector<8x8xf32>
      %41 = vector.extract %31[3] : vector<8xi1> from vector<8x8xi1>
      %42 = affine.apply affine_map<()[s0] -> (s0 + 3)>()[%4]
      vector.maskedstore %assume_align_2[%42, %27], %41, %40 : memref<500x500xf32>, vector<8xi1>, vector<8xf32>
      %43 = vector.extract %26[4] : vector<8xf32> from vector<8x8xf32>
      %44 = vector.extract %31[4] : vector<8xi1> from vector<8x8xi1>
      %45 = affine.apply affine_map<()[s0] -> (s0 + 4)>()[%4]
      vector.maskedstore %assume_align_2[%45, %27], %44, %43 : memref<500x500xf32>, vector<8xi1>, vector<8xf32>
      %46 = vector.extract %26[5] : vector<8xf32> from vector<8x8xf32>
      %47 = vector.extract %31[5] : vector<8xi1> from vector<8x8xi1>
      %48 = affine.apply affine_map<()[s0] -> (s0 + 5)>()[%4]
      vector.maskedstore %assume_align_2[%48, %27], %47, %46 : memref<500x500xf32>, vector<8xi1>, vector<8xf32>
      %49 = vector.extract %26[6] : vector<8xf32> from vector<8x8xf32>
      %50 = vector.extract %31[6] : vector<8xi1> from vector<8x8xi1>
      %51 = affine.apply affine_map<()[s0] -> (s0 + 6)>()[%4]
      vector.maskedstore %assume_align_2[%51, %27], %50, %49 : memref<500x500xf32>, vector<8xi1>, vector<8xf32>
      %52 = vector.extract %26[7] : vector<8xf32> from vector<8x8xf32>
      %53 = vector.extract %31[7] : vector<8xi1> from vector<8x8xi1>
      %54 = affine.apply affine_map<()[s0] -> (s0 + 7)>()[%4]
      vector.maskedstore %assume_align_2[%54, %27], %53, %52 : memref<500x500xf32>, vector<8xi1>, vector<8xf32>
    }
  }
  return
}

