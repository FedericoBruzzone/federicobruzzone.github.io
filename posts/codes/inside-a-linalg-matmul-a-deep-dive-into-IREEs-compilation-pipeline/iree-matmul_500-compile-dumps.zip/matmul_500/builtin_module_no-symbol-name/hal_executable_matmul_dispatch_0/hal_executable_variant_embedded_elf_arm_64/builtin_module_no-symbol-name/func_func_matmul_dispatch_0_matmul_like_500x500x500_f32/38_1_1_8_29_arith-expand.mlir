// -----// IR Dump After ArithExpandOpsPass: arith-expand{include-bf16=true include-f4e2m1=false include-f8e8m0=true include-flush-denormals=false} //----- //
func.func @matmul_dispatch_0_matmul_like_500x500x500_f32() {
  %c-8 = arith.constant -8 : index
  %c8 = arith.constant 8 : index
  %c7 = arith.constant 7 : index
  %c6 = arith.constant 6 : index
  %c5 = arith.constant 5 : index
  %c4 = arith.constant 4 : index
  %c3 = arith.constant 3 : index
  %c2 = arith.constant 2 : index
  %cst = arith.constant dense<0.000000e+00> : vector<8x8xf32>
  %c63 = arith.constant 63 : index
  %c1 = arith.constant 1 : index
  %c500 = arith.constant 500 : index
  %c0 = arith.constant 0 : index
  %c1008000 = arith.constant 1008000 : index
  %c2016000 = arith.constant 2016000 : index
  %0 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c0) flags("ReadOnly|Indirect") : memref<63x500x8x1xf32>
  %assume_align = memref.assume_alignment %0, 64 : memref<63x500x8x1xf32>
  %1 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c1008000) flags("ReadOnly|Indirect") : memref<63x500x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>>
  %assume_align_0 = memref.assume_alignment %1, 64 : memref<63x500x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>>
  %2 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(0) alignment(64) offset(%c2016000) flags("ReadOnly|Indirect") : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>
  %assume_align_1 = memref.assume_alignment %2, 64 : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>
  %3 = hal.interface.binding.subspan layout(<bindings = [#hal.pipeline.binding<storage_buffer, "ReadOnly|Indirect">, #hal.pipeline.binding<storage_buffer, Indirect>], flags = Indirect>) binding(1) alignment(64) offset(%c0) flags(Indirect) : memref<500x500xf32>
  %assume_align_2 = memref.assume_alignment %3, 64 : memref<500x500xf32>
  cf.br ^bb1(%c0 : index)
^bb1(%4: index):  // 2 preds: ^bb0, ^bb7
  %5 = arith.cmpi slt, %4, %c63 : index
  cf.cond_br %5, ^bb2, ^bb8
^bb2:  // pred: ^bb1
  %6 = arith.muli %4, %c8 overflow<nsw> : index
  %7 = arith.muli %4, %c-8 overflow<nsw> : index
  %8 = arith.addi %7, %c500 : index
  %9 = arith.cmpi slt, %8, %c8 : index
  %10 = arith.select %9, %8, %c8 : index
  cf.br ^bb3(%c0 : index)
^bb3(%11: index):  // 2 preds: ^bb2, ^bb6
  %12 = arith.cmpi slt, %11, %c63 : index
  cf.cond_br %12, ^bb4(%c0, %cst : index, vector<8x8xf32>), ^bb7
^bb4(%13: index, %14: vector<8x8xf32>):  // 2 preds: ^bb3, ^bb5
  %15 = arith.cmpi slt, %13, %c500 : index
  cf.cond_br %15, ^bb5, ^bb6
^bb5:  // pred: ^bb4
  %16 = vector.load %assume_align[%4, %13, %c0, %c0] : memref<63x500x8x1xf32>, vector<8xf32>
  %17 = vector.load %assume_align_0[%11, %13, %c0, %c0] : memref<63x500x8x1xf32, strided<[4000, 8, 1, 1], offset: ?>>, vector<8xf32>
  %18 = vector.extract %16[0] : f32 from vector<8xf32>
  %19 = vector.broadcast %18 : f32 to vector<8xf32>
  %20 = vector.extract %14[0] : vector<8xf32> from vector<8x8xf32>
  %21 = vector.fma %19, %17, %20 : vector<8xf32>
  %22 = vector.extract %16[1] : f32 from vector<8xf32>
  %23 = vector.broadcast %22 : f32 to vector<8xf32>
  %24 = vector.extract %14[1] : vector<8xf32> from vector<8x8xf32>
  %25 = vector.fma %23, %17, %24 : vector<8xf32>
  %26 = vector.extract %16[2] : f32 from vector<8xf32>
  %27 = vector.broadcast %26 : f32 to vector<8xf32>
  %28 = vector.extract %14[2] : vector<8xf32> from vector<8x8xf32>
  %29 = vector.fma %27, %17, %28 : vector<8xf32>
  %30 = vector.extract %16[3] : f32 from vector<8xf32>
  %31 = vector.broadcast %30 : f32 to vector<8xf32>
  %32 = vector.extract %14[3] : vector<8xf32> from vector<8x8xf32>
  %33 = vector.fma %31, %17, %32 : vector<8xf32>
  %34 = vector.extract %16[4] : f32 from vector<8xf32>
  %35 = vector.broadcast %34 : f32 to vector<8xf32>
  %36 = vector.extract %14[4] : vector<8xf32> from vector<8x8xf32>
  %37 = vector.fma %35, %17, %36 : vector<8xf32>
  %38 = vector.extract %16[5] : f32 from vector<8xf32>
  %39 = vector.broadcast %38 : f32 to vector<8xf32>
  %40 = vector.extract %14[5] : vector<8xf32> from vector<8x8xf32>
  %41 = vector.fma %39, %17, %40 : vector<8xf32>
  %42 = vector.extract %16[6] : f32 from vector<8xf32>
  %43 = vector.broadcast %42 : f32 to vector<8xf32>
  %44 = vector.extract %14[6] : vector<8xf32> from vector<8x8xf32>
  %45 = vector.fma %43, %17, %44 : vector<8xf32>
  %46 = vector.extract %16[7] : f32 from vector<8xf32>
  %47 = vector.broadcast %46 : f32 to vector<8xf32>
  %48 = vector.extract %14[7] : vector<8xf32> from vector<8x8xf32>
  %49 = vector.fma %47, %17, %48 : vector<8xf32>
  %50:8 = vector.to_elements %21 : vector<8xf32>
  %51:8 = vector.to_elements %25 : vector<8xf32>
  %52:8 = vector.to_elements %29 : vector<8xf32>
  %53:8 = vector.to_elements %33 : vector<8xf32>
  %54:8 = vector.to_elements %37 : vector<8xf32>
  %55:8 = vector.to_elements %41 : vector<8xf32>
  %56:8 = vector.to_elements %45 : vector<8xf32>
  %57:8 = vector.to_elements %49 : vector<8xf32>
  %58 = vector.from_elements %50#0, %50#1, %50#2, %50#3, %50#4, %50#5, %50#6, %50#7, %51#0, %51#1, %51#2, %51#3, %51#4, %51#5, %51#6, %51#7, %52#0, %52#1, %52#2, %52#3, %52#4, %52#5, %52#6, %52#7, %53#0, %53#1, %53#2, %53#3, %53#4, %53#5, %53#6, %53#7, %54#0, %54#1, %54#2, %54#3, %54#4, %54#5, %54#6, %54#7, %55#0, %55#1, %55#2, %55#3, %55#4, %55#5, %55#6, %55#7, %56#0, %56#1, %56#2, %56#3, %56#4, %56#5, %56#6, %56#7, %57#0, %57#1, %57#2, %57#3, %57#4, %57#5, %57#6, %57#7 : vector<8x8xf32>
  %59 = arith.addi %13, %c1 : index
  cf.br ^bb4(%59, %58 : index, vector<8x8xf32>)
^bb6:  // pred: ^bb4
  %60 = vector.load %assume_align_1[%4, %11, %c0, %c0] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>, vector<8xf32>
  %61 = vector.load %assume_align_1[%4, %11, %c1, %c0] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>, vector<8xf32>
  %62 = vector.load %assume_align_1[%4, %11, %c2, %c0] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>, vector<8xf32>
  %63 = vector.load %assume_align_1[%4, %11, %c3, %c0] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>, vector<8xf32>
  %64 = vector.load %assume_align_1[%4, %11, %c4, %c0] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>, vector<8xf32>
  %65 = vector.load %assume_align_1[%4, %11, %c5, %c0] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>, vector<8xf32>
  %66 = vector.load %assume_align_1[%4, %11, %c6, %c0] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>, vector<8xf32>
  %67 = vector.load %assume_align_1[%4, %11, %c7, %c0] : memref<63x63x8x8xf32, strided<[4032, 64, 8, 1], offset: ?>>, vector<8xf32>
  %68:8 = vector.to_elements %60 : vector<8xf32>
  %69:8 = vector.to_elements %61 : vector<8xf32>
  %70:8 = vector.to_elements %62 : vector<8xf32>
  %71:8 = vector.to_elements %63 : vector<8xf32>
  %72:8 = vector.to_elements %64 : vector<8xf32>
  %73:8 = vector.to_elements %65 : vector<8xf32>
  %74:8 = vector.to_elements %66 : vector<8xf32>
  %75:8 = vector.to_elements %67 : vector<8xf32>
  %76 = vector.from_elements %68#0, %68#1, %68#2, %68#3, %68#4, %68#5, %68#6, %68#7, %69#0, %69#1, %69#2, %69#3, %69#4, %69#5, %69#6, %69#7, %70#0, %70#1, %70#2, %70#3, %70#4, %70#5, %70#6, %70#7, %71#0, %71#1, %71#2, %71#3, %71#4, %71#5, %71#6, %71#7, %72#0, %72#1, %72#2, %72#3, %72#4, %72#5, %72#6, %72#7, %73#0, %73#1, %73#2, %73#3, %73#4, %73#5, %73#6, %73#7, %74#0, %74#1, %74#2, %74#3, %74#4, %74#5, %74#6, %74#7, %75#0, %75#1, %75#2, %75#3, %75#4, %75#5, %75#6, %75#7 : vector<8x8xf32>
  %77 = arith.addf %14, %76 : vector<8x8xf32>
  %78 = arith.muli %11, %c8 overflow<nsw> : index
  %79 = arith.muli %11, %c-8 overflow<nsw> : index
  %80 = arith.addi %79, %c500 : index
  %81 = arith.cmpi slt, %80, %c8 : index
  %82 = arith.select %81, %80, %c8 : index
  %83 = vector.create_mask %10, %82 : vector<8x8xi1>
  %84 = vector.extract %77[0] : vector<8xf32> from vector<8x8xf32>
  %85 = vector.extract %83[0] : vector<8xi1> from vector<8x8xi1>
  vector.maskedstore %assume_align_2[%6, %78], %85, %84 : memref<500x500xf32>, vector<8xi1>, vector<8xf32>
  %86 = vector.extract %77[1] : vector<8xf32> from vector<8x8xf32>
  %87 = vector.extract %83[1] : vector<8xi1> from vector<8x8xi1>
  %88 = affine.apply affine_map<()[s0] -> (s0 + 1)>()[%6]
  vector.maskedstore %assume_align_2[%88, %78], %87, %86 : memref<500x500xf32>, vector<8xi1>, vector<8xf32>
  %89 = vector.extract %77[2] : vector<8xf32> from vector<8x8xf32>
  %90 = vector.extract %83[2] : vector<8xi1> from vector<8x8xi1>
  %91 = affine.apply affine_map<()[s0] -> (s0 + 2)>()[%6]
  vector.maskedstore %assume_align_2[%91, %78], %90, %89 : memref<500x500xf32>, vector<8xi1>, vector<8xf32>
  %92 = vector.extract %77[3] : vector<8xf32> from vector<8x8xf32>
  %93 = vector.extract %83[3] : vector<8xi1> from vector<8x8xi1>
  %94 = affine.apply affine_map<()[s0] -> (s0 + 3)>()[%6]
  vector.maskedstore %assume_align_2[%94, %78], %93, %92 : memref<500x500xf32>, vector<8xi1>, vector<8xf32>
  %95 = vector.extract %77[4] : vector<8xf32> from vector<8x8xf32>
  %96 = vector.extract %83[4] : vector<8xi1> from vector<8x8xi1>
  %97 = affine.apply affine_map<()[s0] -> (s0 + 4)>()[%6]
  vector.maskedstore %assume_align_2[%97, %78], %96, %95 : memref<500x500xf32>, vector<8xi1>, vector<8xf32>
  %98 = vector.extract %77[5] : vector<8xf32> from vector<8x8xf32>
  %99 = vector.extract %83[5] : vector<8xi1> from vector<8x8xi1>
  %100 = affine.apply affine_map<()[s0] -> (s0 + 5)>()[%6]
  vector.maskedstore %assume_align_2[%100, %78], %99, %98 : memref<500x500xf32>, vector<8xi1>, vector<8xf32>
  %101 = vector.extract %77[6] : vector<8xf32> from vector<8x8xf32>
  %102 = vector.extract %83[6] : vector<8xi1> from vector<8x8xi1>
  %103 = affine.apply affine_map<()[s0] -> (s0 + 6)>()[%6]
  vector.maskedstore %assume_align_2[%103, %78], %102, %101 : memref<500x500xf32>, vector<8xi1>, vector<8xf32>
  %104 = vector.extract %77[7] : vector<8xf32> from vector<8x8xf32>
  %105 = vector.extract %83[7] : vector<8xi1> from vector<8x8xi1>
  %106 = affine.apply affine_map<()[s0] -> (s0 + 7)>()[%6]
  vector.maskedstore %assume_align_2[%106, %78], %105, %104 : memref<500x500xf32>, vector<8xi1>, vector<8xf32>
  %107 = arith.addi %11, %c1 : index
  cf.br ^bb3(%107 : index)
^bb7:  // pred: ^bb3
  %108 = arith.addi %4, %c1 : index
  cf.br ^bb1(%108 : index)
^bb8:  // pred: ^bb1
  return
}

