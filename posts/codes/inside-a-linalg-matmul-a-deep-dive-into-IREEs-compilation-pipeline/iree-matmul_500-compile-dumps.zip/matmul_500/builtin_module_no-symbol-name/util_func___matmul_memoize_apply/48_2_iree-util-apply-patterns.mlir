// -----// IR Dump After ApplyPatternsPass: iree-util-apply-patterns //----- //
util.func private @__matmul_memoize_apply(%arg0: !hal.device, %arg1: i64) -> !hal.command_buffer attributes {inlining_policy = #util.inline.never} {
  %c3 = arith.constant 3 : index
  %c2 = arith.constant 2 : index
  %c1 = arith.constant 1 : index
  %c3032064 = arith.constant 3032064 : index
  %c1000000 = arith.constant 1000000 : index
  %c4 = arith.constant 4 : index
  %c0 = arith.constant 0 : index
  %c5 = arith.constant 5 : index
  %__device_0_executable_0_matmul_500_linked = util.global.load @__device_0_executable_0_matmul_500_linked : !hal.executable
  %cmd = hal.command_buffer.create device(%arg0 : !hal.device) mode("None") categories("Transfer|Dispatch") affinity(%arg1) bindings(%c5) : !hal.command_buffer
  %function_id = hal.executable.lookup.function target(%__device_0_executable_0_matmul_500_linked : !hal.executable) function(@matmul_500_linked::@embedded_elf_arm_64::@_encoding_0_encode_500x500xf32_to_500x500xf32) : i64
  hal.command_buffer.dispatch<%cmd : !hal.command_buffer> target(%__device_0_executable_0_matmul_500_linked : !hal.executable)[%function_id] workgroups([%c1, %c1, %c1]) bindings([
    (%c0 : index)[%c0, %c1000000], 
    (%c4 : index)[%c0, %c3032064]
  ]) flags("None")
  %function_id_0 = hal.executable.lookup.function target(%__device_0_executable_0_matmul_500_linked : !hal.executable) function(@matmul_500_linked::@embedded_elf_arm_64::@_encoding_1_encode_500x500xf32_to_500x500xf32) : i64
  hal.command_buffer.dispatch<%cmd : !hal.command_buffer> target(%__device_0_executable_0_matmul_500_linked : !hal.executable)[%function_id_0] workgroups([%c1, %c1, %c1]) bindings([
    (%c1 : index)[%c0, %c1000000], 
    (%c4 : index)[%c0, %c3032064]
  ]) flags("None")
  %function_id_1 = hal.executable.lookup.function target(%__device_0_executable_0_matmul_500_linked : !hal.executable) function(@matmul_500_linked::@embedded_elf_arm_64::@_encoding_2_encode_500x500xf32_to_500x500xf32) : i64
  hal.command_buffer.dispatch<%cmd : !hal.command_buffer> target(%__device_0_executable_0_matmul_500_linked : !hal.executable)[%function_id_1] workgroups([%c1, %c1, %c1]) bindings([
    (%c2 : index)[%c0, %c1000000], 
    (%c4 : index)[%c0, %c3032064]
  ]) flags("None")
  hal.command_buffer.execution_barrier<%cmd : !hal.command_buffer> source("Dispatch|Transfer|CommandRetire") target("CommandIssue|Dispatch|Transfer") flags("None")
  %function_id_2 = hal.executable.lookup.function target(%__device_0_executable_0_matmul_500_linked : !hal.executable) function(@matmul_500_linked::@embedded_elf_arm_64::@matmul_dispatch_0_matmul_like_500x500x500_f32) : i64
  hal.command_buffer.dispatch<%cmd : !hal.command_buffer> target(%__device_0_executable_0_matmul_500_linked : !hal.executable)[%function_id_2] workgroups([%c1, %c1, %c1]) bindings([
    (%c4 : index)[%c0, %c3032064], 
    (%c3 : index)[%c0, %c1000000]
  ]) flags("None")
  hal.command_buffer.execution_barrier<%cmd : !hal.command_buffer> source("Dispatch|Transfer|CommandRetire") target("CommandIssue|Dispatch|Transfer") flags("None")
  hal.command_buffer.finalize<%cmd : !hal.command_buffer>
  util.return %cmd : !hal.command_buffer
}

