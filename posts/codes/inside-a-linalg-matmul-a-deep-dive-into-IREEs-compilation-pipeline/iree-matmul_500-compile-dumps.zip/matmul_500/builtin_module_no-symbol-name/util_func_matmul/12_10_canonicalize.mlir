// -----// IR Dump After CanonicalizerPass: canonicalize{cse-between-iterations=false    max-iterations=10 max-num-rewrites=-1 region-simplify=normal test-convergence=false top-down=true} //----- //
util.func public @matmul(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "sync func @matmul(%input0: tensor<500x500xf32>, %input1: tensor<500x500xf32>, %input2: tensor<500x500xf32>) -> (%output0: tensor<500x500xf32>)"}} {
  %c500 = arith.constant 500 : index
  %element_type_f32 = hal.element_type<f32> : i32
  %dense_row_major = hal.encoding_type<dense_row_major> : i32
  hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%c500, %c500]) type(%element_type_f32) encoding(%dense_row_major)
  %0 = stream.tensor.sizeof on(#hal.device.affinity<@__device_0>) tensor<500x500xf32> : index
  %1 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<500x500xf32> in !stream.resource<external>{%0}
  %2 = stream.async.cast on(#hal.device.affinity<@__device_0>) %1 : !stream.resource<external>{%0} -> !stream.resource<*>{%0}
  %element_type_f32_0 = hal.element_type<f32> : i32
  %dense_row_major_1 = hal.encoding_type<dense_row_major> : i32
  hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%c500, %c500]) type(%element_type_f32_0) encoding(%dense_row_major_1)
  %3 = stream.tensor.sizeof on(#hal.device.affinity<@__device_0>) tensor<500x500xf32> : index
  %4 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<500x500xf32> in !stream.resource<external>{%3}
  %5 = stream.async.cast on(#hal.device.affinity<@__device_0>) %4 : !stream.resource<external>{%3} -> !stream.resource<*>{%3}
  %element_type_f32_2 = hal.element_type<f32> : i32
  %dense_row_major_3 = hal.encoding_type<dense_row_major> : i32
  hal.buffer_view.assert<%arg2 : !hal.buffer_view> message("input2") shape([%c500, %c500]) type(%element_type_f32_2) encoding(%dense_row_major_3)
  %6 = stream.tensor.sizeof on(#hal.device.affinity<@__device_0>) tensor<500x500xf32> : index
  %7 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg2 : !hal.buffer_view -> tensor<500x500xf32> in !stream.resource<external>{%6}
  %8 = stream.async.cast on(#hal.device.affinity<@__device_0>) %7 : !stream.resource<external>{%6} -> !stream.resource<*>{%6}
  %9 = stream.tensor.sizeof on(#hal.device.affinity<@__device_0>) tensor<500x500xf32, #iree_encoding.encoding<operand_index = 0 : index, op_type = matmul, element_types = [f32, f32, f32], user_indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d2)>, affine_map<(d0, d1, d2) -> (d2, d1)>, affine_map<(d0, d1, d2) -> (d0, d1)>], iteration_sizes = [500, 500, 500]>> : index
  %10 = stream.tensor.encode on(#hal.device.affinity<@__device_0>) %2 : tensor<500x500xf32> in !stream.resource<*>{%0} -> tensor<500x500xf32, #iree_encoding.encoding<operand_index = 0 : index, op_type = matmul, element_types = [f32, f32, f32], user_indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d2)>, affine_map<(d0, d1, d2) -> (d2, d1)>, affine_map<(d0, d1, d2) -> (d0, d1)>], iteration_sizes = [500, 500, 500]>> in !stream.resource<*>{%9}
  %11 = stream.tensor.sizeof on(#hal.device.affinity<@__device_0>) tensor<500x500xf32, #iree_encoding.encoding<operand_index = 1 : index, op_type = matmul, element_types = [f32, f32, f32], user_indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d2)>, affine_map<(d0, d1, d2) -> (d2, d1)>, affine_map<(d0, d1, d2) -> (d0, d1)>], iteration_sizes = [500, 500, 500]>> : index
  %12 = stream.tensor.encode on(#hal.device.affinity<@__device_0>) %5 : tensor<500x500xf32> in !stream.resource<*>{%3} -> tensor<500x500xf32, #iree_encoding.encoding<operand_index = 1 : index, op_type = matmul, element_types = [f32, f32, f32], user_indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d2)>, affine_map<(d0, d1, d2) -> (d2, d1)>, affine_map<(d0, d1, d2) -> (d0, d1)>], iteration_sizes = [500, 500, 500]>> in !stream.resource<*>{%11}
  %13 = stream.tensor.sizeof on(#hal.device.affinity<@__device_0>) tensor<500x500xf32, #iree_encoding.encoding<operand_index = 2 : index, op_type = matmul, element_types = [f32, f32, f32], user_indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d2)>, affine_map<(d0, d1, d2) -> (d2, d1)>, affine_map<(d0, d1, d2) -> (d0, d1)>], iteration_sizes = [500, 500, 500]>> : index
  %14 = stream.tensor.encode on(#hal.device.affinity<@__device_0>) %8 : tensor<500x500xf32> in !stream.resource<*>{%6} -> tensor<500x500xf32, #iree_encoding.encoding<operand_index = 2 : index, op_type = matmul, element_types = [f32, f32, f32], user_indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d2)>, affine_map<(d0, d1, d2) -> (d2, d1)>, affine_map<(d0, d1, d2) -> (d0, d1)>], iteration_sizes = [500, 500, 500]>> in !stream.resource<*>{%13}
  %15 = stream.tensor.sizeof on(#hal.device.affinity<@__device_0>) tensor<500x500xf32> : index
  %16 = stream.tensor.dispatch on(#hal.device.affinity<@__device_0>) @matmul_dispatch_0::@matmul_dispatch_0_matmul_like_500x500x500_f32(%10, %12, %14) : (tensor<500x500xf32, #iree_encoding.encoding<operand_index = 0 : index, op_type = matmul, element_types = [f32, f32, f32], user_indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d2)>, affine_map<(d0, d1, d2) -> (d2, d1)>, affine_map<(d0, d1, d2) -> (d0, d1)>], iteration_sizes = [500, 500, 500]>> in !stream.resource<*>{%9}, tensor<500x500xf32, #iree_encoding.encoding<operand_index = 1 : index, op_type = matmul, element_types = [f32, f32, f32], user_indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d2)>, affine_map<(d0, d1, d2) -> (d2, d1)>, affine_map<(d0, d1, d2) -> (d0, d1)>], iteration_sizes = [500, 500, 500]>> in !stream.resource<*>{%11}, tensor<500x500xf32, #iree_encoding.encoding<operand_index = 2 : index, op_type = matmul, element_types = [f32, f32, f32], user_indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d2)>, affine_map<(d0, d1, d2) -> (d2, d1)>, affine_map<(d0, d1, d2) -> (d0, d1)>], iteration_sizes = [500, 500, 500]>> in !stream.resource<*>{%13}) -> tensor<500x500xf32> in !stream.resource<*>{%15}
  %17 = stream.async.cast on(#hal.device.affinity<@__device_0>) %16 : !stream.resource<*>{%15} -> !stream.resource<external>{%15}
  %18 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %17 : tensor<500x500xf32> in !stream.resource<external>{%15} -> !hal.buffer_view
  util.return %18 : !hal.buffer_view
}

