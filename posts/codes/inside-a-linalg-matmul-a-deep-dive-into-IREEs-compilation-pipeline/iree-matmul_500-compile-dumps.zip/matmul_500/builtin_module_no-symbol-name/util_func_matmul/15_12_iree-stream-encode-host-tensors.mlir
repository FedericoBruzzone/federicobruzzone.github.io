// -----// IR Dump After EncodeHostTensorsPass: iree-stream-encode-host-tensors //----- //
util.func public @matmul(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "sync func @matmul(%input0: tensor<500x500xf32>, %input1: tensor<500x500xf32>, %input2: tensor<500x500xf32>) -> (%output0: tensor<500x500xf32>)"}} {
  %c0 = arith.constant 0 : index
  %c1016064 = arith.constant 1016064 : index
  %c1008000 = arith.constant 1008000 : index
  %c1000000 = arith.constant 1000000 : index
  %c500 = arith.constant 500 : index
  %element_type_f32 = hal.element_type<f32> : i32
  %dense_row_major = hal.encoding_type<dense_row_major> : i32
  hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%c500, %c500]) type(%element_type_f32) encoding(%dense_row_major)
  %0 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<500x500xf32> in !stream.resource<external>{%c1000000}
  %1 = stream.async.cast on(#hal.device.affinity<@__device_0>) %0 : !stream.resource<external>{%c1000000} -> !stream.resource<*>{%c1000000}
  hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%c500, %c500]) type(%element_type_f32) encoding(%dense_row_major)
  %2 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<500x500xf32> in !stream.resource<external>{%c1000000}
  %3 = stream.async.cast on(#hal.device.affinity<@__device_0>) %2 : !stream.resource<external>{%c1000000} -> !stream.resource<*>{%c1000000}
  hal.buffer_view.assert<%arg2 : !hal.buffer_view> message("input2") shape([%c500, %c500]) type(%element_type_f32) encoding(%dense_row_major)
  %4 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg2 : !hal.buffer_view -> tensor<500x500xf32> in !stream.resource<external>{%c1000000}
  %5 = stream.async.cast on(#hal.device.affinity<@__device_0>) %4 : !stream.resource<external>{%c1000000} -> !stream.resource<*>{%c1000000}
  %6 = stream.tensor.encode on(#hal.device.affinity<@__device_0>) %1 : tensor<500x500xf32> in !stream.resource<*>{%c1000000} -> tensor<500x500xf32, #iree_encoding.layout<[#iree_cpu.cpu_encoding_resolver<configuration = {encoding_info = {innerDimsPos = [0, 1], innerTileSizes = [8, 1], outerDimsPerm = [0, 1]}}>]>> in !stream.resource<*>{%c1008000}
  %7 = stream.tensor.encode on(#hal.device.affinity<@__device_0>) %3 : tensor<500x500xf32> in !stream.resource<*>{%c1000000} -> tensor<500x500xf32, #iree_encoding.layout<[#iree_cpu.cpu_encoding_resolver<configuration = {encoding_info = {innerDimsPos = [1, 0], innerTileSizes = [8, 1], outerDimsPerm = [1, 0]}}>]>> in !stream.resource<*>{%c1008000}
  %8 = stream.tensor.encode on(#hal.device.affinity<@__device_0>) %5 : tensor<500x500xf32> in !stream.resource<*>{%c1000000} -> tensor<500x500xf32, #iree_encoding.layout<[#iree_cpu.cpu_encoding_resolver<configuration = {encoding_info = {innerDimsPos = [0, 1], innerTileSizes = [8, 8], outerDimsPerm = [0, 1]}}>]>> in !stream.resource<*>{%c1016064}
  %9 = stream.async.dispatch on(#hal.device.affinity<@__device_0>) @matmul_dispatch_0::@matmul_dispatch_0_matmul_like_500x500x500_f32(%6[%c0 to %c1008000 for %c1008000], %7[%c0 to %c1008000 for %c1008000], %8[%c0 to %c1016064 for %c1016064]) : (!stream.resource<*>{%c1008000}, !stream.resource<*>{%c1008000}, !stream.resource<*>{%c1016064}) -> !stream.resource<*>{%c1000000}
  %10 = stream.async.cast on(#hal.device.affinity<@__device_0>) %9 : !stream.resource<*>{%c1000000} -> !stream.resource<external>{%c1000000}
  %11 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %10 : tensor<500x500xf32> in !stream.resource<external>{%c1000000} -> !hal.buffer_view
  util.return %11 : !hal.buffer_view
}

