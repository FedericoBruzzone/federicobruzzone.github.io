// -----// IR Dump After CanonicalizerPass: canonicalize{cse-between-iterations=false    max-iterations=10 max-num-rewrites=-1 region-simplify=normal test-convergence=false top-down=true} //----- //
util.func public @matmul(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "sync func @matmul(%input0: tensor<500x500xf32>, %input1: tensor<500x500xf32>, %input2: tensor<500x500xf32>) -> (%output0: tensor<500x500xf32>)"}} {
  %c0 = arith.constant 0 : index
  %c1016064 = arith.constant 1016064 : index
  %c1008000 = arith.constant 1008000 : index
  %c1000000 = arith.constant 1000000 : index
  %c500 = arith.constant 500 : index
  %element_type_f32 = hal.element_type<f32> : i32
  %dense_row_major = hal.encoding_type<dense_row_major> : i32
  hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%c500, %c500]) type(%element_type_f32) encoding(%dense_row_major)
  %0 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<500x500xf32> in !stream.resource<external>{%c1000000}
  hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%c500, %c500]) type(%element_type_f32) encoding(%dense_row_major)
  %1 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<500x500xf32> in !stream.resource<external>{%c1000000}
  hal.buffer_view.assert<%arg2 : !hal.buffer_view> message("input2") shape([%c500, %c500]) type(%element_type_f32) encoding(%dense_row_major)
  %2 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg2 : !hal.buffer_view -> tensor<500x500xf32> in !stream.resource<external>{%c1000000}
  %results, %result_timepoint = stream.async.execute on(#hal.device.affinity<@__device_0>) with(%0 as %arg3: !stream.resource<external>{%c1000000}, %1 as %arg4: !stream.resource<external>{%c1000000}, %2 as %arg5: !stream.resource<external>{%c1000000}) -> !stream.resource<external>{%c1000000} {
    %5:3 = stream.async.concurrent with(%arg3 as %arg6: !stream.resource<external>{%c1000000}, %arg4 as %arg7: !stream.resource<external>{%c1000000}, %arg5 as %arg8: !stream.resource<external>{%c1000000}) -> (!stream.resource<transient>{%c1008000}, !stream.resource<transient>{%c1008000}, !stream.resource<transient>{%c1016064}) {
      %7 = stream.async.dispatch @_encoding_0::@_encoding_0_encode_500x500xf32_to_500x500xf32(%arg6[%c0 to %c1000000 for %c1000000]) : (!stream.resource<external>{%c1000000}) -> !stream.resource<transient>{%c1008000}
      %8 = stream.async.dispatch @_encoding_1::@_encoding_1_encode_500x500xf32_to_500x500xf32(%arg7[%c0 to %c1000000 for %c1000000]) : (!stream.resource<external>{%c1000000}) -> !stream.resource<transient>{%c1008000}
      %9 = stream.async.dispatch @_encoding_2::@_encoding_2_encode_500x500xf32_to_500x500xf32(%arg8[%c0 to %c1000000 for %c1000000]) : (!stream.resource<external>{%c1000000}) -> !stream.resource<transient>{%c1016064}
      stream.yield %7, %8, %9 : !stream.resource<transient>{%c1008000}, !stream.resource<transient>{%c1008000}, !stream.resource<transient>{%c1016064}
    }
    %6 = stream.async.dispatch @matmul_dispatch_0::@matmul_dispatch_0_matmul_like_500x500x500_f32(%5#0[%c0 to %c1008000 for %c1008000], %5#1[%c0 to %c1008000 for %c1008000], %5#2[%c0 to %c1016064 for %c1016064]) : (!stream.resource<transient>{%c1008000}, !stream.resource<transient>{%c1008000}, !stream.resource<transient>{%c1016064}) -> !stream.resource<external>{%c1000000}
    stream.yield %6 : !stream.resource<external>{%c1000000}
  } => !stream.timepoint
  %3 = stream.timepoint.await %result_timepoint => %results : !stream.resource<external>{%c1000000}
  %4 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %3 : tensor<500x500xf32> in !stream.resource<external>{%c1000000} -> !hal.buffer_view
  util.return %4 : !hal.buffer_view
}

