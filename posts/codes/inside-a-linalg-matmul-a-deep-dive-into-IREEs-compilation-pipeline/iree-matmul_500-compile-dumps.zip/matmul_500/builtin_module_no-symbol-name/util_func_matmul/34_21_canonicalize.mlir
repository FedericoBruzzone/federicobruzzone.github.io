// -----// IR Dump After CanonicalizerPass: canonicalize{cse-between-iterations=false    max-iterations=10 max-num-rewrites=-1 region-simplify=normal test-convergence=false top-down=true} //----- //
util.func public @matmul(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "sync func @matmul(%input0: tensor<500x500xf32>, %input1: tensor<500x500xf32>, %input2: tensor<500x500xf32>) -> (%output0: tensor<500x500xf32>)"}} {
  %c3032064 = arith.constant 3032064 : index
  %c0 = arith.constant 0 : index
  %c1000000 = arith.constant 1000000 : index
  %c500 = arith.constant 500 : index
  %element_type_f32 = hal.element_type<f32> : i32
  %dense_row_major = hal.encoding_type<dense_row_major> : i32
  hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%c500, %c500]) type(%element_type_f32) encoding(%dense_row_major)
  %0 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg0 : !hal.buffer_view -> tensor<500x500xf32> in !stream.resource<external>{%c1000000}
  hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%c500, %c500]) type(%element_type_f32) encoding(%dense_row_major)
  %1 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg1 : !hal.buffer_view -> tensor<500x500xf32> in !stream.resource<external>{%c1000000}
  hal.buffer_view.assert<%arg2 : !hal.buffer_view> message("input2") shape([%c500, %c500]) type(%element_type_f32) encoding(%dense_row_major)
  %2 = stream.tensor.import on(#hal.device.affinity<@__device_0>) %arg2 : !hal.buffer_view -> tensor<500x500xf32> in !stream.resource<external>{%c1000000}
  %result, %result_timepoint = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) : !stream.resource<external>{%c1000000} => !stream.timepoint
  %result_0, %result_timepoint_1 = stream.resource.alloca uninitialized on(#hal.device.affinity<@__device_0>) : !stream.resource<transient>{%c3032064} => !stream.timepoint
  %3 = stream.timepoint.join max(%result_timepoint, %result_timepoint_1) => !stream.timepoint
  %4 = stream.cmd.execute on(#hal.device.affinity<@__device_0>) await(%3) => with(%0 as %arg3: !stream.resource<external>{%c1000000}, %1 as %arg4: !stream.resource<external>{%c1000000}, %2 as %arg5: !stream.resource<external>{%c1000000}, %result as %arg6: !stream.resource<external>{%c1000000}, %result_0 as %arg7: !stream.resource<transient>{%c3032064}) {
    stream.cmd.concurrent {
      stream.cmd.dispatch @_encoding_0::@_encoding_0_encode_500x500xf32_to_500x500xf32 {
        ro %arg3[%c0 for %c1000000] : !stream.resource<external>{%c1000000},
        wo %arg7[%c0 for %c3032064] : !stream.resource<transient>{%c3032064}
      }
      stream.cmd.dispatch @_encoding_1::@_encoding_1_encode_500x500xf32_to_500x500xf32 {
        ro %arg4[%c0 for %c1000000] : !stream.resource<external>{%c1000000},
        wo %arg7[%c0 for %c3032064] : !stream.resource<transient>{%c3032064}
      }
      stream.cmd.dispatch @_encoding_2::@_encoding_2_encode_500x500xf32_to_500x500xf32 {
        ro %arg5[%c0 for %c1000000] : !stream.resource<external>{%c1000000},
        wo %arg7[%c0 for %c3032064] : !stream.resource<transient>{%c3032064}
      }
    }
    stream.cmd.dispatch @matmul_dispatch_0::@matmul_dispatch_0_matmul_like_500x500x500_f32 {
      ro %arg7[%c0 for %c3032064] : !stream.resource<transient>{%c3032064},
      wo %arg6[%c0 for %c1000000] : !stream.resource<external>{%c1000000}
    }
  } => !stream.timepoint
  %5 = stream.resource.dealloca on(#hal.device.affinity<@__device_0>) await(%4) => %result_0 : !stream.resource<transient>{%c3032064} => !stream.timepoint
  %6 = stream.timepoint.await %5 => %result : !stream.resource<external>{%c1000000}
  %7 = stream.tensor.export on(#hal.device.affinity<@__device_0>) %6 : tensor<500x500xf32> in !stream.resource<external>{%c1000000} -> !hal.buffer_view
  util.return %7 : !hal.buffer_view
}

