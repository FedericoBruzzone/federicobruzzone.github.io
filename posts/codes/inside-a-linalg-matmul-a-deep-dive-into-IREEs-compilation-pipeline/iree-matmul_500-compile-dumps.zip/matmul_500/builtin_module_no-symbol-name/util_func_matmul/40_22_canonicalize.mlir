// -----// IR Dump After CanonicalizerPass: canonicalize{cse-between-iterations=false    max-iterations=10 max-num-rewrites=-1 region-simplify=normal test-convergence=false top-down=true} //----- //
util.func public @matmul(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "sync func @matmul(%input0: tensor<500x500xf32>, %input1: tensor<500x500xf32>, %input2: tensor<500x500xf32>) -> (%output0: tensor<500x500xf32>)"}} {
  %c-1_i32 = arith.constant -1 : i32
  %c0_i64 = arith.constant 0 : i64
  %0 = util.null : !hal.fence
  %c-1_i64 = arith.constant -1 : i64
  %c3032064 = arith.constant 3032064 : index
  %c0 = arith.constant 0 : index
  %c1000000 = arith.constant 1000000 : index
  %c500 = arith.constant 500 : index
  %element_type_f32 = hal.element_type<f32> : i32
  %dense_row_major = hal.encoding_type<dense_row_major> : i32
  hal.buffer_view.assert<%arg0 : !hal.buffer_view> message("input0") shape([%c500, %c500]) type(%element_type_f32) encoding(%dense_row_major)
  %buffer = hal.buffer_view.buffer<%arg0 : !hal.buffer_view> : !hal.buffer
  %__device_0 = util.global.load immutable @__device_0 : !hal.device
  %allocator = hal.device.allocator<%__device_0 : !hal.device> : !hal.allocator
  hal.buffer.assert<%buffer : !hal.buffer> message("tensor") allocator(%allocator : !hal.allocator) minimum_length(%c1000000) type(DeviceVisible) usage("TransferSource|TransferTarget|Transfer|DispatchStorageRead|DispatchStorageWrite|DispatchStorage")
  hal.buffer_view.assert<%arg1 : !hal.buffer_view> message("input1") shape([%c500, %c500]) type(%element_type_f32) encoding(%dense_row_major)
  %buffer_0 = hal.buffer_view.buffer<%arg1 : !hal.buffer_view> : !hal.buffer
  %__device_0_1 = util.global.load immutable @__device_0 : !hal.device
  %allocator_2 = hal.device.allocator<%__device_0_1 : !hal.device> : !hal.allocator
  hal.buffer.assert<%buffer_0 : !hal.buffer> message("tensor") allocator(%allocator_2 : !hal.allocator) minimum_length(%c1000000) type(DeviceVisible) usage("TransferSource|TransferTarget|Transfer|DispatchStorageRead|DispatchStorageWrite|DispatchStorage")
  hal.buffer_view.assert<%arg2 : !hal.buffer_view> message("input2") shape([%c500, %c500]) type(%element_type_f32) encoding(%dense_row_major)
  %buffer_3 = hal.buffer_view.buffer<%arg2 : !hal.buffer_view> : !hal.buffer
  %__device_0_4 = util.global.load immutable @__device_0 : !hal.device
  %allocator_5 = hal.device.allocator<%__device_0_4 : !hal.device> : !hal.allocator
  hal.buffer.assert<%buffer_3 : !hal.buffer> message("tensor") allocator(%allocator_5 : !hal.allocator) minimum_length(%c1000000) type(DeviceVisible) usage("TransferSource|TransferTarget|Transfer|DispatchStorageRead|DispatchStorageWrite|DispatchStorage")
  %memory_types, %buffer_usage = hal.allocator.resolve_memory_properties for(#hal.device.affinity<@__device_0>) lifetime(external) : i32, i32
  %__device_0_6 = util.global.load immutable @__device_0 : !hal.device
  %fence = hal.fence.create device(%__device_0_6 : !hal.device) flags("None") : !hal.fence
  %transient_buffer = hal.device.queue.alloca<%__device_0_6 : !hal.device> affinity(%c-1_i64) wait(%0) signal(%fence) pool(%c0_i64) type(%memory_types) usage(%buffer_usage) flags("None") : !hal.buffer{%c1000000}
  %memory_types_7, %buffer_usage_8 = hal.allocator.resolve_memory_properties for(#hal.device.affinity<@__device_0>) lifetime(transient) : i32, i32
  %__device_0_9 = util.global.load immutable @__device_0 : !hal.device
  %fence_10 = hal.fence.create device(%__device_0_9 : !hal.device) flags("None") : !hal.fence
  %transient_buffer_11 = hal.device.queue.alloca<%__device_0_9 : !hal.device> affinity(%c-1_i64) wait(%0) signal(%fence_10) pool(%c0_i64) type(%memory_types_7) usage(%buffer_usage_8) flags("None") : !hal.buffer{%c3032064}
  %fence_12 = hal.fence.join at([%fence, %fence_10]) flags("None") -> !hal.fence
  %__device_0_13 = util.global.load immutable @__device_0 : !hal.device
  %1 = util.call @__matmul_memoize_lookup(%__device_0_13, %c-1_i64) : (!hal.device, i64) -> !hal.command_buffer
  %fence_14 = hal.fence.create device(%__device_0_13 : !hal.device) flags("None") : !hal.fence
  hal.device.queue.execute.indirect<%__device_0_13 : !hal.device> affinity(%c-1_i64) wait(%fence_12) signal(%fence_14) commands(%1) bindings([
    (%buffer : !hal.buffer)[%c0, %c1000000], 
    (%buffer_0 : !hal.buffer)[%c0, %c1000000], 
    (%buffer_3 : !hal.buffer)[%c0, %c1000000], 
    (%transient_buffer : !hal.buffer)[%c0, %c1000000], 
    (%transient_buffer_11 : !hal.buffer)[%c0, %c3032064]
  ]) flags("None")
  %__device_0_15 = util.global.load immutable @__device_0 : !hal.device
  %fence_16 = hal.fence.create device(%__device_0_15 : !hal.device) flags("None") : !hal.fence
  hal.device.queue.dealloca<%__device_0_15 : !hal.device> affinity(%c-1_i64) wait(%fence_14) signal(%fence_16) buffer(%transient_buffer_11 : !hal.buffer) flags("None")
  %status = hal.fence.await until([%fence_16]) timeout_millis(%c-1_i32) flags("None") : i32
  util.status.check_ok %status, "failed to wait on timepoint"
  %dense_row_major_17 = hal.encoding_type<dense_row_major> : i32
  %element_type_f32_18 = hal.element_type<f32> : i32
  %view = hal.buffer_view.create buffer(%transient_buffer : !hal.buffer)[%c0, %c1000000] shape([%c500, %c500]) type(%element_type_f32_18) encoding(%dense_row_major_17) : !hal.buffer_view
  util.return %view : !hal.buffer_view
}

