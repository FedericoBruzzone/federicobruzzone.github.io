// -----// IR Dump After ConvertEncodingToFlowPass: iree-dispatch-creation-convert-encoding-to-flow //----- //
util.func public @matmul(%arg0: !hal.buffer_view, %arg1: !hal.buffer_view, %arg2: !hal.buffer_view) -> !hal.buffer_view attributes {iree.abi.stub, iree.reflection = {iree.abi.declaration = "sync func @matmul(%input0: tensor<500x500xf32>, %input1: tensor<500x500xf32>, %input2: tensor<500x500xf32>) -> (%output0: tensor<500x500xf32>)"}} {
  %0 = hal.tensor.import %arg0 "input0" : !hal.buffer_view -> tensor<500x500xf32>
  %1 = iree_tensor_ext.compute_barrier.start %0 : tensor<500x500xf32> -> tensor<500x500xf32>
  %2 = hal.tensor.import %arg1 "input1" : !hal.buffer_view -> tensor<500x500xf32>
  %3 = iree_tensor_ext.compute_barrier.start %2 : tensor<500x500xf32> -> tensor<500x500xf32>
  %4 = hal.tensor.import %arg2 "input2" : !hal.buffer_view -> tensor<500x500xf32>
  %5 = iree_tensor_ext.compute_barrier.start %4 : tensor<500x500xf32> -> tensor<500x500xf32>
  %6 = flow.tensor.encode %1 : tensor<500x500xf32> -> tensor<500x500xf32, #iree_encoding.encoding<operand_index = 0 : index, op_type = matmul, element_types = [f32, f32, f32], user_indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d2)>, affine_map<(d0, d1, d2) -> (d2, d1)>, affine_map<(d0, d1, d2) -> (d0, d1)>], iteration_sizes = [500, 500, 500]>>
  %7 = flow.tensor.encode %3 : tensor<500x500xf32> -> tensor<500x500xf32, #iree_encoding.encoding<operand_index = 1 : index, op_type = matmul, element_types = [f32, f32, f32], user_indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d2)>, affine_map<(d0, d1, d2) -> (d2, d1)>, affine_map<(d0, d1, d2) -> (d0, d1)>], iteration_sizes = [500, 500, 500]>>
  %8 = flow.tensor.encode %5 : tensor<500x500xf32> -> tensor<500x500xf32, #iree_encoding.encoding<operand_index = 2 : index, op_type = matmul, element_types = [f32, f32, f32], user_indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d2)>, affine_map<(d0, d1, d2) -> (d2, d1)>, affine_map<(d0, d1, d2) -> (d0, d1)>], iteration_sizes = [500, 500, 500]>>
  %9 = flow.dispatch.region -> (tensor<500x500xf32>) {
    %12 = linalg.generic {indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d2)>, affine_map<(d0, d1, d2) -> (d2, d1)>, affine_map<(d0, d1, d2) -> (d0, d1)>], iterator_types = ["parallel", "parallel", "reduction"]} ins(%6, %7 : tensor<500x500xf32, #iree_encoding.encoding<operand_index = 0 : index, op_type = matmul, element_types = [f32, f32, f32], user_indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d2)>, affine_map<(d0, d1, d2) -> (d2, d1)>, affine_map<(d0, d1, d2) -> (d0, d1)>], iteration_sizes = [500, 500, 500]>>, tensor<500x500xf32, #iree_encoding.encoding<operand_index = 1 : index, op_type = matmul, element_types = [f32, f32, f32], user_indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d2)>, affine_map<(d0, d1, d2) -> (d2, d1)>, affine_map<(d0, d1, d2) -> (d0, d1)>], iteration_sizes = [500, 500, 500]>>) outs(%8 : tensor<500x500xf32, #iree_encoding.encoding<operand_index = 2 : index, op_type = matmul, element_types = [f32, f32, f32], user_indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d2)>, affine_map<(d0, d1, d2) -> (d2, d1)>, affine_map<(d0, d1, d2) -> (d0, d1)>], iteration_sizes = [500, 500, 500]>>) {
    ^bb0(%in: f32, %in_0: f32, %out: f32):
      %14 = arith.mulf %in, %in_0 : f32
      %15 = arith.addf %out, %14 : f32
      linalg.yield %15 : f32
    } -> tensor<500x500xf32, #iree_encoding.encoding<operand_index = 2 : index, op_type = matmul, element_types = [f32, f32, f32], user_indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d2)>, affine_map<(d0, d1, d2) -> (d2, d1)>, affine_map<(d0, d1, d2) -> (d0, d1)>], iteration_sizes = [500, 500, 500]>>
    %13 = iree_encoding.unset_encoding %12 : tensor<500x500xf32, #iree_encoding.encoding<operand_index = 2 : index, op_type = matmul, element_types = [f32, f32, f32], user_indexing_maps = [affine_map<(d0, d1, d2) -> (d0, d2)>, affine_map<(d0, d1, d2) -> (d2, d1)>, affine_map<(d0, d1, d2) -> (d0, d1)>], iteration_sizes = [500, 500, 500]>> -> tensor<500x500xf32>
    flow.return %13 : tensor<500x500xf32>
  }
  %10 = iree_tensor_ext.compute_barrier.end %9 : tensor<500x500xf32> -> tensor<500x500xf32>
  %11 = hal.tensor.export %10 "output0" : tensor<500x500xf32> -> !hal.buffer_view
  util.return %11 : !hal.buffer_view
}

